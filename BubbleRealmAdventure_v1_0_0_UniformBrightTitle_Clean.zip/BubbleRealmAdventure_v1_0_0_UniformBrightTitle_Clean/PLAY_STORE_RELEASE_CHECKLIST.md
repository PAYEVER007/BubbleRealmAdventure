# Bubble Realm Adventure — first Play Store release

Version name: 1.0.0; version code: 1; application ID: com.bubblerealm.adventure.

## Updated
- Shared loading/home title scaled from 77% to 70% of view width and darkened slightly.
- Removed superseded release notes; retained runtime assets, game code, and Gradle config.
- Existing game/debris logic not edited.

## REQUIRED before production release
- Replace all four official Google TEST AdMob IDs in app/src/main/res/values/strings.xml with real IDs.
- Create/configure the app in Play Console, confirm application ID is unused, and configure app signing/upload key.
- Build a signed release Android App Bundle (.aab) using an Android SDK and working Gradle environment; upload to internal testing.
- This source ZIP does NOT include gradle/wrapper/gradle-wrapper.jar, so ./gradlew will not work until a standard Gradle wrapper JAR is restored or Gradle is installed.
- Configure in-app products referenced in BillingManager and verify purchase acknowledgement, restoration, refunds and server-side entitlement integrity as applicable.
- Complete Play Console Data Safety, privacy policy, ads declaration, content rating, store listing, target audience and required tests.
- Verify startup, both title screens, repeated debris matches, ads consent, ads, purchases, performance and install/update behavior on real devices.
- Check Google Play target API and SDK/library requirements again at actual submission time.
- Existing installed builds with versionCode > 1 cannot be updated in place by this build; uninstall test builds or use a higher code if already published.

## Verification scope
ZIP integrity and source config were checked; Android compilation, signing, install and Play review were NOT performed. This is a release-preparation source package, not a certified Play-ready release.
