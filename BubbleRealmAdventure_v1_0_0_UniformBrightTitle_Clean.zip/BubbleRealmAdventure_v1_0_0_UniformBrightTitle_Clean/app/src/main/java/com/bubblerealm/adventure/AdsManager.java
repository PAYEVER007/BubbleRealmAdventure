package com.bubblerealm.adventure;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

/**
 * Ads + consent manager for Bubble Realm Adventure.
 *
 * v5.0.6 is configured with Google's official TEST AdMob IDs so the project can
 * be tested safely before the real AdMob app/ad-unit IDs are created. Replace
 * the four AdMob IDs in res/values/strings.xml before a production Play release.
 */
public final class AdsManager {
    public interface RewardListener { void onRewardEarned(int coins); }

    private final Activity activity;
    private ConsentInformation consentInformation;

    private AdView banner;
    private boolean bannerRequested;
    private boolean bannerWanted;
    private RewardedAd rewarded;
    private boolean rewardedLoading;
    private InterstitialAd interstitial;
    private boolean interstitialLoading;
    private boolean adsInitStarted;
    private boolean adsReady;

    // v5.0.6: an eligible NEXT LEVEL press waits briefly for an interstitial that
    // is already loading instead of permanently skipping that ad opportunity.
    private static final long NEXT_LEVEL_AD_WAIT_MS = 4000L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingInterstitialAfter;
    private Runnable pendingInterstitialTimeout;
    private int interstitialRetryCount;

    public AdsManager(Activity activity) {
        this.activity = activity;
        requestConsentAndStartAds();
    }

    private void requestConsentAndStartAds() {
        try {
            consentInformation = UserMessagingPlatform.getConsentInformation(activity);
            ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                    .setTagForUnderAgeOfConsent(false)
                    .build();
            consentInformation.requestConsentInfoUpdate(
                    activity,
                    params,
                    () -> {
                        if (consentInformation.canRequestAds()) startAdsOnce();
                        UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity, formError -> {
                            if (consentInformation.canRequestAds()) startAdsOnce();
                        });
                    },
                    requestConsentError -> {
                        // UMP can still have valid consent cached from a previous session.
                        if (consentInformation.canRequestAds()) startAdsOnce();
                    });
        } catch (Throwable t) {
            // Consent/ads failures never block the game itself.
        }
    }

    private synchronized void startAdsOnce() {
        if (adsInitStarted) return;
        adsInitStarted = true;
        try {
            MobileAds.initialize(activity, status -> {
                adsReady = true;
                loadBannerIfNeeded();
                if (banner != null) banner.setVisibility(bannerWanted ? View.VISIBLE : View.GONE);
                preloadRewarded();
                preloadInterstitial();
            });
        } catch (Throwable t) {
            adsInitStarted = false;
        }
    }

    public AdView createBanner() {
        if (banner != null) return banner;
        try {
            banner = new AdView(activity);
            banner.setAdUnitId(activity.getString(R.string.admob_banner_id));
            DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            int adWidthDp = Math.max(1, (int) (dm.widthPixels / Math.max(1f, dm.density)));
            banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidthDp));
            banner.setVisibility(View.GONE);
            loadBannerIfNeeded();
            return banner;
        } catch (Throwable t) {
            return null;
        }
    }

    private void loadBannerIfNeeded() {
        if (!adsReady || banner == null || bannerRequested) return;
        bannerRequested = true;
        try { banner.loadAd(new AdRequest.Builder().build()); }
        catch (Throwable t) { bannerRequested = false; }
    }

    public void setBannerVisible(boolean visible) {
        bannerWanted = visible;
        if (banner == null) return;
        if (visible) loadBannerIfNeeded();
        banner.setVisibility(visible && adsReady ? View.VISIBLE : View.GONE);
    }

    public void preloadRewarded() {
        if (!adsReady || rewarded != null || rewardedLoading) return;
        rewardedLoading = true;
        try {
            RewardedAd.load(activity, activity.getString(R.string.admob_rewarded_id),
                    new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                        @Override public void onAdLoaded(RewardedAd ad) {
                            rewardedLoading = false;
                            rewarded = ad;
                            rewarded.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override public void onAdDismissedFullScreenContent() {
                                    rewarded = null;
                                    preloadRewarded();
                                }
                                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                    rewarded = null;
                                    preloadRewarded();
                                }
                            });
                        }
                        @Override public void onAdFailedToLoad(LoadAdError error) {
                            rewardedLoading = false;
                            rewarded = null;
                        }
                    });
        } catch (Throwable t) {
            rewardedLoading = false;
        }
    }

    public void preloadInterstitial() {
        if (!adsReady || interstitial != null || interstitialLoading) return;
        interstitialLoading = true;
        try {
            InterstitialAd.load(activity, activity.getString(R.string.admob_interstitial_id),
                    new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                        @Override public void onAdLoaded(InterstitialAd ad) {
                            interstitialLoading = false;
                            interstitial = ad;
                            if (pendingInterstitialAfter != null) showPendingInterstitialIfReady();
                        }
                        @Override public void onAdFailedToLoad(LoadAdError error) {
                            interstitialLoading = false;
                            interstitial = null;
                            if (pendingInterstitialAfter != null && interstitialRetryCount < 2) {
                                interstitialRetryCount++;
                                mainHandler.postDelayed(AdsManager.this::preloadInterstitial, 650L);
                            } else if (pendingInterstitialAfter != null) {
                                finishPendingInterstitialWithoutAd();
                            }
                        }
                    });
        } catch (Throwable t) {
            interstitialLoading = false;
            interstitial = null;
            if (pendingInterstitialAfter != null) finishPendingInterstitialWithoutAd();
        }
    }

    /** Called after Adventure levels 2, 4, 6, 8, 10... when NEXT LEVEL is pressed. */
    public void showNextLevelInterstitial(Runnable after) {
        if (pendingInterstitialAfter != null) return;

        if (!adsReady) {
            boolean canRequest = false;
            try { canRequest = consentInformation != null && consentInformation.canRequestAds(); }
            catch (Throwable ignored) {}
            if (!canRequest) {
                if (after != null) after.run();
                return;
            }
            startAdsOnce();
        }

        pendingInterstitialAfter = after;
        interstitialRetryCount = 0;
        pendingInterstitialTimeout = this::finishPendingInterstitialWithoutAd;
        mainHandler.postDelayed(pendingInterstitialTimeout, NEXT_LEVEL_AD_WAIT_MS);

        if (interstitial != null) {
            showPendingInterstitialIfReady();
        } else if (adsReady) {
            preloadInterstitial();
        }
    }

    private void showPendingInterstitialIfReady() {
        if (pendingInterstitialAfter == null || interstitial == null) return;
        Runnable after = pendingInterstitialAfter;
        pendingInterstitialAfter = null;
        if (pendingInterstitialTimeout != null) {
            mainHandler.removeCallbacks(pendingInterstitialTimeout);
            pendingInterstitialTimeout = null;
        }
        InterstitialAd ad = interstitial;
        interstitial = null;
        showInterstitialNow(ad, after);
    }

    private void showInterstitialNow(InterstitialAd ad, Runnable after) {
        if (ad == null) {
            if (after != null) after.run();
            preloadInterstitial();
            return;
        }
        try {
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                private boolean finished;
                private void finishOnce() {
                    if (finished) return;
                    finished = true;
                    preloadInterstitial();
                    if (after != null) after.run();
                }
                @Override public void onAdDismissedFullScreenContent() { finishOnce(); }
                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) { finishOnce(); }
            });
            ad.show(activity);
        } catch (Throwable t) {
            preloadInterstitial();
            if (after != null) after.run();
        }
    }

    private void finishPendingInterstitialWithoutAd() {
        if (pendingInterstitialAfter == null) return;
        Runnable after = pendingInterstitialAfter;
        pendingInterstitialAfter = null;
        if (pendingInterstitialTimeout != null) {
            mainHandler.removeCallbacks(pendingInterstitialTimeout);
            pendingInterstitialTimeout = null;
        }
        interstitialRetryCount = 0;
        preloadInterstitial();
        if (after != null) after.run();
    }

    public void showRewardedCoins(RewardListener listener) {
        showRewardedAmount(7, listener);
    }

    public void showRewardedAmount(int rewardAmount, RewardListener listener) {
        if (!adsReady) {
            Toast.makeText(activity, "Ads are not ready yet. Try again shortly.", Toast.LENGTH_SHORT).show();
            return;
        }
        RewardedAd ad = rewarded;
        if (ad == null) {
            Toast.makeText(activity, "Reward ad is loading. Try again in a moment.", Toast.LENGTH_SHORT).show();
            preloadRewarded();
            return;
        }
        rewarded = null;
        try {
            ad.show(activity, rewardItem -> {
                if (listener != null) listener.onRewardEarned(Math.max(1, rewardAmount));
            });
        } catch (Throwable t) {
            preloadRewarded();
        }
    }

    public boolean isPrivacyOptionsRequired() {
        try {
            return consentInformation != null &&
                    consentInformation.getPrivacyOptionsRequirementStatus()
                            == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
        } catch (Throwable t) {
            return false;
        }
    }

    public void showPrivacyOptions() {
        if (!isPrivacyOptionsRequired()) {
            Toast.makeText(activity, "Ad privacy options are not required for this session.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            UserMessagingPlatform.showPrivacyOptionsForm(activity, formError -> {
                if (consentInformation != null && consentInformation.canRequestAds()) startAdsOnce();
            });
        } catch (Throwable t) {
            Toast.makeText(activity, "Privacy options are unavailable right now.", Toast.LENGTH_SHORT).show();
        }
    }

    public void destroy() {
        try { if (banner != null) banner.destroy(); } catch (Throwable ignored) {}
        if (pendingInterstitialTimeout != null) {
            try { mainHandler.removeCallbacks(pendingInterstitialTimeout); } catch (Throwable ignored) {}
        }
        try { mainHandler.removeCallbacksAndMessages(null); } catch (Throwable ignored) {}
        pendingInterstitialAfter = null;
        pendingInterstitialTimeout = null;
        banner = null;
        rewarded = null;
        interstitial = null;
    }
}
