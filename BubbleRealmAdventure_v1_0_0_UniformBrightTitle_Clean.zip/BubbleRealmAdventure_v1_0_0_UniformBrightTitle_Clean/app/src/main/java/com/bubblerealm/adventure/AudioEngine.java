package com.bubblerealm.adventure;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Looper;

/**
 * Crash-safe SFX engine. Music was removed in v5.5.19.
 * Audio failures are isolated so vendor media bugs do not close the game.
 */
public class AudioEngine {
    public static final int FX_CLICK = 0;
    public static final int FX_SHOOT = 1;
    public static final int FX_POP = 2;
    public static final int FX_BOUNCE = 3;
    public static final int FX_COMBO = 4;
    public static final int FX_COIN = 5;
    public static final int FX_WIN = 6;
    public static final int FX_FAIL = 7;
    public static final int FX_POWER = 8;
    public static final int FX_STAR = 9;
    public static final int FX_LEVEL_START = 10;
    public static final int FX_STREAK = 11;
    public static final int FX_UI_OPEN = 12;
    public static final int FX_DROP = 13;
    public static final int FX_WORLD = 14;
    public static final int FX_BONUS = 15;
    public static final int FX_LAND = 16;
    public static final int FX_TREASURE = 17;
    public static final int FX_SWAP = 18;
    public static final int FX_MAGIC = 19;
    public static final int FX_FEVER = 20;
    public static final int FX_CLEAR90 = 21;
    public static final int FX_VOICE_AMAZING = 22;
    public static final int FX_VOICE_WOW = 23;
    public static final int FX_VOICE_GREAT = 24;
    public static final int FX_VOICE_WELL = 25;
    public static final int FX_VOICE_GOOD = 26;
    public static final int FX_VOICE_BANK = 27;
    public static final int FX_VOICE_NICE = 28;
    public static final int FX_VOICE_LEVEL_UP = 29;
    public static final int FX_LEVEL_UP_CHIME = 30;
    // Dedicated cannon/explosion sounds so gameplay FX do not share the generic pop/shoot SFX.
    public static final int FX_CANNON_C5 = 31;
    public static final int FX_EXPLOSION_E1 = 32;

    private final Context context;
    private SoundPool pool;
    private final int[] soundIds = new int[33];
    private final boolean[] soundLoaded = new boolean[33];
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    // SoundPool decodes in the background; never block the UI thread waiting for callbacks.

    private boolean soundEnabled = true;
    private boolean musicEnabled = false;
    private boolean hostActive = false;
    private boolean released = false;
    private boolean audioAvailable = true;
    // Deliberately louder than earlier builds; the actual audio files are also normalized.

    public AudioEngine(Context context) {
        this.context = context.getApplicationContext();
        initSoundPool();
        // Music has been removed from the game. Keep the audio engine SFX-only.
    }


    public void playPraise(String phrase) {
        if (phrase == null) return;
        String p = phrase.toLowerCase(java.util.Locale.US);
        if (p.contains("amazing")) play(FX_VOICE_AMAZING, 1f, 1f);
        else if (p.contains("wow")) play(FX_VOICE_WOW, 1f, 1f);
        else if (p.contains("great")) play(FX_VOICE_GREAT, 1f, 1f);
        else if (p.contains("well")) play(FX_VOICE_WELL, 1f, 1f);
        else if (p.contains("bank")) play(FX_VOICE_BANK, 1f, 1f);
        else if (p.contains("good")) play(FX_VOICE_GOOD, 1f, 1f);
        else if (p.contains("nice")) play(FX_VOICE_NICE, 1f, 1f);
    }

    public void playPraiseDelayed(String phrase, long delayMs) {
        if (phrase == null || released) return;
        mainHandler.postDelayed(() -> {
            if (!released && soundEnabled) playPraise(phrase);
        }, Math.max(0L, delayMs));
    }

    public void playLevelUpDelayed(long delayMs) {
        if (released) return;
        mainHandler.postDelayed(() -> {
            if (!released && soundEnabled) {
                play(FX_LEVEL_UP_CHIME, 1f, 1f);
                mainHandler.postDelayed(() -> {
                    if (!released && soundEnabled) play(FX_VOICE_LEVEL_UP, 1f, 1f);
                }, 260L);
            }
        }, Math.max(0L, delayMs));
    }

    private void initSoundPool() {
        try {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder()
                    .setMaxStreams(16)
                    .setAudioAttributes(attributes)
                    .build();

            pool.setOnLoadCompleteListener((sp, sampleId, status) -> {
                if (status == 0) {
                    for (int i = 0; i < soundIds.length; i++) {
                        if (soundIds[i] == sampleId) {
                            if (!soundLoaded[i]) {
                                soundLoaded[i] = true;
                            }
                        }
                    }
                }
            });

            // Critical cues first: they must be ready before the first user input.
            soundIds[FX_CLICK] = pool.load(context, R.raw.fx_click, 1);
            soundIds[FX_CANNON_C5] = pool.load(context, R.raw.src_heavy_tank_cannon_blast_c8ca445e, 1);

            soundIds[FX_SHOOT] = pool.load(context, R.raw.fx_shoot, 1);
            soundIds[FX_POP] = pool.load(context, R.raw.fx_pop, 1);
            soundIds[FX_BOUNCE] = pool.load(context, R.raw.fx_bounce, 1);
            soundIds[FX_COMBO] = pool.load(context, R.raw.fx_combo, 1);
            soundIds[FX_COIN] = pool.load(context, R.raw.fx_coin, 1);
            soundIds[FX_WIN] = pool.load(context, R.raw.fx_win, 1);
            soundIds[FX_FAIL] = pool.load(context, R.raw.fx_fail, 1);
            soundIds[FX_POWER] = pool.load(context, R.raw.fx_power, 1);
            soundIds[FX_STAR] = pool.load(context, R.raw.fx_star, 1);
            soundIds[FX_LEVEL_START] = pool.load(context, R.raw.fx_level_start, 1);
            soundIds[FX_STREAK] = pool.load(context, R.raw.fx_streak, 1);
            soundIds[FX_UI_OPEN] = pool.load(context, R.raw.fx_ui_open, 1);
            soundIds[FX_DROP] = pool.load(context, R.raw.fx_drop, 1);
            soundIds[FX_WORLD] = pool.load(context, R.raw.fx_world, 1);
            soundIds[FX_BONUS] = pool.load(context, R.raw.fx_bonus, 1);
            soundIds[FX_LAND] = pool.load(context, R.raw.fx_land, 1);
            soundIds[FX_TREASURE] = pool.load(context, R.raw.fx_treasure, 1);
            soundIds[FX_SWAP] = pool.load(context, R.raw.fx_swap, 1);
            soundIds[FX_MAGIC] = pool.load(context, R.raw.fx_magic, 1);
            soundIds[FX_FEVER] = pool.load(context, R.raw.fx_fever, 1);
            soundIds[FX_CLEAR90] = pool.load(context, R.raw.fx_clear90, 1);
            soundIds[FX_VOICE_AMAZING] = pool.load(context, R.raw.fx_voice_amazing, 1);
            soundIds[FX_VOICE_WOW] = pool.load(context, R.raw.fx_voice_wow, 1);
            soundIds[FX_VOICE_GREAT] = pool.load(context, R.raw.fx_voice_great_shot, 1);
            soundIds[FX_VOICE_WELL] = pool.load(context, R.raw.fx_voice_well_done, 1);
            soundIds[FX_VOICE_GOOD] = pool.load(context, R.raw.fx_voice_good_shot, 1);
            soundIds[FX_VOICE_BANK] = pool.load(context, R.raw.fx_voice_bank_shot, 1);
            soundIds[FX_VOICE_NICE] = pool.load(context, R.raw.fx_voice_nice, 1);
            soundIds[FX_VOICE_LEVEL_UP] = pool.load(context, R.raw.fx_voice_level_up, 1);
            soundIds[FX_LEVEL_UP_CHIME] = pool.load(context, R.raw.fx_level_up_chime, 1);
            soundIds[FX_EXPLOSION_E1] = pool.load(context, R.raw.src_621003__samsterbirdies__cannon_explosion_sound_4, 1);

            // Do not wait here: SoundPool callbacks may be delivered on the main looper.
            // Blocking the constructor delayed the Android launch splash and could make audio
            // callbacks arrive only after the first screen had already appeared.
        } catch (Throwable t) {
            audioAvailable = false;
            safeReleasePool();
        }
    }

    private void rebuildMusicSafe() { /* music removed */ }

    public void setSoundEnabled(boolean enabled) {
        soundEnabled = enabled;
    }

    /** Music was removed in v5.5.19; retained as a no-op for source compatibility. */
    public void setMusicEnabled(boolean enabled) { musicEnabled = false; }
    public void setMusicTheme(int theme) { }
    public void setMusicVolume(float volume) { }
    public boolean isSoundEnabled() { return soundEnabled; }
    public boolean isMusicEnabled() { return false; }
    public boolean isAudioAvailable() { return audioAvailable; }

    public void play(int fx) { play(fx, 1f, 1f); }

    public void play(int fx, float volume, float rate) {
        if (!soundEnabled || released || pool == null || fx < 0 || fx >= soundIds.length) return;
        try {
            int id = soundIds[fx];
            if (id == 0) return;
            if (!soundLoaded[fx]) {
                // Samples decode asynchronously. Retry shortly until SoundPool reports ready;
                // never block the UI/render thread waiting for audio decoding.
                mainHandler.postDelayed(() -> play(fx, volume, rate), 8L);
                return;
            }
            float boosted = Math.max(0f, Math.min(1f, volume * 1.55f));
            pool.play(id, boosted, boosted, 1, 0, Math.max(0.5f, Math.min(2f, rate)));
        } catch (Throwable ignored) {}
    }

    public void onResume() { hostActive = true; }
    public void onPause() { hostActive = false; }

    private void safeReleasePool() {
        if (pool != null) {
            try { pool.release(); } catch (Throwable ignored) {}
            pool = null;
        }
    }


    public void release() {
        released = true;
        mainHandler.removeCallbacksAndMessages(null);
        safeReleasePool();
    }
}
