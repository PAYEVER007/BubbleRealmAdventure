package com.bubblerealm.adventure;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdView;

/** Core host activity. Ads, consent and billing are isolated so failures never stop gameplay. */
public class MainActivity extends Activity implements BillingManager.Listener {
    private BubbleRealmView gameView;
    private FrameLayout root;
    private AdsManager ads;
    private AdView bannerView;
    private boolean bannerDesiredVisible;
    private BillingManager billing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        safeHideSystemUI();

        try {
            root = new FrameLayout(this);
            gameView = new BubbleRealmView(this);
            root.addView(gameView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            setContentView(root);

            try {
                ads = new AdsManager(this);
                bannerView = ads.createBanner();
                if (bannerView != null) {
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                    lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                    root.addView(bannerView, lp);
                    bannerView.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
                        if (bannerDesiredVisible) applyBannerInset(true);
                    });
                }
            } catch (Throwable ignored) {}

            try { billing = new BillingManager(this, this); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            showRecoveryScreen(t);
        }
    }

    public void setBannerVisible(boolean visible) {
        bannerDesiredVisible = visible;
        if (ads != null) ads.setBannerVisible(visible);
        applyBannerInset(visible);
    }

    private void applyBannerInset(boolean requestedVisible) {
        if (gameView == null) return;
        gameView.post(() -> {
            try {
                boolean actuallyVisible = requestedVisible && bannerView != null
                        && bannerView.getVisibility() == View.VISIBLE;
                int reserve = 0;
                if (actuallyVisible) {
                    int measured = bannerView.getMeasuredHeight();
                    int min = Math.round(54f * getResources().getDisplayMetrics().density);
                    reserve = Math.max(measured, min);
                }
                FrameLayout.LayoutParams gp = (FrameLayout.LayoutParams) gameView.getLayoutParams();
                if (gp.bottomMargin != reserve) {
                    gp.bottomMargin = reserve;
                    gameView.setLayoutParams(gp);
                }
            } catch (Throwable ignored) {}
        });
    }

    public void showLevelEndAd(Runnable after) {
        if (ads == null) { if (after != null) after.run(); return; }
        ads.showNextLevelInterstitial(after);
    }

    public void showRewardedCoins() {
        if (ads == null) {
            Toast.makeText(this, "Ads are unavailable on this device.", Toast.LENGTH_SHORT).show();
            return;
        }
        ads.showRewardedCoins(amount -> {
            if (gameView != null) gameView.grantExternalCoins(amount, "REWARDED +" + amount + " COINS");
        });
    }

    public void showRewardedGameReward(int rewardType) {
        if (ads == null) {
            Toast.makeText(this, "Ads are unavailable on this device.", Toast.LENGTH_SHORT).show();
            return;
        }
        ads.showRewardedAmount(1, amount -> {
            if (gameView != null) gameView.grantExternalReward(rewardType);
        });
    }

    public boolean isAdPrivacyOptionsRequired() {
        return ads != null && ads.isPrivacyOptionsRequired();
    }

    public void showAdPrivacyOptions() {
        if (ads != null) ads.showPrivacyOptions();
    }

    public void buyCoinPack(String productId) {
        if (billing == null) {
            Toast.makeText(this, "Google Play purchases are unavailable right now.", Toast.LENGTH_SHORT).show();
            return;
        }
        billing.buy(productId);
    }

    public String getCoinPackPrice(String productId) {
        return billing == null ? "UNAVAILABLE" : billing.getPrice(productId);
    }

    public boolean isBillingReady() { return billing != null && billing.isReady(); }

    public void submitGoogleScore(long score) { }

    @Override
    public void onCoinsPurchased(int coins, String productId, String purchaseToken, Runnable onPersisted) {
        runOnUiThread(() -> {
            if (gameView != null && gameView.grantPurchasedCoinsSafely(
                    coins, "PURCHASE +" + coins + " COINS", purchaseToken)) {
                if (onPersisted != null) onPersisted.run();
            }
        });
    }

    @Override public void onBillingStateChanged(boolean ready) {
        if (gameView != null) gameView.invalidate();
    }

    private void safeHideSystemUI() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                final WindowInsetsController controller = getWindow().getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (Throwable ignored) {}
    }

    private void showRecoveryScreen(Throwable t) {
        TextView v = new TextView(this);
        v.setGravity(Gravity.CENTER);
        v.setTextColor(Color.WHITE);
        v.setBackgroundColor(Color.rgb(42, 36, 105));
        v.setPadding(48, 48, 48, 48);
        v.setTextSize(18f);
        String name = t == null ? "Unknown" : t.getClass().getSimpleName();
        String msg = (t == null || t.getMessage() == null) ? "" : ("\n" + t.getMessage());
        v.setText("Bubble Realm Adventure recovered from a startup problem.\n\nError: " + name + msg +
                "\n\nPlease take a screenshot of this screen and send it to the developer.");
        setContentView(v);
    }

    @Override
    protected void onResume() {
        super.onResume();
        safeHideSystemUI();
        if (gameView != null) try { gameView.onHostResume(); } catch (Throwable ignored) {}
        if (ads != null) try { ads.preloadRewarded(); ads.preloadInterstitial(); } catch (Throwable ignored) {}
        if (billing != null) try { billing.refreshPurchases(); } catch (Throwable ignored) {}
    }

    @Override
    protected void onPause() {
        if (gameView != null) try { gameView.onHostPause(); } catch (Throwable ignored) {}
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) try { gameView.release(); } catch (Throwable ignored) {}
        if (ads != null) try { ads.destroy(); } catch (Throwable ignored) {}
        if (billing != null) try { billing.destroy(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            try { if (gameView.handleBack()) return; } catch (Throwable ignored) {}
        }
        super.onBackPressed();
    }
}
