package com.bubblerealm.adventure;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class BubbleRealmView extends View {

    private enum Screen { SPLASH, HOME, MAP, GAME }
    private enum Overlay { NONE, SETTINGS, HELP, PRIVACY, PAUSE, WIN, LOSE, EXIT_CONFIRM, RESET_CONFIRM, LEADERBOARD, SHOP, REWARD_OFFER }
    private enum Power { NORMAL, BOMB, RAINBOW }
    private enum Objective { CLEAR, RESCUE, KEYS, ICE_BREAK, TREASURE, LIMITED, BOSS }
    private enum GameMode { ADVENTURE, SURVIVAL, TREASURE_ROOM }

    private static final int[] PALETTE = new int[] {
            Color.rgb(0, 198, 83),       // green
            Color.rgb(28, 76, 242),      // royal blue
            Color.rgb(255, 226, 0),      // lemon yellow
            Color.rgb(242, 54, 61),      // red
            Color.rgb(160, 64, 230),     // purple
            Color.rgb(0, 211, 214),      // cyan
            Color.rgb(255, 132, 20),     // orange
            Color.rgb(228, 236, 250)     // pearl
    };

    // Fair free-to-play economy: boosters are useful and earnable, but not refilled every level.
    private static final int BOMB_COST = 140;
    private static final int WILD_COST = 200;
    private static final int DAILY_COIN_REWARD = 8;
    private static final int STARTING_COINS = 45;
    private static final int STARTING_BOMBS = 1;
    private static final int STARTING_WILDS = 1;
    private static final int CONTINUE_COST = 65;
    private static final int SPECIAL_CHEST = 100;
    private static final int SPECIAL_STAR = 200;
    private static final int SPECIAL_ICE = 300;
    private static final int SPECIAL_STONE = 400;
    private static final int SPECIAL_CHAIN = 500;
    private static final int SPECIAL_CLOUD = 600;
    private static final int SPECIAL_KEY = 700;
    private static final int SPECIAL_MYSTERY = 800;
    private static final int SPECIAL_BABY = 900;
    private static final int SPECIAL_LIGHTNING = 1000;
    private static final int SPECIAL_MAGNET = 1100;
    private static final int SPECIAL_PAINT = 1200;
    private static final int SPECIAL_BLACK_HOLE = 1300;
    private static final int SPECIAL_PORTAL = 1400;
    private static final int SPECIAL_ARMOR = 1500;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bubbleBitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF bubbleDrawRect = new RectF();
    private Bitmap logoWordmark;
    private final SharedPreferences prefs;
    private final AudioEngine audio;
    private final Vibrator vibrator;
    private final Random random = new Random();

    private Screen screen = Screen.SPLASH;
    private Overlay overlay = Overlay.NONE;
    private Screen settingsReturnScreen = Screen.HOME;
    private long splashStarted = 0L;
    private long lastFrameNanos = 0L;

    // Saved user state.
    private boolean soundOn;
    private boolean musicOn;
    private boolean aimGuideOn;
    private boolean hapticsOn;
    private int coins;
    private int maxUnlocked;
    private int selectedLevel = 1;
    private int totalStars;
    private int relicCount;
    // Random animated visual themes chosen for each fresh app launch. Gameplay keeps its own world theme,
    // while splash and home deliberately use two DIFFERENT general-purpose live wallpapers every launch.
    private final int startupThemeLevel;
    private final int splashLiveThemeLevel;
    private final int homeLiveThemeLevel;

    // Decorative animation.
    private float ambientTime = 0f;
    private final float[] starX = new float[28];
    private final float[] starY = new float[28];
    private final float[] starPhase = new float[28];

    // Map state.
    private float mapScroll = 0f;
    private float mapTouchStartY = 0f;
    private float mapScrollStart = 0f;
    private boolean mapDragging = false;
    private static final int MAP_LEVELS = 1000;

    // Gameplay grid.
    private static final int GRID_COLS = 10;
    private static final int GRID_ROWS = 18;
    private final HashMap<Integer, Integer> grid = new HashMap<>();
    private float bubbleR;
    private float gridTop;
    private float rowH;
    private float shooterX;
    private float shooterY;
    private float dangerY;
    private Bitmap[] bubbleSprites = new Bitmap[PALETTE.length];

    private int currentColor = 0;
    private int nextColor = 1;
    private int levelScore = 0;
    private int targetScore = 4000;
    // Level objective: clear at least 90% of the bubbles that were present at level start.
    private int initialBubbleCount = 1;
    private int clearTarget = 1;
    private int clearedBubbles = 0;
    private int lastWinClearPercent = 0;
    private int shotsLeft = 28;
    private int misses = 0;
    private int combo = 0;
    private int bombCount = 1;
    private int rainbowCount = 1;
    private Power power = Power.NORMAL;
    private int shotsSinceDrop = 0;
    private int pressureLimit = 7;
    private float rowDropTimer = 0f;
    // Hex-row phase. Toggle this whenever a new ceiling row is inserted so existing
    // bubbles move straight down instead of jumping sideways by half a cell.
    private int gridParityPhase = 0;

    // Aiming and projectile.
    private float aimAngle = (float) -Math.PI / 2f;
    private boolean aiming = false;
    private boolean shotFlying = false;
    private float shotX, shotY, shotVx, shotVy;
    // Safety timer prevents a projectile redirected below the launcher by a moving
    // bumper / portal / gravity interaction from leaving shotFlying stuck forever.
    private float shotFlightTime = 0f;
    private int shotColor;
    private Power shotPower = Power.NORMAL;
    private long lastBounceMs = 0L;
    private int shotBankBounces = 0;

    // Collapsible gameplay tools. One compact button opens/closes the full menu.
    private boolean toolMenuOpen = false;
    // Rewarded-ad offer currently shown in gameplay: 1=moves, 2=bomb, 3=wild.
    private int rewardOfferType = 0;

    // Large animated praise banner shown after skillful shots.
    private String praiseBannerText = null;
    private int praiseBannerColor = Color.WHITE;
    private float praiseBannerTimer = 0f;
    private long lastPraiseAtMs = 0L;
    private long lastAmazingAtMs = 0L;
    private String lastPraiseText = "";

    // v5 realm identity systems. Companion power is earned through skill, never coins.
    private int companionMeter = 0;
    private float companionPulse = 0f;
    private boolean continueUsedThisLevel = false;
    private int fusionStreak = 0;

    // FX.
    private final ArrayList<Particle> particles = new ArrayList<>();
    private final ArrayList<GlassShard> glassShards = new ArrayList<>();
    // All settled collision debris shares one physical floor. This stays synchronized
    // with the resized game view when the bottom banner ad appears/disappears.
    private float debrisFloorY = -1f;
    private final ArrayList<FallingBubble> falling = new ArrayList<>();
    private final ArrayList<FloatingText> floatingTexts = new ArrayList<>();
    private float screenShake = 0f;
    private int displayedBest = 0;
    private int lastWinStars = 1;
    private int lastWinReward = 65;
    private int lastChestBonus = 0;
    private int lastBossBonus = 0;
    private static final float LEVEL_INTRO_DURATION = 2.70f;
    private static final long SPLASH_DURATION_MS = 6500L;
    private float levelIntroTimer = 0f;
    private boolean introWasActive = false;
    private float launcherPulse = 0f;
    // v5.5 cannon firing FX. The cannon is a visual launcher only; the existing
    // projectile/collision rules remain unchanged.
    private float cannonFireTimer = 0f;
    private float cannonRecoil = 0f;
    private float cannonBurstTimer = 0f;
    private float cannonBurstX = 0f, cannonBurstY = 0f;
    private int cannonBurstColor = Color.WHITE;
    private float cannonBurstPower = 1f;
    private final Bitmap[] cannonExplosionFrames = new Bitmap[24];
    private float popFlash = 0f;
    // Short board-impact wave: nearby bubbles wiggle when a shot lands/pops.
    private float impactTimer = 0f;
    private float impactX = 0f, impactY = 0f;
    private float impactStrength = 0f;
    private float feverTimer = 0f;
    private float feverBurst = 0f;
    private float winCelebrationTimer = 0f;
    private float loseCelebrationTimer = 0f;
    private boolean lastLevelWasUnlock = false;
    private int winStarSoundStage = 0;
    private Objective objective = Objective.CLEAR;
    private int objectiveTarget = 0;
    private int objectiveProgress = 0;
    private boolean dailyChallengeMode = false;
    // True only while startLevel() is building a Daily Challenge. This keeps the
    // player's Adventure resume slot completely isolated from the daily session.
    private boolean launchingDailyChallenge = false;
    private boolean almostThereAnnounced = false;
    private float perfectShotTimer = 0f;
    private int winStreak = 0;
    private int levelLossStreak = 0;
    private String milestoneText = null;
    private int shotChestBonus = 0;
    private int shotStarBonus = 0;
    private int shotMysteryScore = 0;
    private final ArrayList<RingFx> rings = new ArrayList<>();

    // v4.0 major gameplay systems.
    private GameMode gameMode = GameMode.ADVENTURE;
    private int survivalWave = 1;
    private int survivalBest = 0;
    private int treasureReturnLevel = 1;
    private boolean treasureRoomPending = false;
    private int activeBranchRoute = 0; // 0 normal, 1 POWER route, 2 TREASURE route
    private int formationMode = 0;     // 0 still, 1 sway, 2 rotate, 3 pulse-wave
    private float windForce = 0f;
    private float gravityForce = 0f;
    private float portalCooldown = 0f;
    private int superCharge = 0;
    private boolean superReadyAnnounced = false;
    private int bossShield = 0;
    private int bossMaxShield = 0;
    private int bossShotsUntilAttack = 0;
    private int bossPhase = 1;
    // v4.1 skill obstacles: an animated energy bumper can deflect shots on selected stages.
    private int movingBarrierMode = 0; // 0 off, 1 horizontal sweep, 2 figure-eight, 3 twin sweep
    private float barrierCooldown = 0f;

    // Touch helpers.
    private float downX, downY;
    private long downTime;
    // If a vendor-specific Canvas/graphics call fails, keep the app alive and show a
    // diagnostic screen instead of letting Android close the process.
    private String renderError = null;
    private boolean lastBannerVisible = false;

    public BubbleRealmView(Context context) {
        super(context);
        setFocusable(true);
        setKeepScreenOn(true);
        prefs = context.getSharedPreferences("bubble_realm_prefs", Context.MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);
        musicOn = prefs.getBoolean("music", true);
        aimGuideOn = prefs.getBoolean("aimGuide", true);
        hapticsOn = prefs.getBoolean("haptics", true);
        coins = prefs.getInt("coins", STARTING_COINS);
        maxUnlocked = Math.max(1, prefs.getInt("maxUnlocked", 1));
        totalStars = prefs.getInt("totalStars", 0);
        relicCount = Math.max(0,prefs.getInt("relic_count",0));
        bombCount = Math.max(0, prefs.getInt("bomb_inventory", STARTING_BOMBS));
        rainbowCount = Math.max(0, prefs.getInt("wild_inventory", STARTING_WILDS));
        if (!prefs.getBoolean("starter_boosters_v28", false)) {
            bombCount = Math.max(STARTING_BOMBS, bombCount);
            rainbowCount = Math.max(STARTING_WILDS, rainbowCount);
            prefs.edit().putInt("bomb_inventory", bombCount)
                    .putInt("wild_inventory", rainbowCount)
                    .putBoolean("starter_boosters_v28", true).commit();
        }
        // v2.11.2 balance change: starter inventory is one Bomb + one Wild.
        // Only migrate the old untouched/default value of 2; larger earned inventories are preserved.
        if (!prefs.getBoolean("starter_boosters_v2112_one_each", false)) {
            SharedPreferences.Editor starterFix = prefs.edit();
            if (bombCount == 2) { bombCount = 1; starterFix.putInt("bomb_inventory", 1); }
            if (rainbowCount == 2) { rainbowCount = 1; starterFix.putInt("wild_inventory", 1); }
            if (prefs.getInt("saved_bomb", -1) == 2) starterFix.putInt("saved_bomb", 1);
            if (prefs.getInt("saved_rainbow", -1) == 2) starterFix.putInt("saved_rainbow", 1);
            starterFix.putBoolean("starter_boosters_v2112_one_each", true).commit();
        }
        int splashWorld = random.nextInt(20);
        int homeWorld = (splashWorld + 1 + random.nextInt(19)) % 20;
        splashLiveThemeLevel = 1 + splashWorld * 25 + random.nextInt(25);
        homeLiveThemeLevel = 1 + homeWorld * 25 + random.nextInt(25);
        // Reuse the home live-theme world for the foreground bubble palette.
        startupThemeLevel = homeLiveThemeLevel;
        audio = new AudioEngine(context);
        audio.setSoundEnabled(soundOn);
        audio.setMusicEnabled(musicOn);
        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        try { logoWordmark = BitmapFactory.decodeResource(getResources(), R.drawable.bubble_realm_wordmark); }
        catch (Throwable ignored) { logoWordmark = null; }
        // Large VFX frame decoding is deferred until the first screen has been drawn.
        postDelayed(() -> new Thread(this::loadCannonExplosionFrames, "BubbleVfxLoader").start(), 220L);

        text.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        text.setTextAlign(Paint.Align.CENTER);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);

        for (int i = 0; i < starX.length; i++) {
            starX[i] = random.nextFloat();
            starY[i] = random.nextFloat();
            starPhase[i] = random.nextFloat() * 6.28f;
        }
    }

    public void onHostResume() {
        audio.onResume();
        lastFrameNanos = 0L;
        postInvalidateOnAnimation();
    }

    public void onHostPause() {
        if (screen == Screen.GAME) {
            saveGameState();
            if (overlay == Overlay.NONE) overlay = Overlay.PAUSE;
        }
        audio.onPause();
    }

    public void release() {
        audio.release();
        recycleSprites();
    }

    public boolean handleBack() {
        if (overlay != Overlay.NONE) {
            if (overlay == Overlay.PRIVACY) {
                overlay = Overlay.SETTINGS;
            } else if (overlay == Overlay.SETTINGS || overlay == Overlay.HELP || overlay == Overlay.LEADERBOARD || overlay == Overlay.SHOP) {
                overlay = (overlay == Overlay.SETTINGS && settingsReturnScreen == Screen.GAME && screen == Screen.GAME)
                        ? Overlay.PAUSE : Overlay.NONE;
            } else if (overlay == Overlay.PAUSE) {
                overlay = Overlay.NONE;
            } else if (overlay == Overlay.WIN || overlay == Overlay.LOSE) {
                overlay = Overlay.NONE;
                if(dailyChallengeMode){dailyChallengeMode=false;screen=Screen.HOME;audio.setMusicTheme(12);}
                else screen = Screen.MAP;
            } else if (overlay == Overlay.EXIT_CONFIRM) {
                overlay = Overlay.NONE;
            } else if (overlay == Overlay.RESET_CONFIRM) {
                overlay = Overlay.SETTINGS;
            }
            clickFx();
            return true;
        }
        if (screen == Screen.GAME) {
            saveGameState();
            overlay = Overlay.PAUSE;
            clickFx();
            return true;
        }
        if (screen == Screen.MAP) {
            screen = Screen.HOME;
            clickFx();
            return true;
        }
        if (screen == Screen.HOME) {
            overlay = Overlay.EXIT_CONFIRM;
            audio.play(AudioEngine.FX_UI_OPEN, .85f, .95f);
            return true;
        }
        if (screen == Screen.SPLASH) {
            screen = Screen.HOME;
            return true;
        }
        return true;
    }

    private MainActivity host() {
        Context c = getContext();
        return c instanceof MainActivity ? (MainActivity)c : null;
    }

    public void grantExternalReward(int type){
        if(type==1){
            shotsLeft+=5;
            floatingTexts.add(new FloatingText("+5 MOVES",getWidth()*.5f,getHeight()*.58f,Color.rgb(116,239,255),27f));
        }else if(type==2){
            bombCount++;
            prefs.edit().putInt("bomb_inventory",bombCount).apply();
            floatingTexts.add(new FloatingText("+1 BOMB",getWidth()*.5f,getHeight()*.58f,Color.rgb(255,143,104),27f));
        }else if(type==3){
            rainbowCount++;
            prefs.edit().putInt("wild_inventory",rainbowCount).apply();
            floatingTexts.add(new FloatingText("+1 WILD",getWidth()*.5f,getHeight()*.58f,Color.rgb(210,135,255),27f));
        }else return;
        overlay=Overlay.NONE;rewardOfferType=0;
        audio.play(AudioEngine.FX_COIN,1f,1.05f);haptic(35);invalidate();
    }

    public void grantExternalCoins(int amount, String reason) {
        if (amount <= 0) return;
        if(reason!=null && reason.startsWith("REWARDED")){
        }
        coins += amount;
        prefs.edit().putInt("coins", coins).apply();
        audio.play(AudioEngine.FX_COIN, 1f, 1.05f);
        haptic(35);
        floatingTexts.add(new FloatingText(reason == null ? ("+" + amount + " COINS") : reason,
                getWidth() * .5f, getHeight() * .58f, Color.rgb(116, 239, 255), 24f));
        for (int i=0;i<22;i++) particles.add(new Particle(getWidth()*.5f,getHeight()*.60f,
                (random.nextFloat()-.5f)*420f,-random.nextFloat()*420f,Color.rgb(118,221,255),4f+random.nextFloat()*5f,.75f+random.nextFloat()*.5f));
        invalidate();
    }

    public boolean grantPurchasedCoinsSafely(int amount, String reason, String purchaseToken) {
        if (amount <= 0 || purchaseToken == null || purchaseToken.isEmpty()) return false;
        String tokenKey = "play_purchase_granted_" + purchaseToken;
        if (prefs.getBoolean(tokenKey, false)) return true;

        int newBalance = coins + amount;
        boolean saved = prefs.edit()
                .putInt("coins", newBalance)
                .putBoolean(tokenKey, true)
                .commit();
        if (!saved) return false;

        coins = newBalance;
        audio.play(AudioEngine.FX_COIN, 1f, 1.05f);
        haptic(35);
        floatingTexts.add(new FloatingText(reason == null ? ("+" + amount + " COINS") : reason,
                getWidth() * .5f, getHeight() * .58f, Color.rgb(116, 239, 255), 24f));
        for (int i=0;i<22;i++) particles.add(new Particle(getWidth()*.5f,getHeight()*.60f,
                (random.nextFloat()-.5f)*420f,-random.nextFloat()*420f,Color.rgb(118,221,255),4f+random.nextFloat()*5f,.75f+random.nextFloat()*.5f));
        invalidate();
        return true;
    }

    private int globalBestScore() {
        int best = 0;
        for (int i=1;i<=MAP_LEVELS;i++) best = Math.max(best, prefs.getInt("best_"+i,0));
        return best;
    }

    private int[][] localTopScores(int maxRows) {
        ArrayList<int[]> rows = new ArrayList<>();
        for (int i=1;i<=MAP_LEVELS;i++) {
            int score = prefs.getInt("best_"+i,0);
            if (score > 0) rows.add(new int[]{i,score});
        }
        Collections.sort(rows, (a,b) -> Integer.compare(b[1],a[1]));
        int n=Math.min(maxRows,rows.size());
        int[][] out=new int[n][2];
        for(int i=0;i<n;i++){out[i][0]=rows.get(i)[0];out[i][1]=rows.get(i)[1];}
        return out;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        bubbleR = Math.min(w / 20.2f, h / 35.2f);
        bubbleR = Math.max(20f, bubbleR);
        // Keep the first bubble row below the full HUD/objective area on tall and narrow phones.
        // Early levels lift the board upward, so a larger base gridTop is required to prevent
        // bubbles from covering LEVEL / SCORE / GOAL / COINS and the objective strip.
        gridTop = h * 0.155f;
        rowH = bubbleR * 1.72f;
        shooterX = w * 0.50f;
        // Higher shooter deck so the lower controls feel like the reference arcade layout.
        shooterY = h * 0.785f;
        dangerY = shooterY - bubbleR * 4.35f;
        try {
            buildBubbleSprites();
        } catch (Throwable t) {
            recycleSprites();
            bubbleSprites = new Bitmap[PALETTE.length];
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (renderError != null) {
            drawRenderRecovery(canvas);
            return;
        }
        try {
            if (screen == Screen.SPLASH && splashStarted == 0L) splashStarted = System.currentTimeMillis();
            long now = System.nanoTime();
            float dt = lastFrameNanos == 0L ? 0.016f : Math.min(0.04f, (now - lastFrameNanos) / 1_000_000_000f);
            lastFrameNanos = now;
            update(dt);

            boolean saved = false;
            if (screenShake > 0f && screen == Screen.GAME) {
                float tremor=(float)(Math.sin(ambientTime*92f)+0.55*Math.sin(ambientTime*137f));
                float sx = tremor * screenShake * .48f + (random.nextFloat()-0.5f)*screenShake*.32f;
                float sy = (float)(Math.cos(ambientTime*101f)-0.45*Math.sin(ambientTime*149f)) * screenShake * .36f + (random.nextFloat()-0.5f)*screenShake*.24f;
                canvas.save();
                saved = true;
                canvas.translate(sx, sy);
            }

            switch (screen) {
                case SPLASH: drawSplash(canvas); break;
                case HOME: drawHome(canvas); break;
                case MAP: drawMap(canvas); break;
                case GAME: drawGame(canvas); break;
            }

            if (saved) canvas.restore();
            if (overlay != Overlay.NONE) drawOverlay(canvas);
            MainActivity hst = host();
            boolean bannerNow = (screen == Screen.HOME && overlay == Overlay.NONE)
                    || (screen == Screen.MAP && overlay == Overlay.NONE)
                    || (screen == Screen.GAME && overlay == Overlay.NONE);
            if (hst != null && bannerNow != lastBannerVisible) { lastBannerVisible = bannerNow; hst.setBannerVisible(bannerNow); }
            postInvalidateOnAnimation();
        } catch (Throwable t) {
            renderError = t.getClass().getSimpleName() + (t.getMessage() == null ? "" : (": " + t.getMessage()));
            try { drawRenderRecovery(canvas); } catch (Throwable ignored) {}
        }
    }

    private void drawRenderRecovery(Canvas c) {
        c.drawColor(Color.rgb(45, 39, 112));
        paint.setShader(null);
        text.setShader(null);
        text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(Color.WHITE);
        text.setTextSize(24f);
        c.drawText("Bubble Realm Adventure Safe Mode", getWidth() * .5f, getHeight() * .42f, text);
        text.setTextSize(16f);
        c.drawText("The game stopped a device-specific graphics error.", getWidth() * .5f, getHeight() * .49f, text);
        String shortError = renderError == null ? "Unknown graphics error" : renderError;
        if (shortError.length() > 62) shortError = shortError.substring(0, 62);
        c.drawText(shortError, getWidth() * .5f, getHeight() * .55f, text);
        c.drawText("Send a screenshot of this screen to the developer.", getWidth() * .5f, getHeight() * .62f, text);
    }

    private void update(float dt) {
        float u=uiScale();
        ambientTime += dt;
        screenShake = Math.max(0f, screenShake - dt * 36f);
        float introBefore = levelIntroTimer;
        levelIntroTimer = Math.max(0f, levelIntroTimer - dt);
        introWasActive = levelIntroTimer > 0f;
        launcherPulse += dt;
        cannonFireTimer = Math.max(0f, cannonFireTimer - dt);
        cannonRecoil = Math.max(0f, cannonRecoil - dt * 4.8f);
        cannonBurstTimer = Math.max(0f, cannonBurstTimer - dt);
        if (introBefore > 0f && levelIntroTimer <= 0f) {
            audio.play(AudioEngine.FX_LEVEL_UP_CHIME, .72f, 1.12f);
            haptic(28);
            popFlash = Math.max(popFlash, .18f);
        }
        popFlash = Math.max(0f, popFlash - dt * 3.5f);
        impactTimer = Math.max(0f, impactTimer - dt);
        feverTimer = Math.max(0f, feverTimer - dt);
        feverBurst = Math.max(0f, feverBurst - dt * 2.8f);
        perfectShotTimer = Math.max(0f, perfectShotTimer - dt);
        portalCooldown = Math.max(0f, portalCooldown - dt);
        barrierCooldown = Math.max(0f, barrierCooldown - dt);
        companionPulse = Math.max(0f, companionPulse - dt * 1.6f);
        if (overlay == Overlay.WIN) {
            winCelebrationTimer += dt;
            int allowed=Math.max(0,Math.min(3,lastWinStars));
            if(winStarSoundStage<allowed){
                float nextAt=.18f+winStarSoundStage*.26f;
                if(winCelebrationTimer>=nextAt){
                    audio.play(AudioEngine.FX_STAR,.92f,1.02f+winStarSoundStage*.06f);
                    winStarSoundStage++;
                }
            }
        }
        if (overlay == Overlay.LOSE) loseCelebrationTimer += dt;
        praiseBannerTimer = Math.max(0f, praiseBannerTimer - dt);
        if (praiseBannerTimer <= 0f) praiseBannerText = null;
        rowDropTimer = Math.max(0f, rowDropTimer - dt);
        for (int i = rings.size() - 1; i >= 0; i--) {
            RingFx r = rings.get(i);
            r.life -= dt;
            r.radius += r.speed * dt;
            if (r.life <= 0f) rings.remove(i);
        }

        if (screen == Screen.SPLASH && System.currentTimeMillis() - splashStarted > SPLASH_DURATION_MS) {
            screen = Screen.HOME;
        }

        if (screen == Screen.GAME && overlay == Overlay.NONE && shotFlying) updateShot(dt);

        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.life -= dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += 420f * dt;
            p.vx *= (1f - Math.min(0.8f, dt * 1.8f));
            if (p.life <= 0f) particles.remove(i);
        }

        // Bound transient effects so large combo/celebration bursts cannot grow
        // the per-frame draw/update workload without limit on lower-memory phones.
        final int particleLimit = (screen == Screen.GAME ? 180 : 90);
        while (particles.size() > particleLimit) particles.remove(0);
        while (rings.size() > 36) rings.remove(0);
        // Keep a bounded debris history without starving subsequent matches.
        // Previously, after 800 settled shards accumulated, every newly spawned
        // airborne shard was immediately removed, so later 3+ matches looked empty.
        // Evict the oldest settled floor pieces FIRST, preserving fresh airborne
        // fragments and allowing every new match to show falling debris.
        final int shardLimit = 900;
        while (glassShards.size() > shardLimit) {
            int removable = -1;
            for (int j = 0; j < glassShards.size(); j++) {
                if (glassShards.get(j).settled) { removable = j; break; }
            }
            // Only if a huge single-frame explosion exceeds the limit.
            if (removable < 0) removable = 0;
            glassShards.remove(removable);
        }

        for (int i = glassShards.size() - 1; i >= 0; i--) {
            GlassShard q = glassShards.get(i);
            if(!q.settled){
                q.life -= dt;
                q.x += q.vx * dt;
                q.y += q.vy * dt;
                q.vy += (q.concrete ? 1320f : 820f) * dt;
                q.vx *= (1f - Math.min(0.48f, dt * (q.concrete ? 1.18f : 1.05f)));
                q.rot += q.vr * dt;
                // Debris is physical and remains visible after reaching the bottom.
                // It gets one or two short bounces, then settles on the floor instead
                // of fading away while still airborne.
                float floorY=getHeight()-12f*u;
                debrisFloorY=floorY;
                // The bottom edge of every chunk lands on the same single surface.
                // Do not stack chunks on earlier chunks and do not keep an old floor
                // when the banner ad changes the game-view height.
                float bottomOffset=q.concrete?q.h*.62f:q.h*.46f;
                if(q.y+bottomOffset >= floorY){
                    q.y=floorY-bottomOffset;
                    if(Math.abs(q.vy)>105f){
                        q.vy=-q.vy*(q.concrete?.22f:.28f);
                        q.vx*=.68f;
                        q.vr*=.68f;
                    }else{
                        q.vy=0f;
                        q.vx*=.35f;
                        q.vr*=.35f;
                        q.settled=true;
                        q.life=9999f;
                        q.maxLife=9999f;
                    }
                }
            } else {
                // Keep all settled pieces attached to the current, single floor.
                // This also removes the old two-surface artifact after banner resize.
                float floorY=getHeight()-12f*u;
                debrisFloorY=floorY;
                float bottomOffset=q.concrete?q.h*.62f:q.h*.46f;
                q.y=floorY-bottomOffset;
                q.vy=0f;
                q.vx*=.92f;
                q.vr*=.92f;
                // Never delete a chunk just because its flight timer expired.
                // Once it is on the floor it remains until the level clears/resets.
                if(q.life<=0f){
                    q.life=9999f;
                    q.maxLife=9999f;
                    q.settled=true;
                }
            }
        }

        for (int i = falling.size() - 1; i >= 0; i--) {
            FallingBubble f = falling.get(i);
            f.vy += 900f * dt;
            f.x += f.vx * dt;
            f.y += f.vy * dt;
            f.rot += f.vr * dt;
            if (f.y > getHeight() + bubbleR * 3f) falling.remove(i);
        }

        for (int i = floatingTexts.size() - 1; i >= 0; i--) {
            FloatingText ft = floatingTexts.get(i);
            ft.life -= dt;
            ft.y -= 52f * dt;
            if (ft.life <= 0f) floatingTexts.remove(i);
        }
    }

    // ---------------------------------------------------------------
    // Drawing: shared visual system
    // ---------------------------------------------------------------

    private void drawAuroraBackground(Canvas c, int top, int bottom) {
        float w = getWidth(), h = getHeight();
        paint.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        paint.setColor(Color.argb(24, 255, 255, 255));
        c.drawOval(new RectF(-w * .20f, h * .11f, w * .58f, h * .31f), paint);
        c.drawOval(new RectF(w * .38f, h * .25f, w * 1.10f, h * .48f), paint);
        c.drawOval(new RectF(-w * .06f, h * .57f, w * .90f, h * .84f), paint);

        paint.setColor(Color.argb(18, 255, 255, 255));
        c.drawOval(new RectF(w * .16f, h * .46f, w * 1.12f, h * .68f), paint);
        c.drawOval(new RectF(-w * .28f, h * .78f, w * .44f, h * .98f), paint);

        paint.setColor(Color.argb(28, 118, 226, 255));
        c.drawCircle(w * .16f + (float) Math.sin(ambientTime * .28f) * 20f, h * .18f, w * .21f, paint);
        paint.setColor(Color.argb(22, 255, 140, 232));
        c.drawCircle(w * .81f + (float) Math.cos(ambientTime * .24f) * 18f, h * .32f, w * .18f, paint);
        paint.setColor(Color.argb(18, 255, 219, 82));
        c.drawCircle(w * .72f, h * .76f, w * .22f, paint);

        for (int i = 0; i < starX.length; i++) {
            float pulse = 0.45f + 0.55f * (0.5f + 0.5f * (float) Math.sin(ambientTime * 1.35f + starPhase[i]));
            paint.setColor(Color.argb((int) (135 * pulse), 255, 255, 255));
            float r = 1.1f + 2.4f * pulse;
            c.drawCircle(starX[i] * w, starY[i] * h, r, paint);
        }
    }

    private void roundedGradient(Canvas c, RectF r, float radius, int start, int end) {
        paint.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom, start, end, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, paint);
        paint.setShader(null);
    }

    private void card(Canvas c, RectF r, float radius, int fill) {
        paint.setColor(Color.argb(70, 0, 0, 0));
        c.drawRoundRect(new RectF(r.left, r.top + 7f, r.right, r.bottom + 7f), radius, radius, paint);
        paint.setColor(fill);
        c.drawRoundRect(r, radius, radius, paint);
        stroke.setStrokeWidth(2f);
        stroke.setColor(Color.argb(120, 255, 255, 255));
        c.drawRoundRect(r, radius, radius, stroke);
    }

    private void label(Canvas c, String s, float x, float y, float size, int color) {
        text.setShader(null);
        text.setTextSize(size * 1.06f);
        text.setTypeface(android.graphics.Typeface.create(size >= 18f ? "sans-serif-black" : "sans-serif-medium", android.graphics.Typeface.BOLD));
        text.setShadowLayer(Math.max(1.2f, size * .065f), 0f, Math.max(1f, size * .035f), Color.argb(155, 12, 18, 66));
        text.setColor(color);
        text.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, text);
        text.clearShadowLayer();
    }

    private void labelLeft(Canvas c, String s, float x, float y, float size, int color) {
        text.setShader(null);
        text.setTextSize(size * 1.05f);
        text.setTypeface(android.graphics.Typeface.create(size >= 20f ? "sans-serif-black" : "sans-serif-medium", android.graphics.Typeface.BOLD));
        text.setShadowLayer(Math.max(1.1f, size * .06f), 0f, Math.max(0.8f, size * .03f), Color.argb(115, 18, 24, 72));
        text.setColor(color);
        text.setTextAlign(Paint.Align.LEFT);
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, text);
        text.clearShadowLayer();
        text.setTextAlign(Paint.Align.CENTER);
    }

    // Shared outlined text renderer used by special gameplay banners and bubbles.
    private void labelOutline(Canvas c, String s, float x, float y, float size, int fill, int outline) {
        text.setShader(null);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD));
        text.setTextSize(size);
        Paint.FontMetrics fm = text.getFontMetrics();
        float baseline = y - (fm.ascent + fm.descent) / 2f;

        Paint.Style oldStyle = text.getStyle();
        float oldStrokeWidth = text.getStrokeWidth();

        text.setStyle(Paint.Style.STROKE);
        text.setStrokeWidth(Math.max(3f, size * .12f));
        text.setColor(outline);
        text.setShadowLayer(Math.max(2f, size * .09f), 0f, Math.max(1f, size * .06f), Color.argb(150, 0, 0, 0));
        c.drawText(s, x, baseline, text);
        text.clearShadowLayer();

        text.setStyle(Paint.Style.FILL);
        text.setColor(fill);
        c.drawText(s, x, baseline, text);

        text.setStyle(oldStyle);
        text.setStrokeWidth(oldStrokeWidth);
    }

    private void button(Canvas c, RectF r, String title, int top, int bottom) {
        float u=uiScale();
        float rad=Math.min(23f*u,r.height()*.38f);
        float pulse=.5f+.5f*(float)Math.sin(ambientTime*2.65f+r.centerY()*.011f);
        // Soft glow stays OUTSIDE the button but does not create a raised lip above it.
        stroke.setStrokeWidth((4.2f+1.4f*pulse)*u);
        stroke.setColor(Color.argb((int)(30+30*pulse),Color.red(top),Color.green(top),Color.blue(top)));
        c.drawRoundRect(new RectF(r.left-2f*u,r.top-2f*u,r.right+2f*u,r.bottom+2f*u),rad+2f*u,rad+2f*u,stroke);
        paint.setColor(Color.argb(112,7,12,45));
        c.drawRoundRect(new RectF(r.left+1f*u,r.top+7f*u,r.right+1f*u,r.bottom+7f*u),rad,rad,paint);
        stroke.setStrokeWidth(3.2f*u);stroke.setColor(Color.argb(235,231,246,255));
        c.drawRoundRect(new RectF(r.left-1f*u,r.top-1f*u,r.right+1f*u,r.bottom+1f*u),rad+1f*u,rad+1f*u,stroke);
        roundedGradient(c,r,rad,top,bottom);
        // Contained glass highlight: clipped inside the real button bounds.
        c.save();Path clip=new Path();clip.addRoundRect(r,rad,rad,Path.Direction.CW);c.clipPath(clip);
        paint.setShader(new LinearGradient(0,r.top,0,r.centerY(),Color.argb(138,255,255,255),Color.argb(8,255,255,255),Shader.TileMode.CLAMP));
        c.drawRect(r.left+3f*u,r.top+3f*u,r.right-3f*u,r.centerY(),paint);paint.setShader(null);
        paint.setColor(Color.argb(52,0,0,0));c.drawRect(r.left+5f*u,r.bottom-r.height()*.17f,r.right-5f*u,r.bottom-3f*u,paint);
        float sweep=((ambientTime*.24f)%1f);float sx=r.left-r.width()*.22f+sweep*r.width()*1.44f;
        Path shine=new Path();shine.moveTo(sx-r.width()*.10f,r.top);shine.lineTo(sx+r.width()*.02f,r.top);shine.lineTo(sx+r.width()*.17f,r.bottom);shine.lineTo(sx+r.width()*.05f,r.bottom);shine.close();
        paint.setColor(Color.argb(34,255,255,255));c.drawPath(shine,paint);c.restore();
        stroke.setStrokeWidth(1.25f*u);stroke.setColor(Color.argb(125,4,13,54));
        c.drawRoundRect(new RectF(r.left+3f*u,r.top+3f*u,r.right-3f*u,r.bottom-3f*u),rad*.87f,rad*.87f,stroke);
        // Tiny moving edge spark gives a premium arcade-button effect.
        float sparkX=r.left+rad+(r.width()-2f*rad)*sweep;
        paint.setColor(Color.argb((int)(100+95*pulse),255,255,255));c.drawCircle(sparkX,r.top+2.5f*u,(1.4f+1.1f*pulse)*u,paint);
        label(c,title,r.centerX(),r.centerY()-1f*u,Math.min(21.5f*u,r.height()*.41f),Color.WHITE);
    }

    private void iconCircle(Canvas c, float x, float y, float r, String glyph, int start, int end) {
        float u=uiScale();
        // Clean arcade icon: solid depth + rim, intentionally no glass/white glare overlay.
        paint.setColor(Color.argb(105,5,10,42));
        c.drawCircle(x,y+4f*u,r+1.5f*u,paint);
        paint.setShader(new LinearGradient(x,y-r,x,y+r,lighten(start,.16f),darken(end,.08f),Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,paint);
        paint.setShader(null);
        stroke.setStrokeWidth(3.2f*u);stroke.setColor(Color.rgb(224,239,255));c.drawCircle(x,y,r,stroke);
        stroke.setStrokeWidth(1.2f*u);stroke.setColor(Color.argb(135,12,25,73));c.drawCircle(x,y,r-3f*u,stroke);
        label(c,glyph,x,y,r*.98f,Color.WHITE);
    }

    private int lighten(int color, float amount) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        r += (int)((255 - r) * amount);
        g += (int)((255 - g) * amount);
        b += (int)((255 - b) * amount);
        return Color.rgb(clamp255(r), clamp255(g), clamp255(b));
    }

    private int darken(int color, float amount) {
        return Color.rgb((int)(Color.red(color) * (1f - amount)),
                (int)(Color.green(color) * (1f - amount)),
                (int)(Color.blue(color) * (1f - amount)));
    }

    private int clamp255(int v) { return Math.max(0, Math.min(255, v)); }

    // ---------------------------------------------------------------
    // Splash / Home
    // ---------------------------------------------------------------

    private void drawSplash(Canvas c) {
        drawStartupWallpaper(c,splashLiveThemeLevel);
        drawRealmAtmosphere(c,splashLiveThemeLevel,1.0f);
        float w=getWidth(),h=getHeight(),u=uiScale();
        paint.setShader(new LinearGradient(0,0,0,h,Color.argb(76,12,8,72),Color.argb(20,10,48,124),Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
        long elapsed=System.currentTimeMillis()-splashStarted;
        float intro=clamp01(elapsed/1050f);
        float enter=.62f+.38f*easeOutBack(intro);
        float drift=(float)Math.sin(ambientTime*.75f)*14f*u;
        drawBubbleSprite(c,4,w*.10f,h*.13f+drift,w*.096f);drawBubbleSprite(c,0,w*.86f,h*.10f-drift*.45f,w*.082f);
        drawBubbleSprite(c,1,w*.93f,h*.31f+drift*.22f,w*.060f);drawBubbleSprite(c,3,w*.07f,h*.44f-drift*.25f,w*.052f);
        // extra foreground bubble stream
        for(int i=0;i<6;i++){
            float ph=ambientTime*(.09f+i*.009f)+i*.82f;
            float bx=((i*.137f)+ambientTime*.004f*(1+i%2))%1.15f*w-w*.07f;
            float by=h*(.18f+((i*13)%58)/100f)+(float)Math.sin(ph)*h*.025f;
            drawBubbleSprite(c,(i+startupThemeLevel)%PALETTE.length,bx,by,w*(.018f+(i%3)*.008f));
        }
        float pulse=1f+.055f*(float)Math.sin(ambientTime*3.1f);
        c.save();c.rotate((1f-intro)*-5f,w*.5f,h*.285f);c.scale(enter*pulse,enter*pulse,w*.5f,h*.285f);drawLogo(c,w*.5f,h*.275f,w*.99f);c.restore();
        for(int i=0;i<14;i++){float a=ambientTime*.82f+i*.4488f;float rr=w*(.35f+(i%3)*.026f);float sx=w*.5f+(float)Math.cos(a)*rr;float sy=h*.30f+(float)Math.sin(a)*h*.125f;float tw=.5f+.5f*(float)Math.sin(ambientTime*2.6f+i);paint.setColor(Color.argb((int)(58+108*tw),255,255,255));c.drawCircle(sx,sy,(1.2f+(i%3)*.8f)*u,paint);}
        labelOutline(c,"MATCH, POP & SHINE!",w*.5f,h*.480f,27f*u,Color.WHITE,Color.rgb(42,38,112));
        labelOutline(c,"1000 LEVELS • TREASURES • BOSSES",w*.5f,h*.520f,15.5f*u,Color.rgb(246,250,255),Color.rgb(52,61,128));
        float p=Math.min(1f,elapsed/(float)SPLASH_DURATION_MS);
        RectF outer=new RectF(w*.13f,h*.755f,w*.87f,h*.827f);paint.setColor(Color.argb(175,10,12,62));c.drawRoundRect(new RectF(outer.left,outer.top+7f*u,outer.right,outer.bottom+7f*u),24f*u,24f*u,paint);stroke.setStrokeWidth(3f*u);stroke.setColor(Color.argb(220,224,243,255));c.drawRoundRect(outer,24f*u,24f*u,stroke);
        RectF inner=new RectF(outer.left+6f*u,outer.top+6f*u,outer.right-6f*u,outer.bottom-6f*u);paint.setColor(Color.rgb(31,29,91));c.drawRoundRect(inner,18f*u,18f*u,paint);
        if(p>0f){RectF fill=new RectF(inner.left,inner.top,inner.left+inner.width()*p,inner.bottom);roundedGradient(c,fill,18f*u,Color.rgb(72,202,255),Color.rgb(184,65,241));paint.setColor(Color.argb(95,255,255,255));c.drawRoundRect(new RectF(fill.left+2f*u,fill.top+2f*u,fill.right-2f*u,fill.centerY()),16f*u,16f*u,paint);float glowX=fill.right;paint.setShader(new RadialGradient(glowX,fill.centerY(),18f*u,Color.argb(150,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(glowX,fill.centerY(),18f*u,paint);paint.setShader(null);}
        labelOutline(c,(int)(p*100)+"%",outer.centerX(),outer.centerY(),24f*u,Color.WHITE,Color.rgb(38,36,105));
        labelOutline(c,"LOADING...",w*.5f,h*.875f,20.5f*u,Color.WHITE,Color.rgb(52,48,119));
    }

    private void drawLogo(Canvas c, float cx, float cy, float width) {
        float r=width*.103f;
        float bob=(float)Math.sin(ambientTime*1.25f)*r*.055f;
        float halo=.55f+.45f*(float)Math.sin(ambientTime*2.0f);
        paint.setShader(new RadialGradient(cx,cy+r*.10f,width*.58f,
                Color.argb((int)(34+28*halo),105,203,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(cx,cy+r*.10f,width*.58f,paint);paint.setShader(null);
        // Slow orbit sparks around the title.
        for(int i=0;i<10;i++){
            float a=ambientTime*.42f+i*.6283f;
            float ox=cx+(float)Math.cos(a)*width*.47f;
            float oy=cy+r*.25f+(float)Math.sin(a)*r*1.15f;
            float tw=.5f+.5f*(float)Math.sin(ambientTime*3f+i);
            paint.setColor(Color.argb((int)(65+85*tw),255,247,205));
            c.drawCircle(ox,oy,(1.2f+1.4f*tw)*uiScale(),paint);
        }
        drawBubbleSprite(c,0,cx-width*.39f,cy-r*.10f+bob,r*.62f);
        drawBubbleSprite(c,1,cx-width*.28f,cy-r*.84f-bob,r*.50f);
        drawBubbleSprite(c,3,cx+width*.37f,cy-r*.60f+bob*.5f,r*.47f);
        drawBubbleSprite(c,4,cx+width*.30f,cy+r*.22f-bob*.4f,r*.52f);
        drawBubbleSprite(c,2,cx+width*.17f,cy-r*.78f+bob*.4f,r*.41f);

        // Removed the blue plaque behind the title and replaced it with a soft glow,
        // so the logo feels more open and 3D over the live wallpaper.
        paint.setShader(new RadialGradient(cx,cy+r*.34f,width*.46f,
                Color.argb(82,18,12,58),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawOval(new RectF(cx-width*.46f,cy-r*.02f,cx+width*.46f,cy+r*1.65f),paint);
        paint.setShader(null);

        // Independently rendered high-resolution glossy lettering inspired by the launcher icon.
        // No text pixels are cut from or pasted out of the launcher icon.
        if (logoWordmark != null && !logoWordmark.isRecycled()) {
            float logoW = width * .70f;
            float logoH = logoW * logoWordmark.getHeight() / (float) logoWordmark.getWidth();
            float logoCenterY = cy + width * .060f;
            RectF logoRect = new RectF(cx-logoW*.5f, logoCenterY-logoH*.5f,
                    cx+logoW*.5f, logoCenterY+logoH*.5f);
            c.drawBitmap(logoWordmark, null, logoRect, bubbleBitmapPaint);
        } else {
            // Safe fallback if bitmap decoding fails.
            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(android.graphics.Typeface.create("serif",android.graphics.Typeface.BOLD));
            text.setFakeBoldText(true);
            text.setTextSize(width*.20f);
            text.setColor(Color.WHITE);
            text.setShadowLayer(r*.16f,0,r*.08f,Color.rgb(12,18,70));
            c.drawText("Bubble",cx,cy,text);
            text.setTextSize(width*.18f);
            text.setColor(Color.rgb(255,190,38));
            c.drawText("Realm",cx,cy+r*.92f,text);
            text.clearShadowLayer();
            text.setFakeBoldText(false);
        }
    }

    private void drawHome(Canvas c) {
        audio.setMusicTheme(12);drawStartupWallpaper(c,homeLiveThemeLevel);
        drawRealmAtmosphere(c,homeLiveThemeLevel,1.15f);
        float w=getWidth(),h=getHeight(),u=uiScale();
        paint.setColor(Color.argb(18,8,8,70));c.drawRect(0,0,w,h,paint);
        // Home-specific parallax foreground, independent of the base wallpaper.
        for(int i=0;i<7;i++){
            float ph=ambientTime*(.10f+i*.007f)+i*.73f;
            float bx=((i*.121f)+ambientTime*.0032f*(1+i%3))%1.13f*w-w*.06f;
            float by=h*(.10f+((i*17)%70)/100f)+(float)Math.cos(ph)*h*.03f;
            float br=w*(.014f+(i%4)*.007f);
            int bc=PALETTE[(i+worldIndex(startupThemeLevel))%PALETTE.length];
            paint.setShader(new RadialGradient(bx-br*.30f,by-br*.34f,br*1.4f,Color.argb(76,255,255,255),Color.argb(28,Color.red(bc),Color.green(bc),Color.blue(bc)),Shader.TileMode.CLAMP));c.drawCircle(bx,by,br,paint);paint.setShader(null);
        }
        drawTopCurrency(c);
        float bob=(float)Math.sin(ambientTime*.85f)*8f*u;
        drawBubbleSprite(c,0,w*.06f,h*.18f+bob,w*.072f);drawBubbleSprite(c,1,w*.95f,h*.20f-bob*.45f,w*.063f);
        drawBubbleSprite(c,2,w*.84f,h*.35f+bob*.28f,w*.053f);drawBubbleSprite(c,4,w*.14f,h*.36f-bob*.22f,w*.055f);
        float homePulse=1f+.025f*(float)Math.sin(ambientTime*2.2f);
        c.save();c.scale(homePulse,homePulse,w*.5f,h*.19f);drawLogo(c,w*.5f,h*.190f,w*.98f);c.restore();
        RectF tagline=new RectF(w*.10f,h*.320f,w*.635f,h*.365f);paint.setColor(Color.argb(120,35,35,108));c.drawRoundRect(tagline,18f*u,18f*u,paint);stroke.setStrokeWidth(1.4f*u);stroke.setColor(Color.argb(150,219,243,255));c.drawRoundRect(tagline,18f*u,18f*u,stroke);label(c,"ADVENTURE • BOSSES • REWARDS",tagline.centerX(),tagline.centerY(),14.2f*u,Color.WHITE);
        RectF survivalBtn=new RectF(w*.655f,h*.320f,w*.91f,h*.365f);button(c,survivalBtn,"SURVIVAL",Color.rgb(255,116,74),Color.rgb(165,49,94));
        boolean resume=hasContinueOption();
        if(resume){
            button(c,new RectF(w*.11f,h*.382f,w*.89f,h*.462f),"CONTINUE • LEVEL "+continueLevel(),Color.rgb(117,226,78),Color.rgb(35,155,19));
            button(c,new RectF(w*.13f,h*.490f,w*.87f,h*.565f),"PLAY LEVELS",Color.rgb(74,198,255),Color.rgb(38,96,209));
            button(c,new RectF(w*.16f,h*.590f,w*.84f,h*.660f),isDailyChallengeClaimed()?"DAILY CHALLENGE ✓":"DAILY CHALLENGE",Color.rgb(199,91,249),Color.rgb(102,42,183));
            button(c,new RectF(w*.16f,h*.680f,w*.84f,h*.750f),isDailyGiftClaimed()?"DAILY GIFT ✓":"DAILY GIFT +"+DAILY_COIN_REWARD,Color.rgb(255,188,49),Color.rgb(236,99,18));
            button(c,new RectF(w*.16f,h*.758f,w*.84f,h*.828f),"WATCH AD +7 COINS",Color.rgb(178,94,244),Color.rgb(92,51,188));
        }else{
            button(c,new RectF(w*.12f,h*.425f,w*.88f,h*.510f),"PLAY LEVELS",Color.rgb(117,226,78),Color.rgb(35,155,19));
            button(c,new RectF(w*.15f,h*.535f,w*.85f,h*.613f),isDailyChallengeClaimed()?"DAILY CHALLENGE ✓":"DAILY CHALLENGE",Color.rgb(74,198,255),Color.rgb(38,96,209));
            button(c,new RectF(w*.15f,h*.635f,w*.85f,h*.713f),isDailyGiftClaimed()?"DAILY GIFT ✓":"DAILY GIFT +"+DAILY_COIN_REWARD,Color.rgb(255,188,49),Color.rgb(236,99,18));
            button(c,new RectF(w*.15f,h*.720f,w*.85f,h*.798f),"WATCH AD +7 COINS",Color.rgb(178,94,244),Color.rgb(92,51,188));
        }
        float ir=w*.060f;
        iconCircle(c,w*.12f,h*.870f,ir,"?",Color.rgb(52,214,222),Color.rgb(24,117,165));
        iconCircle(c,w*.38f,h*.870f,ir,"★",Color.rgb(236,92,196),Color.rgb(142,39,137));
        iconCircle(c,w*.62f,h*.870f,ir,"¢",Color.rgb(116,222,80),Color.rgb(39,145,48));
        iconCircle(c,w*.88f,h*.870f,ir,"⚙",Color.rgb(70,171,255),Color.rgb(42,72,190));
        label(c,"HELP",w*.12f,h*.920f,13.8f*u,Color.WHITE);label(c,"SCORES",w*.38f,h*.920f,13.8f*u,Color.WHITE);label(c,"COIN SHOP",w*.62f,h*.920f,13.8f*u,Color.WHITE);label(c,"SETTINGS",w*.88f,h*.920f,13.8f*u,Color.WHITE);
        button(c,new RectF(w*.32f,h*.945f,w*.68f,h*.985f),"EXIT",Color.rgb(244,119,88),Color.rgb(167,56,64));
        drawLooseFx(c);
    }

    private void drawLooseFx(Canvas c) {
        for (Particle p : particles) {
            float alpha = Math.max(0f, Math.min(1f, p.life / p.maxLife));
            paint.setColor((p.color & 0x00FFFFFF) | ((int)(alpha * 255) << 24));
            c.drawCircle(p.x, p.y, p.size * (.55f + .45f * alpha), paint);
        }
        for (FloatingText ft : floatingTexts) {
            int a = (int)(255 * Math.min(1f, ft.life / .35f));
            label(c, ft.text, ft.x, ft.y, ft.size, (ft.color & 0x00FFFFFF) | (a << 24));
        }
    }

    private void drawTopCurrency(Canvas c) {
        float w=getWidth(),u=uiScale();
        RectF coinCard=new RectF(w*.025f,8f*u,w*.365f,57f*u),starCard=new RectF(w*.635f,8f*u,w*.975f,57f*u);
        for(RectF card:new RectF[]{coinCard,starCard}){
            paint.setColor(Color.rgb(35,39,105));
            c.drawRoundRect(card,20f*u,20f*u,paint);
            stroke.setStrokeWidth(2.4f*u);stroke.setColor(Color.rgb(224,239,255));c.drawRoundRect(card,20f*u,20f*u,stroke);
            stroke.setStrokeWidth(1.1f*u);stroke.setColor(Color.rgb(76,88,172));
            c.drawRoundRect(new RectF(card.left+4f*u,card.top+4f*u,card.right-4f*u,card.bottom-4f*u),16f*u,16f*u,stroke);
        }
        float coinX=coinCard.left+23f*u, cy=coinCard.centerY();
        paint.setColor(Color.rgb(246,190,42));c.drawCircle(coinX,cy,14f*u,paint);
        stroke.setStrokeWidth(1.5f*u);stroke.setColor(Color.rgb(151,96,18));c.drawCircle(coinX,cy,14f*u,stroke);
        label(c,"¢",coinX,cy,15f*u,Color.WHITE);
        drawStar(c,starCard.left+23f*u,starCard.centerY(),14f*u,Color.rgb(255,218,57));
        label(c,String.valueOf(coins),coinCard.centerX()+12f*u,coinCard.centerY(),19f*u,Color.WHITE);
        label(c,String.valueOf(totalStars),starCard.centerX()+12f*u,starCard.centerY(),19f*u,Color.WHITE);
        if(relicCount>0){
            RectF relic=new RectF(w*.405f,13f*u,w*.595f,52f*u);roundedGradient(c,relic,15f*u,Color.rgb(111,71,196),Color.rgb(52,55,142));
            drawStar(c,relic.left+18f*u,relic.centerY(),10f*u,Color.rgb(121,239,255));label(c,"RELIC "+relicCount,relic.centerX()+10f*u,relic.centerY(),11f*u,Color.WHITE);
        }
        for(RectF card:new RectF[]{coinCard,starCard}){
            float px=card.right-20f*u,py=card.centerY();
            paint.setColor(Color.rgb(78,192,78));c.drawCircle(px,py,13f*u,paint);
            stroke.setStrokeWidth(1.3f*u);stroke.setColor(Color.rgb(38,116,52));c.drawCircle(px,py,13f*u,stroke);
            label(c,"+",px,py,16f*u,Color.WHITE);
        }
    }

    // ---------------------------------------------------------------
    // Level map
    // ---------------------------------------------------------------

    private void drawMap(Canvas c) {
        audio.setMusicTheme(12);
        int focusLevel=Math.max(1,Math.min(MAP_LEVELS,Math.round(mapFocusLevelFloat())));
        int mapWorld=worldIndex(focusLevel);
        drawMapScrollWallpaper(c);
        drawRealmAtmosphere(c,focusLevel,0.88f);
        paint.setColor(Color.argb(15,55,35,125));c.drawRect(0,0,getWidth(),getHeight(),paint);
        float w=getWidth(),h=getHeight(),u=uiScale();
        paint.setColor(Color.argb(30,255,255,255));for(int i=0;i<7;i++){float yy=h*.12f+i*h*.15f+(mapScroll%(h*.17f));c.drawOval(new RectF(-w*.18f,yy,w*.78f,yy+w*.26f),paint);}
        paint.setShader(new RadialGradient(w*.82f,h*.28f,w*.34f,Color.argb(38,255,151,226),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(w*.82f,h*.28f,w*.34f,paint);paint.setShader(null);
        drawTopCurrency(c);
        iconCircle(c,w*.09f,66f*u,34f*u,"‹",Color.rgb(72,194,255),Color.rgb(48,71,195));
        iconCircle(c,w*.91f,66f*u,34f*u,"⚙",Color.rgb(72,194,255),Color.rgb(48,71,195));
        RectF mission=new RectF(w*.13f,51f*u,w*.87f,116f*u);roundedGradient(c,mission,18f*u,Color.rgb(57,61,150),Color.rgb(27,32,94));stroke.setStrokeWidth(2f*u);stroke.setColor(Color.argb(190,222,242,255));c.drawRoundRect(mission,18f*u,18f*u,stroke);
        int chestBase=(totalStars/30)*30;int need=chestBase+30;float prog=Math.min(1f,(totalStars-chestBase)/30f);
        label(c,"NEXT MEGA CHEST • "+need+" STARS",mission.centerX(),mission.top+18f*u,14f*u,Color.WHITE);
        RectF pbg=new RectF(mission.left+28f*u,mission.top+38f*u,mission.right-28f*u,mission.top+54f*u);paint.setColor(Color.rgb(116,124,169));c.drawRoundRect(pbg,8f*u,8f*u,paint);
        RectF pfg=new RectF(pbg.left,pbg.top,pbg.left+pbg.width()*prog,pbg.bottom);roundedGradient(c,pfg,8f*u,Color.rgb(255,190,47),Color.rgb(255,93,69));label(c,(totalStars-chestBase)+"/30",mission.centerX(),mission.top+46f*u,10f*u,Color.WHITE);

        Path path=new Path();boolean started=false;
        for(int level=1;level<=MAP_LEVELS;level++){PointF q=mapNode(level);if(q.y<104f*u||q.y>h+80f*u)continue;if(!started){path.moveTo(q.x,q.y);started=true;}else path.lineTo(q.x,q.y);}
        // v3.3: turn the level route into a real adventure road instead of a glowing ribbon.
        // Layered strokes create shadow -> shoulder -> white edge -> asphalt, while dashed yellow
        // center markings and animated reflectors make the route read as a road even on busy live scenes.
        if(started){
            stroke.setStrokeWidth(w*.235f);stroke.setColor(Color.argb(72,10,13,34));c.drawPath(path,stroke);
            stroke.setStrokeWidth(w*.195f);stroke.setColor(Color.argb(238,112,104,113));c.drawPath(path,stroke);
            stroke.setStrokeWidth(w*.174f);stroke.setColor(Color.argb(245,237,239,245));c.drawPath(path,stroke);
            stroke.setStrokeWidth(w*.150f);stroke.setColor(Color.argb(255,55,61,75));c.drawPath(path,stroke);
            stroke.setStrokeWidth(w*.123f);stroke.setColor(Color.argb(255,64,71,87));c.drawPath(path,stroke);
        }
        for(int level=1;level<MAP_LEVELS;level++){
            PointF a=mapNode(level),b=mapNode(level+1);
            if(a.y<105f*u||a.y>h+60f*u||b.y<105f*u||b.y>h+60f*u)continue;
            // Broken yellow center line.
            for(int d=0;d<5;d++){
                float t0=.08f+d*.19f,t1=Math.min(.92f,t0+.095f);
                float x0=a.x+(b.x-a.x)*t0,y0=a.y+(b.y-a.y)*t0;
                float x1=a.x+(b.x-a.x)*t1,y1=a.y+(b.y-a.y)*t1;
                stroke.setStrokeWidth(3.2f*u);stroke.setColor(Color.argb(230,255,205,66));c.drawLine(x0,y0,x1,y1,stroke);
            }
            // Roadside reflector studs pulse softly.
            float dx=b.x-a.x,dy=b.y-a.y,len=(float)Math.sqrt(dx*dx+dy*dy);
            if(len>1f){
                float px=-dy/len,py=dx/len;
                for(int d=1;d<=3;d++){
                    float t=d/4f,cx=a.x+dx*t,cy=a.y+dy*t;
                    float side=w*.078f;
                    float tw=.55f+.45f*(float)Math.sin(ambientTime*3.2f+level*.28f+d);
                    paint.setColor(Color.argb((int)(125+85*tw),235,248,255));
                    c.drawCircle(cx+px*side,cy+py*side,2.2f*u,paint);
                    c.drawCircle(cx-px*side,cy-py*side,2.2f*u,paint);
                }
            }
        }
        // Animated light beads travel through the visible map route.
        int sparkBase=Math.max(1,focusLevel-5);
        for(int sp=0;sp<7;sp++){
            int lv=Math.min(MAP_LEVELS-1,sparkBase+sp*2);PointF a=mapNode(lv),b=mapNode(lv+1);
            if(a.y<100f*u||a.y>h+65f*u||b.y<100f*u||b.y>h+65f*u)continue;
            float tt=(ambientTime*(.22f+sp*.012f)+sp*.137f)%1f;
            float x=a.x+(b.x-a.x)*tt,y=a.y+(b.y-a.y)*tt;
            paint.setShader(new RadialGradient(x,y,11f*u,Color.argb(180,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x,y,11f*u,paint);paint.setShader(null);
            paint.setColor(Color.argb(225,255,234,117));c.drawCircle(x,y,2.6f*u,paint);
        }

        for(int level=MAP_LEVELS;level>=1;level--){
            PointF q=mapNode(level);if(q.y<108f*u||q.y>h+52f*u)continue;boolean unlocked=level<=maxUnlocked,current=level==maxUnlocked;int stars=prefs.getInt("stars_"+level,0);boolean completed=stars>0;float pulse=current?1f+.07f*(float)Math.sin(ambientTime*4.5f):1f;float r=(current?34f:29f)*u*pulse;
            if(current){
                float hp=.5f+.5f*(float)Math.sin(ambientTime*4.2f);
                stroke.setStrokeWidth((3f+2f*hp)*u);stroke.setColor(Color.argb((int)(80+80*hp),143,239,255));
                c.drawCircle(q.x,q.y,r+12f*u+4f*u*hp,stroke);
            } else if(completed && level%5==0){
                stroke.setStrokeWidth(2f*u);stroke.setColor(Color.argb(65,255,220,79));
                c.drawCircle(q.x,q.y,r+8f*u,stroke);
            }
            paint.setColor(Color.argb(105,0,0,0));c.drawCircle(q.x,q.y+6f*u,r+3f*u,paint);
            if(unlocked){
                int col=completed?Color.rgb(66,216,134):themeAccent(level);
                paint.setShader(new RadialGradient(q.x-r*.34f,q.y-r*.42f,r*1.65f,new int[]{Color.WHITE,lighten(col,.58f),col,darken(col,.48f)},new float[]{0f,.12f,.62f,1f},Shader.TileMode.CLAMP));c.drawCircle(q.x,q.y,r,paint);paint.setShader(null);
                if(completed){stroke.setStrokeWidth(5f*u);stroke.setColor(Color.argb(92,255,233,120));c.drawCircle(q.x,q.y,r+4f*u,stroke);}
                paint.setColor(Color.argb(115,255,255,255));c.drawOval(new RectF(q.x-r*.58f,q.y-r*.72f,q.x+r*.08f,q.y-r*.20f),paint);
                stroke.setStrokeWidth((current?3f:2.2f)*u);stroke.setColor(Color.WHITE);c.drawCircle(q.x,q.y,r,stroke);
                label(c,String.valueOf(level),q.x,q.y,18f*u,Color.WHITE);
                for(int st=0;st<3;st++)drawStar(c,q.x+(st-1)*14f*u,q.y+r+14f*u,6f*u,st<stars?Color.rgb(255,218,48):Color.argb(135,255,255,255));
                if(completed){paint.setColor(Color.argb(220,255,255,255));c.drawCircle(q.x+r*.66f,q.y-r*.62f,10f*u,paint);label(c,"✓",q.x+r*.66f,q.y-r*.62f,10f*u,Color.rgb(46,182,98));}
            }
            else{drawLockedLevelNode(c,q.x,q.y,r,level,u);}
            if(isBossLevel(level)){RectF gate=new RectF(q.x+31f*u,q.y-11f*u,q.x+78f*u,q.y+11f*u);roundedGradient(c,gate,7f*u,Color.rgb(255,114,122),Color.rgb(199,42,79));label(c,"BOSS",gate.centerX(),gate.centerY(),7f*u,Color.WHITE);}
            else if(level%25==0){RectF gate=new RectF(q.x+31f*u,q.y-11f*u,q.x+72f*u,q.y+11f*u);roundedGradient(c,gate,7f*u,Color.rgb(255,185,62),Color.rgb(221,83,57));label(c,"WORLD",gate.centerX(),gate.centerY(),7f*u,Color.WHITE);}
            else if(isChestLevel(level)){drawChestMapBadge(c,q.x+38f*u,q.y,14f*u);}
            else if(level%10==0){paint.setShader(new RadialGradient(q.x+37f*u,q.y,13f*u,Color.rgb(255,239,118),Color.rgb(241,139,27),Shader.TileMode.CLAMP));c.drawCircle(q.x+37f*u,q.y,12f*u,paint);paint.setShader(null);label(c,"+",q.x+37f*u,q.y,10f*u,Color.WHITE);}
        }
        drawBranchChoiceNodes(c,u);
        drawMapFeatureCards(c,u);
        RectF worldTag=new RectF(w*.20f,h-112f*u,w*.80f,h-80f*u);card(c,worldTag,14f*u,Color.argb(170,34,31,94));label(c,"WORLD "+(mapWorld+1)+" • "+worldName(focusLevel)+" • AREA "+(((focusLevel-1)/10)+1),worldTag.centerX(),worldTag.centerY(),12f*u,Color.WHITE);
        if(mapScroll<25f)label(c,"SWIPE DOWN TO EXPLORE HIGHER LEVELS",w*.5f,h-132f*u,11.5f*u,Color.argb(220,255,255,255));
        drawLooseFx(c);
    }

    private void drawLockedLevelNode(Canvas c,float x,float y,float r,int level,float u) {
        paint.setShader(new RadialGradient(x-r*.30f,y-r*.38f,r*1.55f,
                new int[]{Color.rgb(181,176,220),Color.rgb(103,96,153),Color.rgb(54,49,94)},null,Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,paint);paint.setShader(null);
        paint.setColor(Color.argb(78,255,255,255));
        c.drawOval(new RectF(x-r*.55f,y-r*.70f,x+r*.05f,y-r*.24f),paint);
        stroke.setStrokeWidth(2.5f*u);stroke.setColor(Color.rgb(205,199,235));c.drawCircle(x,y,r,stroke);

        float lw=r*.28f, top=y-r*.36f;
        stroke.setStrokeWidth(Math.max(2f,3.2f*u));stroke.setColor(Color.rgb(241,226,86));
        c.drawArc(new RectF(x-lw,y-r*.48f,x+lw,y-r*.02f),190f,160f,false,stroke);
        RectF body=new RectF(x-r*.34f,y-r*.18f,x+r*.34f,y+r*.18f);
        roundedGradient(c,body,r*.10f,Color.rgb(255,224,75),Color.rgb(207,135,22));
        paint.setColor(Color.rgb(94,67,35));c.drawCircle(x,y-r*.02f,Math.max(2.2f,r*.055f),paint);
        c.drawRoundRect(new RectF(x-r*.035f,y,x+r*.035f,y+r*.09f),r*.02f,r*.02f,paint);
        label(c,"LV "+level,x,y+r*.48f,10.5f*u,Color.WHITE);
    }

    private void drawChestMapBadge(Canvas c,float x,float y,float r){
        float u=uiScale();paint.setShader(new RadialGradient(x,y,r*1.25f,Color.WHITE,Color.rgb(255,163,26),Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.WHITE);c.drawCircle(x,y,r,stroke);RectF box=new RectF(x-r*.55f,y-r*.08f,x+r*.55f,y+r*.48f);roundedGradient(c,box,r*.18f,Color.rgb(255,203,61),Color.rgb(194,92,23));paint.setColor(Color.rgb(109,58,26));c.drawRect(box.left,y-r*.05f,box.right,y+r*.07f,paint);paint.setColor(Color.WHITE);c.drawCircle(x,y+r*.19f,r*.09f,paint);
    }

    private PointF branchNode(int level,int route){
        PointF q=mapNode(level);float w=getWidth(),u=uiScale();
        float side=(route==1?-1f:1f);
        return new PointF(q.x+side*w*.185f,q.y+(route==1?-10f:10f)*u);
    }

    private void drawBranchChoiceNodes(Canvas c,float u){
        float h=getHeight(),w=getWidth();
        for(int level=2;level<=Math.min(MAP_LEVELS,maxUnlocked);level++){
            if(!isBranchChoiceLevel(level))continue;
            PointF q=mapNode(level);
            if(q.y<145f*u||q.y>h-85f*u)continue;
            PointF prev=mapNode(level-1),next=mapNode(Math.min(MAP_LEVELS,level+1));
            PointF powerNode=branchNode(level,1),treasureNode=branchNode(level,2);
            int chosen=branchRouteForLevel(level);
            // Two real fork roads that leave the main road and rejoin after the choice.
            for(int route=1;route<=2;route++){
                PointF b=route==1?powerNode:treasureNode;
                Path fork=new Path();fork.moveTo(prev.x,prev.y);fork.quadTo(q.x,q.y,b.x,b.y);fork.quadTo(q.x,q.y,next.x,next.y);
                stroke.setStrokeWidth(w*.090f);stroke.setColor(Color.argb(chosen==0||chosen==route?210:80,48,54,70));c.drawPath(fork,stroke);
                stroke.setStrokeWidth(w*.010f);stroke.setColor(route==1?Color.argb(220,91,220,255):Color.argb(220,255,197,73));c.drawPath(fork,stroke);
            }
            if(chosen==0 && level==maxUnlocked){
                float pulse=.5f+.5f*(float)Math.sin(ambientTime*4f);
                label(c,"CHOOSE YOUR ROUTE",q.x,q.y-48f*u,11.2f*u,Color.argb((int)(190+60*pulse),255,246,185));
            }
            drawBranchBadge(c,powerNode.x,powerNode.y,1,chosen,u);
            drawBranchBadge(c,treasureNode.x,treasureNode.y,2,chosen,u);
        }
    }

    private void drawBranchBadge(Canvas c,float x,float y,int route,int chosen,float u){
        boolean selected=chosen==route,disabled=chosen!=0&&!selected;
        int top=route==1?Color.rgb(72,201,255):Color.rgb(255,184,54);
        int bottom=route==1?Color.rgb(82,74,207):Color.rgb(208,89,31);
        float r=(selected?24f:21f)*u;
        paint.setColor(Color.argb(disabled?70:110,0,0,0));c.drawCircle(x,y+4f*u,r+3f*u,paint);
        paint.setColor(disabled?Color.argb(145,95,98,125):top);c.drawCircle(x,y,r,paint);
        stroke.setStrokeWidth(selected?3.5f*u:2f*u);stroke.setColor(selected?Color.WHITE:Color.argb(disabled?100:210,255,255,255));c.drawCircle(x,y,r,stroke);
        label(c,route==1?"⚡":"¢",x,y,15f*u,Color.WHITE);
        label(c,route==1?"POWER":"TREASURE",x,y+r+12f*u,8.5f*u,disabled?Color.argb(120,255,255,255):Color.WHITE);
        if(selected){paint.setColor(Color.rgb(72,211,118));c.drawCircle(x+r*.72f,y-r*.70f,7f*u,paint);label(c,"✓",x+r*.72f,y-r*.70f,7f*u,Color.WHITE);}
    }

    private void drawMapFeatureCards(Canvas c,float u){
        float w=getWidth(),h=getHeight();
        int base=Math.max(1,Math.min(MAP_LEVELS,maxUnlocked));
        int[] upcoming=new int[]{Math.min(MAP_LEVELS,base+5),Math.min(MAP_LEVELS,base+14),Math.min(MAP_LEVELS,base+24)};
        for(int i=0;i<upcoming.length;i++){
            int lvl=upcoming[i];
            PointF q=mapNode(lvl);
            if(q.y<145f*u||q.y>h-90f*u)continue;
            boolean left=(i%2)==0;
            float cx=left?w*.15f:w*.85f;
            RectF r=new RectF(cx-58f*u,q.y-26f*u,cx+58f*u,q.y+26f*u);
            Objective oo=objectiveForLevel(lvl);String title=isBossLevel(lvl)?"BOSS":(isChestLevel(lvl)?"CHEST":(oo==Objective.RESCUE?"RESCUE":oo==Objective.KEYS?"KEYS":oo==Objective.ICE_BREAK?"ICE":oo==Objective.LIMITED?"LIMIT":"BOOST"));
            int top=isBossLevel(lvl)?Color.rgb(255,112,126):(isChestLevel(lvl)?Color.rgb(255,186,54):Color.rgb(77,207,255));
            int bottom=isBossLevel(lvl)?Color.rgb(186,41,86):(isChestLevel(lvl)?Color.rgb(225,88,48):Color.rgb(46,95,210));
            paint.setColor(Color.argb(80,0,0,0));c.drawRoundRect(new RectF(r.left,r.top+5f*u,r.right,r.bottom+5f*u),12f*u,12f*u,paint);
            roundedGradient(c,r,12f*u,top,bottom);
            paint.setColor(Color.argb(100,255,255,255));c.drawRoundRect(new RectF(r.left+2f*u,r.top+2f*u,r.right-2f*u,r.top+r.height()*.43f),10f*u,10f*u,paint);
            label(c,title,r.centerX(),r.centerY()-5f*u,12.5f*u,Color.WHITE);
            label(c,"LV."+lvl,r.centerX(),r.centerY()+14f*u,9.5f*u,Color.argb(230,255,255,255));
        }
    }

    private PointF mapNode(int level) {
        float w=getWidth(),u=uiScale();
        // Leave a real bottom safe zone for Level 1; the world-name card sits near the bottom
        // and previously covered the current Level 1 node on several portrait phones.
        float y=getHeight()-158f*u-(level-1)*126f*u+mapScroll;
        float x=w*.5f+(float)Math.sin((level-1)*1.04f)*w*.27f;
        return new PointF(x,y);
    }

    private float maxMapScroll() {
        float u=uiScale(); float content=(MAP_LEVELS-1)*126f*u;
        return Math.max(0f,content-(getHeight()-210f*u));
    }

    private boolean isChestLevel(int level){ return level % 10 == 0 && !isBossLevel(level); }
    private boolean isBossLevel(int level){ return level % 25 == 0; }
    private int specialPrefix(int value){ return value>=100 ? (value/100)*100 : 0; }
    private int baseColorOf(int value){ return value>=100 ? Math.max(0,Math.min(PALETTE.length-1,value%100)) : Math.max(0,Math.min(PALETTE.length-1,value)); }
    private boolean isSpecial(int value,int prefix){ return value>=prefix && value<prefix+100; }
    private boolean isChestBubbleValue(int value){ return isSpecial(value,SPECIAL_CHEST); }
    private boolean isStarBubbleValue(int value){ return isSpecial(value,SPECIAL_STAR); }
    private boolean isIceBubbleValue(int value){ return isSpecial(value,SPECIAL_ICE); }
    private boolean isStoneBubbleValue(int value){ return isSpecial(value,SPECIAL_STONE); }
    private boolean isChainBubbleValue(int value){ return isSpecial(value,SPECIAL_CHAIN); }
    private boolean isCloudBubbleValue(int value){ return isSpecial(value,SPECIAL_CLOUD); }
    private boolean isKeyBubbleValue(int value){ return isSpecial(value,SPECIAL_KEY); }
    private boolean isMysteryBubbleValue(int value){ return isSpecial(value,SPECIAL_MYSTERY); }
    private boolean isBabyBubbleValue(int value){ return isSpecial(value,SPECIAL_BABY); }
    private boolean isLightningBubbleValue(int value){ return isSpecial(value,SPECIAL_LIGHTNING); }
    private boolean isMagnetBubbleValue(int value){ return isSpecial(value,SPECIAL_MAGNET); }
    private boolean isPaintBubbleValue(int value){ return isSpecial(value,SPECIAL_PAINT); }
    private boolean isBlackHoleBubbleValue(int value){ return isSpecial(value,SPECIAL_BLACK_HOLE); }
    private boolean isPortalBubbleValue(int value){ return isSpecial(value,SPECIAL_PORTAL); }
    private boolean isArmorBubbleValue(int value){ return isSpecial(value,SPECIAL_ARMOR); }
    private int makeSpecialBubble(int prefix,int color){ return prefix + Math.max(0,Math.min(PALETTE.length-1,color)); }
    private int makeChestBubble(int color){ return makeSpecialBubble(SPECIAL_CHEST,color); }
    private int makeStarBubble(int color){ return makeSpecialBubble(SPECIAL_STAR,color); }

    private Objective objectiveForLevel(int level){
        if(isBossLevel(level))return Objective.BOSS;
        if(isChestLevel(level))return Objective.TREASURE;
        // Variety starts early instead of making the first world feel like repeated clear-only stages.
        if(level==1)return Objective.CLEAR;
        int m=level%12;
        if(m==3||m==8)return Objective.RESCUE;
        if(m==5||m==10)return Objective.KEYS;
        if(m==7)return Objective.ICE_BREAK;
        if(m==2||m==9)return Objective.LIMITED;
        return Objective.CLEAR;
    }

    private String objectiveTitle(){
        if(gameMode==GameMode.SURVIVAL)return "SURVIVE WAVE "+survivalWave;
        if(gameMode==GameMode.TREASURE_ROOM)return "TREASURE ROOM";
        switch(objective){
            case RESCUE:return "RESCUE BABIES";
            case KEYS:return "COLLECT KEYS";
            case ICE_BREAK:return "BREAK THE ICE";
            case TREASURE:return "DROP TREASURE";
            case LIMITED:return "LIMITED SHOTS";
            case BOSS:return "DEFEAT THE BOSS";
            default:return "CLEAR BUBBLES";
        }
    }

    private String objectiveDetail(){
        if(objective==Objective.CLEAR||objective==Objective.LIMITED||objective==Objective.BOSS){
            int pct=Math.min(100,Math.round(clearedBubbles*100f/Math.max(1,initialBubbleCount)));
            return pct+"% / "+Math.round(100f*clearTarget/Math.max(1,initialBubbleCount))+"%";
        }
        return Math.min(objectiveProgress,objectiveTarget)+" / "+Math.max(1,objectiveTarget);
    }

    private String worldRuleName(int level){
        int w=worldIndex(level);
        if(w==1||w==14)return "MYSTERY RAIN";
        if(w==3||w==16)return "CLOUD CURRENT";
        if(w==5||w==11)return "ICE STORM";
        if(w==7||w==15)return "CHAIN GRID";
        if(w==10||w==17)return "RAPID PRESSURE";
        if(w==13||w==19)return "STAR SURGE";
        return "BUBBLE REALM";
    }

    private float objectiveClearRatio(){
        // v4.0: levels deliberately take longer from the opening world, while objective stages
        // keep enough margin to stay completable without mandatory paid boosters.
        if(gameMode==GameMode.TREASURE_ROOM)return .62f;
        if(gameMode==GameMode.SURVIVAL)return .58f;
        if(objective==Objective.BOSS)return .98f;
        if(objective==Objective.LIMITED)return .97f;
        if(objective==Objective.CLEAR)return .98f;
        return .86f;
    }

    private boolean objectiveMet(){
        if(gameMode==GameMode.SURVIVAL)return true;
        if(objective==Objective.BOSS)return bossShield<=0;
        if(objective==Objective.CLEAR||objective==Objective.LIMITED)return true;
        return objectiveProgress>=Math.max(1,objectiveTarget);
    }

    private void placeSpecialBubbles(Random r,int count,int kindPrefix){
        if(grid.isEmpty()||count<=0)return;
        ArrayList<Integer> keys=new ArrayList<>(grid.keySet());
        Collections.shuffle(keys,r);
        int placed=0;
        for(int k:keys){
            int value=grid.get(k);
            if(value>=100)continue;
            int base=baseColorOf(value);
            grid.put(k, makeSpecialBubble(kindPrefix,base));
            placed++;
            if(placed>=count)break;
        }
    }

    private int countSpecialOnBoard(int prefix){
        int n=0;for(Integer v:grid.values())if(v!=null&&isSpecial(v,prefix))n++;return n;
    }

    private int dailyChallengeLevel(){
        Calendar c=Calendar.getInstance();
        int day=c.get(Calendar.DAY_OF_YEAR);
        return 1+Math.abs(day*37+Calendar.getInstance().get(Calendar.YEAR)*11)%MAP_LEVELS;
    }

    private String todayKey(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(Calendar.getInstance().getTime());}

    private boolean isDailyChallengeClaimed(){ return todayKey().equals(prefs.getString("daily_challenge_done","")); }

    private String dailyEventName(){
        int d=Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%4;
        return d==0?"DOUBLE COIN DAY":d==1?"TREASURE HUNT":d==2?"BUBBLE RUSH":"BOSS BOUNTY";
    }

    private void startDailyChallenge(){
        // Daily Challenge is a temporary session. Never replace the Adventure
        // CONTINUE save with today's random challenge level.
        launchingDailyChallenge=true;
        dailyChallengeMode=true;
        startLevel(dailyChallengeLevel());
        launchingDailyChallenge=false;
        dailyChallengeMode=true;
        floatingTexts.add(new FloatingText("DAILY CHALLENGE",getWidth()*.5f,getHeight()*.35f,Color.rgb(255,226,92),28f));
    }

    private boolean isBranchChoiceLevel(int level){
        return level>1 && ((level-1)%12==0) && !isBossLevel(level);
    }

    private int branchRouteForLevel(int level){
        if(!isBranchChoiceLevel(level))return 0;
        return Math.max(0,Math.min(2,prefs.getInt("route_"+level,0)));
    }

    private String branchRouteName(int route){
        return route==1?"POWER ROUTE":route==2?"TREASURE ROUTE":"MAIN ROUTE";
    }

    private boolean isTreasureRoomAvailableAfter(int level){
        return level>0 && level<MAP_LEVELS && level%7==0;
    }

    private void configureDynamicLevelSystems(int level){
        // Movement starts almost immediately. Level 1 teaches the shooter, then the board gets alive.
        if(level<=1)formationMode=0;
        else if(level%9==0)formationMode=2;
        else if(level%5==0)formationMode=3;
        else if(level%2==0)formationMode=1;
        else formationMode=0;

        windForce=0f;gravityForce=0f;
        int world=worldIndex(level);
        if(level>=3 && (level%6==0 || world==3 || world==15)){
            float mag=34f+Math.min(86f,level*.18f);
            windForce=((level&1)==0?1f:-1f)*mag;
        }
        if(level>=5 && (level%9==0 || world==4 || world==17)){
            gravityForce=38f+Math.min(92f,level*.15f);
        }
        // Moving energy bumpers are physical obstacles, not just decoration.
        movingBarrierMode=level<3?0:(level%11==0?3:(level%4==0?2:(level%3==0?1:0)));
        // Realm-specific rules make worlds feel mechanically different, not just recolored.
        if(level>=2 && (world==0||world==5||world==13))formationMode=Math.max(formationMode,1);
        if(world==13 && level>=25)formationMode=2;
        if(world==6||world==18)formationMode=Math.max(formationMode,3);
        if(world==7||world==15)movingBarrierMode=Math.max(movingBarrierMode,2);
        if(world==9||world==19)movingBarrierMode=Math.max(movingBarrierMode,1);
        if(world==18 && level>=50){windForce=windForce==0f?46f:windForce;gravityForce=Math.max(gravityForce,42f);}
        portalCooldown=0f;barrierCooldown=0f;
    }

    private void startSurvivalMode(){
        gameMode=GameMode.SURVIVAL;
        dailyChallengeMode=false;
        selectedLevel=Math.max(1,maxUnlocked);
        screen=Screen.GAME;overlay=Overlay.NONE;toolMenuOpen=false;
        grid.clear();particles.clear();glassShards.clear();debrisFloorY=-1f;falling.clear();floatingTexts.clear();rings.clear();
        levelScore=0;combo=0;misses=0;survivalWave=1;survivalBest=prefs.getInt("survival_best",0);
        shotsLeft=9999;shotsSinceDrop=0;pressureLimit=5;rowDropTimer=0f;gridParityPhase=0;shotFlightTime=0f;
        activeBranchRoute=0;objective=Objective.CLEAR;objectiveTarget=0;objectiveProgress=0;
        power=Power.NORMAL;shotFlying=false;superCharge=0;superReadyAnnounced=false;
        bossShield=0;bossMaxShield=0;bossShotsUntilAttack=0;bossPhase=1;
        configureDynamicLevelSystems(Math.max(12,selectedLevel));
        buildSurvivalWave(true);
        initialBubbleCount=Math.max(1,grid.size());
        clearTarget=Math.max(1,(int)Math.ceil(initialBubbleCount*.58f));
        clearedBubbles=0;
        currentColor=pickExistingColor();nextColor=pickExistingColor();
        displayedBest=survivalBest;levelIntroTimer=LEVEL_INTRO_DURATION;popFlash=0f;impactTimer=0f;impactStrength=0f;
        audio.setMusicTheme(12);audio.play(AudioEngine.FX_LEVEL_START,1f,.93f);
        floatingTexts.add(new FloatingText("SURVIVAL • ENDLESS PRESSURE",getWidth()*.5f,getHeight()*.38f,Color.rgb(255,226,92),28f));
        haptic(28);
    }

    private void buildSurvivalWave(boolean fresh){
        Random r=new Random(90117L+survivalWave*811L+selectedLevel*29L);
        if(fresh)grid.clear();
        int rows=fresh?8:Math.min(4,2+survivalWave/4);
        if(!fresh){
            for(int n=0;n<rows;n++)addCeilingRowNoCheck();
            return;
        }
        int active=Math.min(PALETTE.length,4+Math.min(3,survivalWave/3));
        for(int row=0;row<rows;row++)for(int col=0;col<GRID_COLS;col++){
            if(row>2 && r.nextFloat()<.04f)continue;
            grid.put(key(row,col),r.nextInt(active));
        }
        placeSpecialBubbles(r,2,SPECIAL_LIGHTNING);
        placeSpecialBubbles(r,1,SPECIAL_MAGNET);
        if(selectedLevel>=20)placeSpecialBubbles(r,1,SPECIAL_PAINT);
        if(selectedLevel>=45)placeSpecialBubbles(r,1,SPECIAL_BLACK_HOLE);
        if(selectedLevel>=15)placeSpecialBubbles(r,2,SPECIAL_PORTAL);
    }

    private void startTreasureRoom(int fromLevel){
        gameMode=GameMode.TREASURE_ROOM;
        dailyChallengeMode=false;
        treasureReturnLevel=Math.min(MAP_LEVELS,Math.max(1,fromLevel+1));
        selectedLevel=Math.max(1,Math.min(MAP_LEVELS,fromLevel));
        screen=Screen.GAME;overlay=Overlay.NONE;toolMenuOpen=false;
        grid.clear();particles.clear();glassShards.clear();debrisFloorY=-1f;falling.clear();floatingTexts.clear();rings.clear();
        levelScore=0;combo=0;misses=0;shotsLeft=18;shotsSinceDrop=0;pressureLimit=7;rowDropTimer=0f;gridParityPhase=0;shotFlightTime=0f;
        activeBranchRoute=2;objective=Objective.TREASURE;power=Power.NORMAL;shotFlying=false;
        superCharge=35;superReadyAnnounced=false;bossShield=0;bossMaxShield=0;bossShotsUntilAttack=0;bossPhase=1;
        formationMode=1;windForce=0f;gravityForce=0f;portalCooldown=0f;
        Random r=new Random(73001L+fromLevel*109L);
        int active=Math.min(PALETTE.length,4+fromLevel/120);
        for(int row=0;row<7;row++)for(int col=0;col<GRID_COLS;col++){
            if(row>2&&r.nextFloat()<.08f)continue;
            grid.put(key(row,col),r.nextInt(Math.max(3,active)));
        }
        placeSpecialBubbles(r,6,SPECIAL_CHEST);
        placeSpecialBubbles(r,2,SPECIAL_STAR);
        placeSpecialBubbles(r,1,SPECIAL_LIGHTNING);
        placeSpecialBubbles(r,1,SPECIAL_BLACK_HOLE);
        initialBubbleCount=Math.max(1,grid.size());clearTarget=Math.max(1,(int)Math.ceil(initialBubbleCount*.62f));clearedBubbles=0;
        objectiveProgress=0;objectiveTarget=Math.max(1,countSpecialOnBoard(SPECIAL_CHEST));
        targetScore=1200+fromLevel*22;
        currentColor=pickExistingColor();nextColor=pickExistingColor();displayedBest=0;
        levelIntroTimer=LEVEL_INTRO_DURATION;popFlash=0f;impactTimer=0f;impactStrength=0f;
        audio.setMusicTheme(12);audio.play(AudioEngine.FX_TREASURE,1f,1.04f);
        floatingTexts.add(new FloatingText("TREASURE ROOM • COLLECT ALL CHESTS",getWidth()*.5f,getHeight()*.38f,Color.rgb(255,224,82),27f));
        haptic(32);
    }

    // ---------------------------------------------------------------
    // Gameplay
    // ---------------------------------------------------------------

    private void startLevel(int level) {
        boolean dailyLaunch=launchingDailyChallenge;
        gameMode=GameMode.ADVENTURE;
        dailyChallengeMode=dailyLaunch;
        selectedLevel=Math.max(1,Math.min(MAP_LEVELS,level));screen=Screen.GAME;overlay=Overlay.NONE;toolMenuOpen=false;
        grid.clear();particles.clear();glassShards.clear();debrisFloorY=-1f;falling.clear();floatingTexts.clear();levelScore=0;combo=0;misses=0;lastChestBonus=0;lastBossBonus=0;winCelebrationTimer=0f;lastLevelWasUnlock=false;winStarSoundStage=0;
        companionMeter=0;companionPulse=0f;continueUsedThisLevel=false;fusionStreak=0;
        int world=worldIndex(selectedLevel);
        activeBranchRoute=branchRouteForLevel(selectedLevel);
        objective=objectiveForLevel(selectedLevel);
        boolean boss=objective==Objective.BOSS;
        // v4.0 hard-from-level-1 balance: larger boards + near-total clear make stages longer,
        // but the shot budget and comeback boost keep them skill-completable.
        shotsLeft=28; // v5.5.17: return the Adventure move budget to the earlier, tighter 28-shot pacing.
        if(objective==Objective.LIMITED)shotsLeft=Math.max(16,shotsLeft-6);
        if(boss)shotsLeft=Math.max(18,shotsLeft-3);
        levelLossStreak=prefs.getInt("loss_streak_"+selectedLevel,0);
        if(levelLossStreak>=2){int extra=levelLossStreak>=4?4:2;shotsLeft+=extra;floatingTexts.add(new FloatingText("COMEBACK BOOST +"+extra+" SHOTS",getWidth()*.5f,getHeight()*.38f,Color.rgb(157,244,255),25f));}
        targetScore=1450+selectedLevel*40+world*210+(boss?700:0)+(isChestLevel(selectedLevel)?180:0);
        bombCount=Math.max(0,prefs.getInt("bomb_inventory",bombCount));
        rainbowCount=Math.max(0,prefs.getInt("wild_inventory",rainbowCount));
        power=Power.NORMAL;shotFlying=false;shotFlightTime=0f;gridParityPhase=0;
        superCharge=activeBranchRoute==1?20:0;superReadyAnnounced=false;
        treasureRoomPending=false;
        configureDynamicLevelSystems(selectedLevel);
        shotsSinceDrop=0;
        pressureLimit=selectedLevel<=20?8:selectedLevel<=100?7:selectedLevel<=250?6:selectedLevel<=500?5:4;
        if(boss)pressureLimit=Math.max(4,pressureLimit-1);
        rowDropTimer=0f;
        bossMaxShield=boss?(3+Math.min(4,selectedLevel/100)):0;
        bossShield=bossMaxShield;
        bossShotsUntilAttack=boss?4:0;
        bossPhase=1;
        buildLevel(selectedLevel);
        initialBubbleCount=Math.max(1,grid.size());
        clearTarget=Math.max(1,(int)Math.ceil(initialBubbleCount*objectiveClearRatio()));
        clearedBubbles=0;
        objectiveProgress=0;
        if(objective==Objective.RESCUE)objectiveTarget=Math.max(1,countSpecialOnBoard(SPECIAL_BABY));
        else if(objective==Objective.KEYS)objectiveTarget=Math.max(1,countSpecialOnBoard(SPECIAL_KEY));
        else if(objective==Objective.ICE_BREAK)objectiveTarget=Math.max(1,countSpecialOnBoard(SPECIAL_ICE));
        else if(objective==Objective.TREASURE)objectiveTarget=Math.max(1,countSpecialOnBoard(SPECIAL_CHEST));
        else objectiveTarget=0;
        feverTimer=0f;feverBurst=0f;rings.clear();perfectShotTimer=0f;almostThereAnnounced=false;milestoneText=null;
        currentColor=pickExistingColor();nextColor=pickExistingColor();displayedBest=prefs.getInt("best_"+selectedLevel,0);
        levelIntroTimer=LEVEL_INTRO_DURATION; popFlash=0f; impactTimer=0f; impactStrength=0f;
        audio.setMusicTheme(12);audio.play(AudioEngine.FX_LEVEL_START,1f,1f);
        if((selectedLevel-1)%25==0)audio.play(AudioEngine.FX_WORLD,.95f,1f);
        // A normal Adventure level owns the resume slot. A Daily Challenge must
        // leave the existing Adventure save untouched.
        if(!dailyLaunch){clearSavedGame();saveGameState();}
        haptic(22);
    }

    private void buildLevel(int level) {
        Random r=new Random(level*7391L+20260812L);
        int world=worldIndex(level);
        boolean boss=isBossLevel(level);

        int activeColors;
        int baseRows;
        float holeChance;
        if(level<=20){
            // Early levels now begin a little higher so the opening board does not feel too low.
            // Difficulty still ramps because the board gradually descends as you clear bubbles.
            activeColors=level<=2?4:(level<=8?5:6);
            baseRows=level<=2?5:(level<=8?6:7);
            holeChance=.001f;
        } else if(level<=100){
            activeColors=4 + (level>=45?1:0);
            baseRows=6 + Math.min(1, (level-21)/40);
            holeChance=.03f + Math.min(.03f, (level-21)*.0005f);
        } else if(level<=260){
            activeColors=5 + (level>=160?1:0);
            baseRows=6 + Math.min(1, (level-101)/90);
            holeChance=.05f + Math.min(.04f, world*.005f);
        } else {
            activeColors=Math.min(6,5 + (level>=420?1:0));
            baseRows=6 + Math.min(1, (level-261)/300);
            holeChance=.06f + Math.min(.06f, world*.005f);
        }
        if(boss){ activeColors=Math.min(PALETTE.length, activeColors+1); baseRows=Math.min(7, baseRows+1); holeChance*=.48f; }
        baseRows=Math.min(7, baseRows);

        for(int row=0;row<baseRows;row++){
            for(int col=0;col<GRID_COLS;col++){
                boolean edgeHole=level>80 && row>1&&(col==0||col==GRID_COLS-1)&&r.nextFloat()<(.10f + world*.008f);
                boolean hole=row>1&&r.nextFloat()<holeChance;
                if(edgeHole||hole)continue;
                int color;
                if(row>0&&r.nextFloat()<(level<=20?.48f:(level<=60?.58f:.52f))){
                    Integer above=grid.get(key(row-1,Math.max(0,Math.min(GRID_COLS-1,col))));
                    color=(above!=null&&above>=0)?baseColorOf(above):r.nextInt(activeColors);
                }else color=r.nextInt(activeColors);
                grid.put(key(row,col),color);
            }
        }
        int pattern=level%10;
        if(level>14){
            if(pattern==0){for(int row=2;row<baseRows;row++)if(row%2==0)grid.remove(key(row,GRID_COLS/2));}
            else if(pattern==1){for(int row=Math.max(2,baseRows/2);row<baseRows;row++){grid.remove(key(row,1));grid.remove(key(row,GRID_COLS-2));}}
            else if(pattern==2){for(int row=2;row<baseRows;row++)for(int col=0;col<GRID_COLS;col++)if((row+col)%5==0)grid.remove(key(row,col));}
            else if(pattern==3){for(int row=2;row<baseRows;row++){int c=Math.min(GRID_COLS-1,(row+1)%GRID_COLS);grid.remove(key(row,c));}}
            else if(pattern==4){for(int row=2;row<baseRows;row++){int c=Math.min(GRID_COLS-1,row%GRID_COLS);grid.remove(key(row,c));grid.remove(key(row,GRID_COLS-1-c));}}
            else if(pattern==5){for(int col=2;col<GRID_COLS-2;col+=3)grid.remove(key(baseRows-1,col));}
            else if(pattern==6){for(int row=2;row<baseRows;row++)if(row%3==0){grid.remove(key(row,3));grid.remove(key(row,6));}}
            else if(pattern==7){grid.remove(key(baseRows-1,1));grid.remove(key(baseRows-1,GRID_COLS-2));grid.remove(key(baseRows-2,GRID_COLS/2));}
            else if(pattern==8){for(int row=2;row<baseRows;row++){grid.remove(key(row,0)); if(row%2==1)grid.remove(key(row,GRID_COLS-1));}}
            else {for(int col=1;col<GRID_COLS-1;col+=2)grid.remove(key(baseRows-2,col));}
        }
        polishGeneratedLevel(r, activeColors, baseRows);

        // Objective bubbles and world hazards are applied after polish so their identity is preserved.
        Objective obj=objectiveForLevel(level);
        if(obj==Objective.TREASURE||isChestLevel(level))placeSpecialBubbles(r, level<100?2:3, SPECIAL_CHEST);
        if(level>=15)placeSpecialBubbles(r, boss?4:(level<120?1:2), SPECIAL_STAR);
        if(obj==Objective.RESCUE)placeSpecialBubbles(r, level<150?2:3, SPECIAL_BABY);
        if(obj==Objective.KEYS)placeSpecialBubbles(r, level<150?2:3, SPECIAL_KEY);
        if(obj==Objective.ICE_BREAK)placeSpecialBubbles(r, level<120?4:6, SPECIAL_ICE);

        int obstacleTier=level<3?1:level<18?2:level<55?3:level<140?4:5;
        // A few blockers appear in the very first world so Level 1 is not a tutorial-sized board.
        placeSpecialBubbles(r, Math.min(6,1+obstacleTier+(world==5||world==11?1:0)), SPECIAL_ICE);
        placeSpecialBubbles(r, level<=2?2:Math.min(7,2+obstacleTier), SPECIAL_ARMOR);
        if(level>=3)placeSpecialBubbles(r, Math.min(5,1+obstacleTier/2), SPECIAL_CHAIN);
        if(level>=5)placeSpecialBubbles(r, Math.min(5,1+obstacleTier/2), SPECIAL_CLOUD);
        if(level>=7)placeSpecialBubbles(r, Math.min(5,1+obstacleTier/2), SPECIAL_STONE);
        if(level>=2)placeSpecialBubbles(r, boss?2:1+(level>=160?1:0), SPECIAL_MYSTERY);
        // World signatures: every realm has a recognizable board personality.
        if(world==0)placeSpecialBubbles(r,1,SPECIAL_LIGHTNING);
        if(world==1||world==14)placeSpecialBubbles(r,1,SPECIAL_MYSTERY);
        if(world==2||world==12)placeSpecialBubbles(r,1,SPECIAL_STAR);
        if(world==3||world==16)placeSpecialBubbles(r,1+(level>=180?1:0),SPECIAL_CLOUD);
        if(world==4||world==17)placeSpecialBubbles(r,1,SPECIAL_PORTAL);
        if(world==5||world==11)placeSpecialBubbles(r,2,SPECIAL_ICE);
        if(world==6)placeSpecialBubbles(r,1,SPECIAL_ARMOR);
        if(world==7||world==15)placeSpecialBubbles(r,1+(level>=180?1:0),SPECIAL_CHAIN);
        if(world==8)placeSpecialBubbles(r,1,SPECIAL_MAGNET);
        if(world==9||world==13||world==19)placeSpecialBubbles(r,1,SPECIAL_STAR);
        if(world==10)placeSpecialBubbles(r,1,SPECIAL_BLACK_HOLE);
        if(world==18)placeSpecialBubbles(r,2,SPECIAL_PAINT);

        // v4.0 special bubbles: introduced gradually so the opening game teaches them naturally.
        if(level>=4)placeSpecialBubbles(r,1+(level>=120?1:0),SPECIAL_LIGHTNING);
        if(level>=7)placeSpecialBubbles(r,1,SPECIAL_MAGNET);
        if(level>=11)placeSpecialBubbles(r,1+(level>=220?1:0),SPECIAL_PAINT);
        if(level>=17)placeSpecialBubbles(r,1+(level>=320?1:0),SPECIAL_BLACK_HOLE);
        if(level>=8 && (level%5==0 || world==3 || world==15))placeSpecialBubbles(r,2,SPECIAL_PORTAL);

        // Branching-road variants really change the board the player enters.
        if(activeBranchRoute==1){
            placeSpecialBubbles(r,2,SPECIAL_LIGHTNING);
            placeSpecialBubbles(r,1,SPECIAL_MAGNET);
            placeSpecialBubbles(r,1,SPECIAL_PAINT);
        }else if(activeBranchRoute==2){
            placeSpecialBubbles(r,2,SPECIAL_CHEST);
            placeSpecialBubbles(r,1,SPECIAL_MYSTERY);
            if(level>=22)placeSpecialBubbles(r,1,SPECIAL_BLACK_HOLE);
        }
    }


    private void polishGeneratedLevel(Random r,int activeColors,int baseRows){
        for(int pass=0; pass<3; pass++){
            ArrayList<Integer> cells=new ArrayList<>(grid.keySet());
            boolean changed=false;
            for(int k:cells){
                Integer cur=grid.get(k);
                if(cur==null)continue;
                int row=rowOf(k),col=colOf(k);
                int occupied=0;
                Integer onlyNeighborColor=null;
                for(int nk:neighborKeys(row,col)){
                    Integer nc=grid.get(nk);
                    if(nc!=null){
                        occupied++;
                        if(onlyNeighborColor==null)onlyNeighborColor=baseColorOf(nc);
                    }
                }
                if(row>0 && occupied==0){
                    grid.remove(k);
                    changed=true;
                } else if(occupied==1 && onlyNeighborColor!=null){
                    grid.put(k, onlyNeighborColor);
                }
            }
            if(!changed)break;
        }

        // Fill a few lonely gaps so the board feels fuller and avoids awkward single-center bubbles.
        ArrayList<Integer> filled=new ArrayList<>();
        for(int row=1; row<Math.min(baseRows, GRID_ROWS-1); row++){
            for(int col=0; col<GRID_COLS; col++){
                int k=key(row,col);
                if(grid.containsKey(k))continue;
                int support=0;
                Integer color=null;
                for(int nk:neighborKeys(row,col)){
                    Integer nc=grid.get(nk);
                    if(nc!=null){
                        support++;
                        if(color==null)color=baseColorOf(nc);
                    }
                }
                if(support>=3 && r.nextFloat()<.18f){
                    grid.put(k, color!=null?color:r.nextInt(Math.max(3,Math.min(activeColors,PALETTE.length))));
                    filled.add(k);
                }
            }
        }

        // Last polish: if a bubble has exactly one visible neighbor, align its color to that group.
        for(int k:new ArrayList<>(grid.keySet())){
            Integer cur=grid.get(k);
            if(cur==null)continue;
            int row=rowOf(k),col=colOf(k),occupied=0;
            Integer only=null;
            for(int nk:neighborKeys(row,col)){
                Integer nc=grid.get(nk);
                if(nc!=null){
                    occupied++;
                    only=baseColorOf(nc);
                }
            }
            if(occupied==1 && only!=null)grid.put(k, only);
        }
    }

    private void drawGameplayPolish(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        float pulse=.50f+.50f*(float)Math.sin(ambientTime*1.9f);

        // Edge neon glows.
        paint.setShader(new LinearGradient(0,0,48f*u,0,Color.argb((int)(54+38*pulse),105,226,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawRect(0,96f*u,52f*u,h*.83f,paint);paint.setShader(null);
        paint.setShader(new LinearGradient(w,0,w-48f*u,0,Color.argb((int)(48+34*pulse),207,127,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawRect(w-52f*u,96f*u,w,h*.83f,paint);paint.setShader(null);

        // Sweeping light beams.
        for(int i=0;i<4;i++){
            float cx=((ambientTime*(.016f+i*.003f)+i*.29f)%1.15f)*w-w*.08f;
            Path beam=new Path();
            beam.moveTo(cx-w*.13f,96f*u);beam.lineTo(cx+w*.035f,96f*u);
            beam.lineTo(cx+w*.24f,h*.79f);beam.lineTo(cx+w*.055f,h*.79f);beam.close();
            paint.setColor(Color.argb(9+i*4,255,255,255));c.drawPath(beam,paint);
        }

        // Combo heat aura makes hot streaks feel different.
        if(combo>=2 || feverTimer>0f){
            float strength=feverTimer>0f?1f:Math.min(1f,combo/6f);
            int a=(int)(38+58*strength*(.65f+.35f*pulse));
            paint.setShader(new RadialGradient(w*.5f,h*.50f,w*.52f,
                    Color.argb(a,255,205,70),Color.TRANSPARENT,Shader.TileMode.CLAMP));
            c.drawCircle(w*.5f,h*.50f,w*.52f,paint);paint.setShader(null);
        }

        // Inner glass border.
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.argb(88,255,255,255));
        c.drawRoundRect(new RectF(7f*u,101f*u,w-7f*u,h*.815f),22f*u,22f*u,stroke);

        // Floating foreground sparkles.
        for(int i=0;i<22;i++){
            float xx=((i*.061f)+(ambientTime*.0065f*(1+i%3)))%1f*w;
            float yy=h*(.13f+((i*.113f)%1f)*.64f);
            float tw=.5f+.5f*(float)Math.sin(ambientTime*2.4f+i);
            float rr=(1.2f+(i%4)*.63f)*u*(.70f+.38f*tw);
            paint.setColor(Color.argb(45+(i%4)*16,255,255,255));c.drawCircle(xx,yy,rr,paint);
        }

        // Soft vignette at top/bottom to improve focus.
        paint.setShader(new LinearGradient(0,96f*u,0,165f*u,Color.argb(42,13,20,69),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawRect(0,96f*u,w,170f*u,paint);paint.setShader(null);
        paint.setShader(new LinearGradient(0,h*.72f,0,h*.84f,Color.TRANSPARENT,Color.argb(38,13,20,69),Shader.TileMode.CLAMP));
        c.drawRect(0,h*.70f,w,h*.84f,paint);paint.setShader(null);
    }

    private void drawGameplayDepth(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        float top=96f*u,bottom=h*.815f;
        int accent=themeAccent(selectedLevel);
        // A restrained glass board plane gives the bubbles a physical playfield without hiding the world.
        paint.setShader(new LinearGradient(0,top,0,bottom,
                Color.argb(42,255,255,255),Color.argb(12,8,15,54),Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(10f*u,top,w-10f*u,bottom),20f*u,20f*u,paint);paint.setShader(null);
        stroke.setStrokeWidth(1.2f*u);
        stroke.setColor(Color.argb(62,255,255,255));
        for(int i=0;i<7;i++){
            float yy=top+(bottom-top)*(.12f+i*.12f);
            c.drawLine(18f*u,yy,w-18f*u,yy,stroke);
        }
        // Perspective-like side light strips. They remain subtle so the aiming line stays dominant.
        stroke.setStrokeWidth(2.2f*u);
        stroke.setColor(Color.argb(58,Color.red(accent),Color.green(accent),Color.blue(accent)));
        Path left=new Path();left.moveTo(14f*u,bottom);left.lineTo(w*.18f,top);
        Path right=new Path();right.moveTo(w-14f*u,bottom);right.lineTo(w*.82f,top);
        c.drawPath(left,stroke);c.drawPath(right,stroke);
        // Soft launcher deck reflection.
        paint.setShader(new RadialGradient(shooterX,shooterY+8f*u,radiusSafe(bubbleR*3.8f),
                Color.argb(34,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawOval(new RectF(shooterX-bubbleR*4.1f,shooterY+8f*u,shooterX+bubbleR*4.1f,shooterY+bubbleR*1.7f),paint);
        paint.setShader(null);
    }

    private float radiusSafe(float r){return Math.max(1f,r);}

    private void drawComboCinematic(Canvas c){
        if(combo<2 || overlay!=Overlay.NONE)return;
        float w=getWidth(),u=uiScale();
        float pulse=1f+.055f*(float)Math.sin(ambientTime*8f);
        float intensity=Math.min(1f,combo/8f);
        RectF cb=new RectF(w*.63f,96f*u,w*.97f,136f*u);
        int left=Color.rgb(255,214,72);
        int right=combo>=5?Color.rgb(255,84,122):Color.rgb(238,83,63);
        roundedGradient(c,cb,17f*u,left,right);
        stroke.setStrokeWidth((1.5f+intensity)*u);
        stroke.setColor(Color.argb(220,255,247,198));c.drawRoundRect(cb,17f*u,17f*u,stroke);
        paint.setColor(Color.argb(70,255,255,255));
        c.drawRoundRect(new RectF(cb.left+4f*u,cb.top+4f*u,cb.right-4f*u,cb.top+15f*u),11f*u,11f*u,paint);
        label(c,"COMBO x"+combo,cb.centerX(),cb.centerY()+1f*u,15.5f*u*pulse,Color.WHITE);
        // Tiny streak meter communicates momentum without adding another button.
        RectF meter=new RectF(cb.left,cb.bottom+4f*u,cb.right,cb.bottom+9f*u);
        paint.setColor(Color.argb(90,0,0,0));c.drawRoundRect(meter,4f*u,4f*u,paint);
        float fill=Math.min(1f,combo/8f);
        roundedGradient(c,new RectF(meter.left,meter.top,meter.left+meter.width()*fill,meter.bottom),4f*u,Color.rgb(255,239,104),Color.rgb(255,117,164));
        if(combo>=5){
            for(int i=0;i<5;i++){
                float a=ambientTime*2.4f+i*1.257f;
                float sx=cb.left+cb.width()*.5f+(float)Math.cos(a)*cb.width()*.54f;
                float sy=cb.centerY()+(float)Math.sin(a)*12f*u;
                paint.setColor(Color.argb(150,255,247,170));c.drawCircle(sx,sy,(1.5f+i%2)*u,paint);
            }
        }
    }

    private void drawGame(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        drawLevelBackground(c);
        drawGameplayPolish(c);
        drawGameplayDepth(c);
        paint.setColor(Color.argb(28,255,255,255));c.drawRoundRect(new RectF(3f*u,3f*u,w-3f*u,h*.915f),16f*u,16f*u,paint);
        drawGameTopBar(c);
        float clearProgress=Math.min(1f,clearedBubbles/(float)Math.max(1,clearTarget));
        float progress=(objective==Objective.CLEAR||objective==Objective.LIMITED||objective==Objective.BOSS)?clearProgress:Math.min(1f,objectiveProgress/(float)Math.max(1,objectiveTarget));
        RectF objBg=new RectF(w*.235f,78f*u,w*.84f,94f*u);paint.setColor(Color.argb(165,22,29,83));c.drawRoundRect(objBg,9f*u,9f*u,paint);
        if(progress>0f){RectF obj=new RectF(objBg.left,objBg.top,objBg.left+objBg.width()*progress,objBg.bottom);roundedGradient(c,obj,9f*u,Color.rgb(76,245,136),Color.rgb(40,169,255));paint.setColor(Color.argb(95,255,255,255));c.drawRoundRect(new RectF(obj.left+2f*u,obj.top+2f*u,obj.right-2f*u,obj.top+6f*u),5f*u,5f*u,paint);}
        label(c,objectiveTitle()+" • "+objectiveDetail(),w*.54f,68f*u,10.2f*u,Color.WHITE);
        int dropIn=Math.max(0,pressureLimit-shotsSinceDrop);
        RectF pressure=new RectF(w*.70f,78f*u,w*.95f,95f*u);paint.setColor(Color.argb(155,77,35,92));c.drawRoundRect(pressure,9f*u,9f*u,paint);
        float pp=Math.min(1f,shotsSinceDrop/(float)Math.max(1,pressureLimit));if(pp>0f){RectF pf=new RectF(pressure.left,pressure.top,pressure.left+pressure.width()*pp,pressure.bottom);roundedGradient(c,pf,9f*u,Color.rgb(255,159,54),Color.rgb(241,62,88));}
        label(c,"DROP IN "+dropIn,pressure.centerX(),pressure.centerY(),9.3f*u,Color.WHITE);

        drawMovingBarriers(c);
        drawBubbleCeilingRail(c);
        drawDynamicFieldFx(c);
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.argb(90,255,255,255));for(float x=10f*u;x<w;x+=14f*u)c.drawLine(x,dangerY,x+6f*u,dangerY,stroke);
        ArrayList<Integer> keys=new ArrayList<>(grid.keySet());Collections.sort(keys);
        float dropVisual=rowDropTimer>0f?-rowH*Math.min(1f,rowDropTimer/.38f):0f;
        for(Integer k:keys){
            PointF q=cellCenter(rowOf(k),colOf(k));Integer color=grid.get(k);
            if(color!=null){
                float bx=q.x,by=q.y+dropVisual;
                if(impactTimer>0f){
                    // Earthquake-style board reaction: every bubble gets a strong shared
                    // tremor, while bubbles near the collision receive an additional punch.
                    float life=Math.min(1f,impactTimer/.68f);
                    float global=(float)Math.sin(ambientTime*58f)*impactStrength*.42f*life;
                    float globalY=(float)Math.cos(ambientTime*51f)*impactStrength*.30f*life;
                    bx+=global;
                    by+=globalY;
                    float d=dist(q.x,q.y,impactX,impactY);
                    float reach=bubbleR*6.2f;
                    if(d<reach){
                        float fall=1f-d/reach;
                        float wave=(float)Math.sin(ambientTime*48f+d*.14f);
                        float wave2=(float)Math.cos(ambientTime*43f+d*.10f);
                        bx+=wave*impactStrength*(.70f+.45f*fall)*fall*life;
                        by+=wave2*impactStrength*.58f*(.70f+.45f*fall)*fall*life;
                    }
                }
                drawBoardBubble(c,color,bx,by,bubbleR);
            }
        }
        for(FallingBubble f:falling){
            float fx=f.x,fy=f.y;
            if(impactTimer>0f){
                float life=Math.min(1f,impactTimer/.68f);
                fx+=(float)Math.sin(ambientTime*54f+f.x*.02f)*impactStrength*.34f*life;
                fy+=(float)Math.cos(ambientTime*49f+f.y*.018f)*impactStrength*.24f*life;
            }
            c.save();c.rotate(f.rot,fx,fy);drawBubbleSprite(c,f.color,fx,fy,bubbleR);c.restore();
        }
        if(aimGuideOn&&!shotInputBlocked())drawAimGuide(c);
        drawShooter(c);
        drawGameToolsTopButton(c);
        drawRealmCompanion(c);
        if(shotFlying){drawShotTrail(c);if(shotPower==Power.BOMB)drawBombBubble(c,shotX,shotY,bubbleR*.9f);else if(shotPower==Power.RAINBOW)drawRainbowBubble(c,shotX,shotY,bubbleR*.9f);else drawBubbleSprite(c,shotColor,shotX,shotY,bubbleR*.92f);}
        drawSuperPower(c);drawPowerups(c);drawFeverMeter(c);drawBossMeter(c);
        drawRingFx(c);
        drawCannonImpactFx(c);
        drawPraiseBanner(c);
        drawComboCinematic(c);
        for(Particle q:particles){float a=Math.max(0f,Math.min(1f,q.life/q.maxLife));int alpha=(int)(a*255);paint.setColor((q.color&0x00FFFFFF)|(alpha<<24));float rr=q.size*(.55f+.45f*a);c.drawCircle(q.x,q.y,rr,paint);if(q.size>6.2f){stroke.setStrokeWidth(Math.max(1f,1.25f*u));stroke.setColor(Color.argb(Math.min(220,alpha),255,255,255));c.drawLine(q.x-rr*1.25f,q.y,q.x+rr*1.25f,q.y,stroke);c.drawLine(q.x,q.y-rr*1.25f,q.x,q.y+rr*1.25f,stroke);}}
        for(GlassShard q:glassShards){
            // Physical debris must remain visible throughout its fall. Its life timer
            // is used for settling bookkeeping, not visual fading; fading airborne
            // chunks here made later match explosions appear to produce no debris.
            float a=1f;
            int alpha=(int)(a*(q.concrete?245:230));
            c.save(); c.translate(q.x,q.y); c.rotate(q.rot);
            Path sh=new Path();
            if(q.concrete){
                // Irregular, weighty chunks with a dark edge and a small dusty highlight.
                if(q.settled){
                    paint.setColor(Color.argb((int)(alpha*.30f),8,9,12));
                    c.drawOval(new RectF(-q.w*.72f,q.h*.30f,q.w*.72f,q.h*.72f),paint);
                }
                sh.moveTo(-q.w*.62f,q.h*.08f); sh.lineTo(-q.w*.39f,-q.h*.54f);
                sh.lineTo(-q.w*.07f,-q.h*.68f); sh.lineTo(q.w*.29f,-q.h*.47f);
                sh.lineTo(q.w*.61f,-q.h*.02f); sh.lineTo(q.w*.43f,q.h*.43f);
                sh.lineTo(q.w*.10f,q.h*.62f); sh.lineTo(-q.w*.37f,q.h*.48f); sh.close();
                // Same family as the broken bubble, with only subtle shading so the
                // debris reads as colored material rather than black concrete.
                paint.setColor((q.color&0x00FFFFFF)|(alpha<<24)); c.drawPath(sh,paint);
                Path facet=new Path();
                facet.moveTo(-q.w*.39f,-q.h*.54f); facet.lineTo(-q.w*.07f,-q.h*.68f);
                facet.lineTo(q.w*.29f,-q.h*.47f); facet.lineTo(q.w*.04f,-q.h*.12f); facet.close();
                paint.setColor((lighten(q.color,.10f)&0x00FFFFFF)|((int)(alpha*.72f)<<24)); c.drawPath(facet,paint);
                Path side=new Path();
                side.moveTo(q.w*.29f,-q.h*.47f); side.lineTo(q.w*.61f,-q.h*.02f);
                side.lineTo(q.w*.43f,q.h*.43f); side.lineTo(q.w*.10f,q.h*.62f);
                side.lineTo(q.w*.04f,-q.h*.12f); side.close();
                paint.setColor((darken(q.color,.16f)&0x00FFFFFF)|((int)(alpha*.78f)<<24)); c.drawPath(side,paint);
                stroke.setStrokeWidth(Math.max(.9f,u*.62f)); stroke.setColor(Color.argb((int)(alpha*.48f),30,34,42)); c.drawPath(sh,stroke);
                stroke.setStrokeWidth(Math.max(.7f,u*.42f)); stroke.setColor(Color.argb((int)(alpha*.38f),255,255,255));
                c.drawLine(-q.w*.30f,-q.h*.28f,q.w*.13f,-q.h*.40f,stroke);
            }else{
                sh.moveTo(-q.w*.54f,q.h*.34f); sh.lineTo(-q.w*.14f,-q.h*.57f);
                sh.lineTo(q.w*.46f,-q.h*.12f); sh.lineTo(q.w*.27f,q.h*.46f);
                sh.close();
                paint.setColor((q.color&0x00FFFFFF)|(alpha<<24)); c.drawPath(sh,paint);
                stroke.setStrokeWidth(Math.max(.8f,u*.8f)); stroke.setColor(Color.argb((int)(alpha*.52f),70,72,78)); c.drawPath(sh,stroke);
            }
            c.restore();
        }
        for(FloatingText ft:floatingTexts){int a=(int)(255*Math.min(1f,ft.life/.35f));label(c,ft.text,ft.x,ft.y,ft.size*u,(ft.color&0x00FFFFFF)|(a<<24));}
        if(popFlash>0f){paint.setColor(Color.argb((int)(48*popFlash),255,255,255));c.drawRect(0,0,w,h,paint);}
        if(feverBurst>0f){paint.setShader(new RadialGradient(w*.5f,h*.46f,w*.62f,Color.argb((int)(70*feverBurst),255,231,77),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(w*.5f,h*.46f,w*.62f,paint);paint.setShader(null);}
        if(perfectShotTimer>0f&&overlay==Overlay.NONE){float a=Math.min(1f,perfectShotTimer/.30f);float pulse=1f+.08f*(float)Math.sin(ambientTime*12f);labelOutline(c,"PERFECT SHOT!",w*.5f,h*.36f,34f*u*pulse,Color.rgb(255,238,90),Color.rgb(142,50,93));stroke.setStrokeWidth(3f*u);stroke.setColor(Color.argb((int)(170*a),255,230,91));c.drawCircle(w*.5f,h*.36f,62f*u*(1.3f-a*.3f),stroke);}
        if(almostThereAnnounced&&clearProgress>=.82f&&overlay==Overlay.NONE){float glow=.5f+.5f*(float)Math.sin(ambientTime*5.5f);stroke.setStrokeWidth((2f+2f*glow)*u);stroke.setColor(Color.argb((int)(65+75*glow),255,230,93));c.drawRoundRect(new RectF(7f*u,102f*u,w-7f*u,h*.82f),18f*u,18f*u,stroke);}
        if(levelIntroTimer>0f&&overlay==Overlay.NONE){
            float elapsedIntro=LEVEL_INTRO_DURATION-levelIntroTimer;
            float inT=clamp01(elapsedIntro/.58f);
            float outT=clamp01((LEVEL_INTRO_DURATION-elapsedIntro)/.52f);
            float alpha=Math.min(1f,inT)*(1f-.72f*outT);
            float pop=easeOutBack(inT);
            float pulse=.5f+.5f*(float)Math.sin(ambientTime*6.2f);
            // Start banner intentionally uses the SAME panel/header language as LEVEL COMPLETE.
            RectF intro=new RectF(w*.075f,h*.135f,w*.925f,h*.735f);
            c.save();
            c.scale(.90f+.10f*pop,.90f+.10f*pop,intro.centerX(),intro.centerY());
            // Rich multi-colour reveal glow behind the level card.
            paint.setShader(new RadialGradient(intro.centerX(),intro.centerY(),intro.width()*.70f,
                    new int[]{Color.argb((int)(82*alpha),60,220,255),Color.argb((int)(70*alpha),128,82,255),Color.argb((int)(62*alpha),255,72,174),Color.TRANSPARENT},
                    new float[]{0f,.34f,.66f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(intro.centerX(),intro.centerY(),intro.width()*.70f,paint);paint.setShader(null);
            // Four floating colour orbs make the reveal feel brighter without covering the text.
            for(int orb=0;orb<4;orb++){
                float oa=ambientTime*(.65f+.08f*orb)+orb*1.5708f;
                float ox=intro.centerX()+(float)Math.cos(oa)*intro.width()*.39f;
                float oy=intro.centerY()+(float)Math.sin(oa)*intro.height()*.28f;
                int oc=orb==0?Color.rgb(54,224,255):(orb==1?Color.rgb(255,83,169):(orb==2?Color.rgb(255,211,65):Color.rgb(167,91,255)));
                paint.setShader(new RadialGradient(ox,oy,30f*u,Color.argb((int)(105*alpha),Color.red(oc),Color.green(oc),Color.blue(oc)),Color.TRANSPARENT,Shader.TileMode.CLAMP));
                c.drawCircle(ox,oy,30f*u,paint);paint.setShader(null);
            }
            // Animated entrance: rotating light rays behind the panel make the banner feel like a level reveal.
            c.save();
            c.rotate(ambientTime*9f,intro.centerX(),intro.centerY());
            for(int ray=0;ray<12;ray++){
                float ra=ray*(float)Math.PI*2f/12f;
                float x1=intro.centerX()+(float)Math.cos(ra)*intro.width()*.30f;
                float y1=intro.centerY()+(float)Math.sin(ra)*intro.height()*.30f;
                float x2=intro.centerX()+(float)Math.cos(ra)*intro.width()*.68f;
                float y2=intro.centerY()+(float)Math.sin(ra)*intro.height()*.68f;
                stroke.setStrokeWidth((1.5f+(ray%3))*u);
                int rayCol=ray%4==0?Color.rgb(255,92,170):(ray%4==1?Color.rgb(86,224,255):(ray%4==2?Color.rgb(255,210,72):Color.rgb(170,102,255)));
                stroke.setColor(Color.argb((int)(70*alpha),Color.red(rayCol),Color.green(rayCol),Color.blue(rayCol)));
                c.drawLine(x1,y1,x2,y2,stroke);
            }
            c.restore();

            // v5.5.6: level-start card now matches the dark, solid paused-menu language.
            paint.setShader(new LinearGradient(intro.left,intro.top,intro.right,intro.bottom,
                    Color.argb(248,7,10,22),Color.argb(244,18,21,39),Shader.TileMode.CLAMP));
            c.drawRoundRect(intro,24f*u,24f*u,paint);paint.setShader(null);
            stroke.setStrokeWidth(2.4f*u);stroke.setColor(Color.argb(225,88,99,135));
            c.drawRoundRect(new RectF(intro.left+1f*u,intro.top+1f*u,intro.right-1f*u,intro.bottom-1f*u),23f*u,23f*u,stroke);
            paint.setColor(Color.argb(55,255,255,255));
            c.drawRoundRect(new RectF(intro.left+4f*u,intro.top+4f*u,intro.right-4f*u,intro.top+28f*u),19f*u,19f*u,paint);
            drawPanelHeader(c,intro,gameMode==GameMode.SURVIVAL?("SURVIVAL WAVE "+survivalWave):(gameMode==GameMode.TREASURE_ROOM?"TREASURE ROOM":((dailyChallengeMode?"DAILY • ":"")+(isBossLevel(selectedLevel)?"BOSS LEVEL ":"LEVEL ")+selectedLevel)),false);

            // Start banner: no star crown. Use the same premium completion-style
            // hierarchy, but give the current LEVEL number a larger animated title.
            float titleY=intro.top+112f*u;
            float titlePulse=1f+.045f*(float)Math.sin(ambientTime*7.2f);
            RectF titleRibbon=new RectF(intro.left+30f*u,titleY-34f*u,intro.right-30f*u,titleY+34f*u);
            paint.setShader(new LinearGradient(titleRibbon.left,0,titleRibbon.right,0,new int[]{Color.rgb(42,211,255),Color.rgb(84,102,255),Color.rgb(185,76,235),Color.rgb(255,82,150)},null,Shader.TileMode.CLAMP));
            c.drawRoundRect(titleRibbon,22f*u,22f*u,paint);paint.setShader(null);
            stroke.setStrokeWidth(3.0f*u);stroke.setColor(Color.argb(235,225,248,255));c.drawRoundRect(titleRibbon,22f*u,22f*u,stroke);
            stroke.setStrokeWidth((1.2f+2.0f*pulse)*u);stroke.setColor(Color.argb((int)(95+95*pulse),116,239,255));c.drawRoundRect(new RectF(titleRibbon.left-4f*u,titleRibbon.top-4f*u,titleRibbon.right+4f*u,titleRibbon.bottom+4f*u),25f*u,25f*u,stroke);
            c.save();c.scale(titlePulse,titlePulse,intro.centerX(),titleY);
            labelOutline(c,"LEVEL "+selectedLevel,intro.centerX(),titleY,33f*u,Color.WHITE,Color.rgb(31,54,151));
            c.restore();
            // Animated shine sweeps across the level ribbon.
            float shine=((ambientTime*.55f)%1.4f)-.2f;
            float sx=intro.left+(intro.width()*shine);
            paint.setShader(new LinearGradient(sx-34f*u,0,sx+34f*u,0,Color.TRANSPARENT,Color.argb((int)(110*alpha),255,255,255),Shader.TileMode.MIRROR));
            c.drawRect(intro.left+42f*u,titleRibbon.top,intro.right-42f*u,titleRibbon.bottom,paint);paint.setShader(null);
            labelOutline(c,objectiveTitle(),intro.centerX(),intro.top+154f*u,16f*u,Color.WHITE,Color.rgb(117,42,166));
            RectF info=new RectF(intro.left+28f*u,intro.top+184f*u,intro.right-28f*u,intro.top+274f*u);
            paint.setShader(new LinearGradient(info.left,info.top,info.right,info.bottom,new int[]{Color.rgb(45,171,236),Color.rgb(83,72,192),Color.rgb(123,52,166)},null,Shader.TileMode.CLAMP));
            c.drawRoundRect(info,18f*u,18f*u,paint);paint.setShader(null);
            labelOutline(c,objectiveDetail(),info.centerX(),info.top+35f*u,22f*u,Color.WHITE,Color.rgb(35,50,125));
            String route=activeBranchRoute>0?(" • "+branchRouteName(activeBranchRoute)):"";
            String field=(windForce!=0f?" • WIND":"")+(gravityForce!=0f?" • GRAVITY":"")+(formationMode>0?" • MOVING BOARD":"")+(movingBarrierMode>0?" • BUMPER":"");
            label(c,worldName(selectedLevel)+route+field,info.centerX(),info.top+67f*u,10.5f*u,Color.rgb(198,231,255));
            float pulseScale=1f+.035f*(float)Math.sin(ambientTime*8.0f);
            c.save();c.scale(pulseScale,pulseScale,intro.centerX(),intro.top+322f*u);
            labelOutline(c,"GET READY • AIM • POP!",intro.centerX(),intro.top+322f*u,18f*u,Color.WHITE,Color.rgb(54,74,166));
            c.restore();
            for(int i=0;i<8;i++){
                float a=ambientTime*1.7f+i*.897f;
                float sparkleX=intro.left+34f*u+(i/7f)*(intro.width()-68f*u);
                float sy=intro.top+84f*u+(float)Math.sin(a)*7f*u;
                paint.setColor(Color.argb((int)((90+105*pulse)*alpha),255,244,175));
                c.drawCircle(sparkleX,sy,(1.5f+(i%3))*u,paint);
            }
            c.restore();
        }
    }

    private void spawnLandingSparkles(float x,float y,int colorIndex){
        int base=PALETTE[Math.max(0,Math.min(PALETTE.length-1,colorIndex))];
        for(int i=0;i<10;i++){
            float a=(float)(i*Math.PI*2.0/10.0)+random.nextFloat()*.24f;
            float sp=70f+random.nextFloat()*170f;
            particles.add(new Particle(x,y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp-35f,base,2.2f+random.nextFloat()*2.8f,.34f+random.nextFloat()*.28f));
        }
        for(int i=0;i<4;i++){
            float a=random.nextFloat()*6.283f,sp=110f+random.nextFloat()*150f;
            particles.add(new Particle(x,y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp,Color.WHITE,1.8f+random.nextFloat()*1.4f,.28f+random.nextFloat()*.20f));
        }
    }

    private void drawShotTrail(Canvas c) {
        float speed=(float)Math.sqrt(shotVx*shotVx+shotVy*shotVy); if(speed<1f)return;
        float ux=shotVx/speed,uy=shotVy/speed,px=-uy,py=ux,u=uiScale();
        int base=shotPower==Power.NORMAL?PALETTE[Math.max(0,Math.min(PALETTE.length-1,shotColor))]:Color.WHITE;
        float rearX=shotX-ux*bubbleR*.72f,rearY=shotY-uy*bubbleR*.72f;
        paint.setShader(new RadialGradient(rearX,rearY,bubbleR*2.15f,
                new int[]{Color.argb(235,255,255,238),Color.argb(205,255,133,30),Color.argb(85,255,48,12),Color.TRANSPARENT},
                new float[]{0f,.24f,.58f,1f},Shader.TileMode.CLAMP));
        c.drawCircle(rearX,rearY,bubbleR*2.15f,paint);paint.setShader(null);
        for(int i=0;i<18;i++){
            float side=(random.nextFloat()-.5f)*bubbleR*1.08f;
            float len=bubbleR*(.75f+random.nextFloat()*2.35f);
            float wob=(float)Math.sin(ambientTime*24f+i*1.9f)*bubbleR*.12f;
            float bx=rearX+px*side+ux*wob,by=rearY+py*side+uy*wob;
            Path flame=new Path();
            flame.moveTo(bx+px*bubbleR*.10f,by+py*bubbleR*.10f);
            flame.lineTo(bx-ux*len,by-uy*len);
            flame.lineTo(bx-px*bubbleR*.10f+ux*len*.25f,by-py*bubbleR*.10f+uy*len*.25f);
            flame.close();
            int col=i%3==0?Color.rgb(255,247,196):(i%3==1?Color.rgb(255,156,35):Color.rgb(255,63,18));
            paint.setColor(Color.argb(210-i*11,Color.red(col),Color.green(col),Color.blue(col)));
            c.drawPath(flame,paint);
        }
        for(int i=1;i<=18;i++){
            float t=i*.20f;
            float wob=(float)Math.sin(ambientTime*19f+i*1.37f)*bubbleR*.075f*i;
            float tx=shotX-ux*bubbleR*(.82f+t)+px*wob,ty=shotY-uy*bubbleR*(.82f+t)+py*wob;
            float rr=bubbleR*(.25f-i*.013f);
            int alpha=Math.max(10,120-i*9);
            paint.setColor(Color.argb(alpha,Color.red(base),Color.green(base),Color.blue(base)));
            c.drawCircle(tx,ty,Math.max(2f,rr),paint);
            paint.setColor(Color.argb(Math.max(10,125-i*10),255,220,130));
            c.drawCircle(tx-ux*rr*.35f,ty-uy*rr*.35f,Math.max(1f,rr*.30f),paint);
        }
        for(int i=0;i<8;i++){
            float t=.25f+random.nextFloat()*1.9f,side=(random.nextFloat()-.5f)*bubbleR*1.55f;
            float sx=rearX-ux*bubbleR*t+px*side,sy=rearY-uy*bubbleR*t+py*side;
            paint.setColor(Color.argb((int)(165*(1f-t/2.2f)),255,random.nextInt(90)+130,35));
            c.drawCircle(sx,sy,(1.2f+random.nextFloat()*2.4f)*u,paint);
        }
        stroke.setStrokeWidth(2.0f*u);stroke.setColor(Color.argb(225,255,255,255));
        c.drawLine(shotX-ux*bubbleR*.50f+px*bubbleR*.34f,shotY-uy*bubbleR*.50f+py*bubbleR*.34f,
                   shotX-ux*bubbleR*.10f+px*bubbleR*.34f,shotY-uy*bubbleR*.10f+py*bubbleR*.34f,stroke);
    }

    private void drawBubbleCeilingRail(Canvas c) {
        float w=getWidth(),u=uiScale();
        // Use the ACTUAL row-0 position so the ceiling always touches the visible board,
        // even when early-level lift/progress/formation settings change the board height.
        PointF first=cellCenter(0,0);
        float bubbleTop=first.y-bubbleR;
        float shelfBottom=bubbleTop+3f*u;
        float shelfTop=Math.max(120f*u,shelfBottom-25f*u);

        // A wide translucent canopy fills the former empty gap below FEVER/objective UI.
        RectF canopy=new RectF(8f*u,shelfTop,w-8f*u,shelfBottom);
        paint.setShader(new LinearGradient(0,canopy.top,0,canopy.bottom,
                Color.argb(225,47,70,137),Color.argb(238,18,35,91),Shader.TileMode.CLAMP));
        c.drawRoundRect(canopy,11f*u,11f*u,paint);paint.setShader(null);
        paint.setColor(Color.argb(75,255,255,255));
        c.drawRoundRect(new RectF(canopy.left+3f*u,canopy.top+2f*u,canopy.right-3f*u,canopy.top+7f*u),7f*u,7f*u,paint);
        stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.argb(215,211,236,255));
        c.drawRoundRect(canopy,11f*u,11f*u,stroke);

        // Thick lower lip creates a clear physical ceiling edge directly above the bubbles.
        RectF rail=new RectF(10f*u,shelfBottom-8f*u,w-10f*u,shelfBottom+2.5f*u);
        paint.setShader(new LinearGradient(rail.left,rail.top,rail.right,rail.bottom,
                Color.rgb(99,222,255),Color.rgb(98,81,214),Shader.TileMode.CLAMP));
        c.drawRoundRect(rail,5.5f*u,5.5f*u,paint);paint.setShader(null);
        paint.setColor(Color.argb(175,255,255,255));
        c.drawRoundRect(new RectF(rail.left+4f*u,rail.top+1f*u,rail.right-4f*u,rail.top+3.2f*u),2f*u,2f*u,paint);
        stroke.setStrokeWidth(1.6f*u);stroke.setColor(Color.argb(230,230,246,255));c.drawRoundRect(rail,5.5f*u,5.5f*u,stroke);

        // Short hangers/studs visually connect row 0 to the ceiling instead of leaving it floating.
        float usable=w-bubbleR*2.2f;
        float spacing=usable/(GRID_COLS-.5f);
        for(int col=0;col<GRID_COLS;col++){
            float x=bubbleR*1.1f+col*spacing+(gridParityPhase==1?spacing*.5f:0f);
            if(x>w-8f*u)continue;
            stroke.setStrokeWidth(2.0f*u);stroke.setColor(Color.argb(175,205,235,255));
            c.drawLine(x,shelfBottom,x,bubbleTop+2f*u,stroke);
            paint.setColor(Color.argb(220,240,249,255));c.drawCircle(x,shelfBottom-1f*u,2.3f*u,paint);
        }
    }

    private void drawGameTopBar(Canvas c) {
        float w=getWidth(),u=uiScale();RectF top=new RectF(5f*u,5f*u,w-5f*u,88f*u);
        paint.setColor(Color.argb(160,3,8,45));c.drawRoundRect(new RectF(top.left,top.top+7f*u,top.right,top.bottom+7f*u),23f*u,23f*u,paint);
        roundedGradient(c,top,23f*u,Color.rgb(48,62,167),Color.rgb(17,26,91));stroke.setStrokeWidth(2.5f*u);stroke.setColor(Color.argb(230,220,242,255));c.drawRoundRect(top,23f*u,23f*u,stroke);
        paint.setColor(Color.argb(95,255,255,255));c.drawRoundRect(new RectF(top.left+4f*u,top.top+4f*u,top.right-4f*u,top.top+25f*u),19f*u,19f*u,paint);
        // Strong lower separator keeps the HUD visually distinct from the bubble board.
        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.argb(210,217,239,255));
        c.drawLine(top.left+22f*u,top.bottom-2f*u,top.right-22f*u,top.bottom-2f*u,stroke);
        float l=81f*u,right=w-8f*u,cw=(right-l)/4f;
        String firstCap=gameMode==GameMode.SURVIVAL?"WAVE":gameMode==GameMode.TREASURE_ROOM?"BONUS":"LEVEL";
        String[] cap={firstCap,"SCORE","GOAL","COINS"};
        String goalVal=(objective==Objective.CLEAR||objective==Objective.LIMITED||objective==Objective.BOSS)?Math.min(100,Math.round(clearedBubbles*100f/Math.max(1,initialBubbleCount)))+"%":Math.min(objectiveProgress,objectiveTarget)+"/"+Math.max(1,objectiveTarget);
        String firstVal=gameMode==GameMode.SURVIVAL?String.valueOf(survivalWave):gameMode==GameMode.TREASURE_ROOM?"ROOM":String.valueOf(selectedLevel);
        String[] val={firstVal,String.valueOf(levelScore),goalVal,String.valueOf(coins)};
        for(int i=0;i<4;i++){RectF cell=new RectF(l+i*cw+2f*u,13f*u,l+(i+1)*cw-3f*u,79f*u);paint.setColor(Color.argb(42,255,255,255));c.drawRoundRect(cell,14f*u,14f*u,paint);stroke.setStrokeWidth(1f*u);stroke.setColor(Color.argb(95,255,255,255));c.drawRoundRect(cell,14f*u,14f*u,stroke);label(c,cap[i],cell.centerX(),27f*u,10.5f*u,Color.rgb(210,229,255));label(c,val[i],cell.centerX(),55f*u,i==1?17f*u:19f*u,Color.WHITE);}
    }

    private void drawShooter(Canvas c) {
        float r=bubbleR*1.55f,u=uiScale();
        float dx=(float)Math.cos(aimAngle),dy=(float)Math.sin(aimAngle);
        float lp=.5f+.5f*(float)Math.sin(launcherPulse*4.6f);
        float recoil=cannonRecoil*r*.50f;

        // Ground shadow under the cannon.
        paint.setShader(new RadialGradient(shooterX,shooterY+r*1.55f,r*3.4f,
                Color.argb(105,0,0,0),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawOval(new RectF(shooterX-r*2.8f,shooterY+r*.92f,shooterX+r*3.1f,shooterY+r*2.15f),paint);
        paint.setShader(null);

        // Fixed dark triangular artillery mount, matching the reference silhouette.
        Path mount=new Path();
        mount.moveTo(shooterX-r*1.20f,shooterY+r*.95f);
        mount.lineTo(shooterX-r*.22f,shooterY+r*.02f);
        mount.lineTo(shooterX+r*1.22f,shooterY+r*.98f);
        mount.close();
        paint.setShader(new LinearGradient(shooterX,shooterY,shooterX,shooterY+r*1.2f,
                Color.rgb(34,36,38),Color.rgb(5,6,8),Shader.TileMode.CLAMP));
        c.drawPath(mount,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.4f*u);stroke.setColor(Color.rgb(55,58,62));c.drawPath(mount,stroke);
        // Mount foot.
        paint.setColor(Color.rgb(8,9,11));
        c.drawRoundRect(new RectF(shooterX-r*1.28f,shooterY+r*.92f,shooterX+r*1.30f,shooterY+r*1.18f),r*.12f,r*.12f,paint);
        stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.rgb(49,52,56));
        c.drawRoundRect(new RectF(shooterX-r*1.28f,shooterY+r*.92f,shooterX+r*1.30f,shooterY+r*1.18f),r*.12f,r*.12f,stroke);

        c.save();
        float cannonJitter=(cannonFireTimer>0f)?(float)Math.sin(ambientTime*86f)*4.2f*(cannonFireTimer/.48f):0f;
        float cannonKick=(cannonFireTimer>0f)?cannonRecoil*r*.62f:0f;
        c.translate(-dx*cannonKick,-dy*cannonKick);
        c.rotate((float)Math.toDegrees(aimAngle)+cannonJitter,shooterX,shooterY);

        float back=-r*1.48f-recoil, bodyFront=r*1.28f-recoil, muzzle=r*3.02f-recoil;

        // Full continuous cannon housing. The housing is intentionally built as a
        // symmetric rounded bulb around the barrel axis. This is important: the
        // previous versions rounded only the rear edge, so when the cannon pointed
        // vertically the visible left wall could still read as a flat straight edge.
        // Here both sides have the same deep half-round curvature.
        Path body=new Path();
        float frontX=shooterX+bodyFront-r*.34f;
        float rearTip=shooterX+back;
        float sideR=r*.92f;
        // Upper side of the bulb (one side of the cannon).
        body.moveTo(frontX,shooterY-r*.43f);
        body.cubicTo(shooterX+bodyFront-r*.72f,shooterY-r*.70f,
                shooterX+back+r*.70f,shooterY-r*.98f,
                shooterX+back+r*.30f,shooterY-r*.82f);
        body.cubicTo(shooterX+back-r*.08f,shooterY-r*.55f,
                rearTip-r*.02f,shooterY-r*.20f,
                rearTip,shooterY);
        // Lower side is a mirrored deep half-round, so the opposite visible edge
        // cannot become a flat vertical wall.
        body.cubicTo(rearTip-r*.02f,shooterY+r*.20f,
                shooterX+back-r*.08f,shooterY+r*.55f,
                shooterX+back+r*.30f,shooterY+r*.82f);
        body.cubicTo(shooterX+back+r*.70f,shooterY+r*.98f,
                shooterX+bodyFront-r*.72f,shooterY+r*.70f,
                frontX,shooterY+r*.43f);
        // Narrow front shoulder around the barrel.
        body.cubicTo(shooterX+bodyFront+r*.02f,shooterY+r*.30f,
                shooterX+bodyFront+r*.08f,shooterY+r*.04f,
                shooterX+bodyFront+r*.08f,shooterY-r*.04f);
        body.cubicTo(shooterX+bodyFront+r*.08f,shooterY-r*.18f,
                shooterX+bodyFront-r*.02f,shooterY-r*.34f,
                frontX,shooterY-r*.43f);
        body.close();

        paint.setShader(new LinearGradient(0,shooterY-r*.75f,0,shooterY+r*.75f,
                new int[]{Color.rgb(34,36,39),Color.rgb(9,10,12),Color.rgb(0,1,2)},null,Shader.TileMode.CLAMP));
        c.drawPath(body,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.6f*u);stroke.setColor(Color.rgb(49,52,56));c.drawPath(body,stroke);

        // Short tapered barrel in the same dark metal finish.
        Path barrel=new Path();
        barrel.moveTo(shooterX+bodyFront-r*.38f,shooterY-r*.46f);
        barrel.lineTo(shooterX+muzzle-r*.34f,shooterY-r*.30f);
        barrel.lineTo(shooterX+muzzle,shooterY-r*.45f);
        barrel.lineTo(shooterX+muzzle+r*.03f,shooterY+r*.45f);
        barrel.lineTo(shooterX+muzzle-r*.34f,shooterY+r*.30f);
        barrel.lineTo(shooterX+bodyFront-r*.38f,shooterY+r*.46f);
        barrel.close();
        paint.setShader(new LinearGradient(0,shooterY-r*.5f,0,shooterY+r*.5f,
                new int[]{Color.rgb(24,26,29),Color.rgb(8,9,11),Color.rgb(1,2,3)},null,Shader.TileMode.CLAMP));
        c.drawPath(barrel,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.0f*u);stroke.setColor(Color.rgb(39,42,46));c.drawPath(barrel,stroke);

        // Soft metal highlight on top, kept almost black.
        paint.setColor(Color.argb(135,225,230,235));
        c.drawRoundRect(new RectF(shooterX+back+r*.58f,shooterY-r*.48f,shooterX+muzzle-r*.52f,shooterY-r*.34f),r*.07f,r*.07f,paint);

        // Two compact reinforcement bands and a thick muzzle collar.
        for(int i=0;i<2;i++){
            float bx=shooterX+muzzle-r*(.48f+i*.28f);
            paint.setShader(new LinearGradient(bx-r*.10f,shooterY-r*.55f,bx+r*.10f,shooterY+r*.55f,
                    Color.rgb(39,42,46),Color.rgb(4,5,7),Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(bx-r*.13f,shooterY-r*.54f,bx+r*.13f,shooterY+r*.54f),r*.08f,r*.08f,paint);paint.setShader(null);
            stroke.setStrokeWidth(1.4f*u);stroke.setColor(Color.rgb(56,59,64));
            c.drawRoundRect(new RectF(bx-r*.13f,shooterY-r*.52f,bx+r*.13f,shooterY+r*.52f),r*.08f,r*.08f,stroke);
        }

        float boreX=shooterX+muzzle+r*.02f;
        paint.setColor(Color.rgb(1,1,2));
        c.drawOval(new RectF(boreX-r*.30f,shooterY-r*.54f,boreX+r*.12f,shooterY+r*.54f),paint);
        paint.setShader(new RadialGradient(boreX-r*.10f,shooterY-r*.05f,r*.32f,
                Color.rgb(49,52,56),Color.BLACK,Shader.TileMode.CLAMP));
        c.drawOval(new RectF(boreX-r*.25f,shooterY-r*.41f,boreX+r*.05f,shooterY+r*.41f),paint);paint.setShader(null);
        stroke.setStrokeWidth(2.7f*u);stroke.setColor(Color.rgb(47,50,54));
        c.drawOval(new RectF(boreX-r*.32f,shooterY-r*.56f,boreX+r*.15f,shooterY+r*.56f),stroke);

        // Rear pivot / loading chamber: the loaded bubble sits here, not above the cannon.
        paint.setShader(new RadialGradient(shooterX-r*.52f,shooterY,r*.56f,
                Color.rgb(45,48,52),Color.rgb(5,6,8),Shader.TileMode.CLAMP));
        c.drawCircle(shooterX-r*.52f,shooterY,r*.52f,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.0f*u);stroke.setColor(Color.rgb(58,61,65));
        c.drawCircle(shooterX-r*.52f,shooterY,r*.52f,stroke);
        paint.setColor(Color.rgb(9,10,12));c.drawCircle(shooterX-r*.52f,shooterY,r*.31f,paint);
        c.restore();

        // Loaded bubble is seated in the rear chamber.
        float loadX=shooterX-r*.52f-recoil*dx*.20f,loadY=shooterY-recoil*dy*.20f;
        if(power==Power.BOMB)drawBombBubble(c,loadX,loadY,r*.58f);
        else if(power==Power.RAINBOW)drawRainbowBubble(c,loadX,loadY,r*.60f);
        else drawBubbleSprite(c,currentColor,loadX,loadY,r*.62f);

        // Strong, short muzzle fire synced with the actual cannon recoil.
        if(cannonFireTimer>0f){
            float muzzleX=shooterX+dx*(r*3.02f-recoil+r*.16f), muzzleY=shooterY+dy*(r*3.02f-recoil+r*.16f);
            float a=Math.min(1f,cannonFireTimer/.42f);
            paint.setShader(new RadialGradient(muzzleX,muzzleY,r*1.75f,
                    new int[]{Color.argb((int)(255*a),255,255,235),Color.argb((int)(220*a),255,125,22),Color.TRANSPARENT},
                    new float[]{0f,.30f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(muzzleX,muzzleY,r*1.75f,paint);paint.setShader(null);
            for(int i=0;i<24;i++){
                float side=(random.nextFloat()-.5f)*r*1.25f;
                float len=r*(1.0f+random.nextFloat()*2.6f)*(0.58f+.42f*a);
                float bx=muzzleX-dy*side,by=muzzleY+dx*side;
                Path flame=new Path();
                flame.moveTo(bx-dy*r*.15f,by+dx*r*.15f);
                flame.lineTo(bx+dx*len,by+dy*len);
                flame.lineTo(bx+dx*len*.46f+dy*r*.20f,by+dy*len*.46f-dx*r*.20f);
                flame.close();
                int fc=i%4==0?Color.WHITE:(i%3==0?Color.rgb(255,212,68):Color.rgb(255,92,14));
                paint.setColor(Color.argb((int)((155+i%3*30)*a),Color.red(fc),Color.green(fc),Color.blue(fc)));
                c.drawPath(flame,paint);
            }
        }

        // Next bubble remains clear of the cannon body.
        float nextX=shooterX+r*3.35f,nextY=shooterY+r*.05f;
        paint.setShader(new RadialGradient(nextX,nextY,r*1.12f,Color.argb(145,255,255,255),Color.argb(55,45,50,58),Shader.TileMode.CLAMP));
        c.drawCircle(nextX,nextY,r*.92f,paint);paint.setShader(null);
        stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.argb(160,255,255,255));c.drawCircle(nextX,nextY,r*.90f,stroke);
        drawBubbleSprite(c,nextColor,nextX,nextY,r*.70f);label(c,"NEXT",nextX,nextY+r*1.23f,11f*u,Color.WHITE);

        float countX=shooterX-r*2.35f,countY=shooterY+r*.72f;
        paint.setShader(new RadialGradient(countX,countY,26f*u,Color.WHITE,Color.rgb(38,42,47),Shader.TileMode.CLAMP));
        c.drawCircle(countX,countY,23f*u,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.WHITE);c.drawCircle(countX,countY,23f*u,stroke);
        label(c,String.valueOf(shotsLeft),countX,countY,18f*u,Color.WHITE);
    }

    private void drawAimGuide(Canvas c) {
        float dx=(float)Math.cos(aimAngle),dy=(float)Math.sin(aimAngle);
        float x=shooterX,y=shooterY;
        float step=bubbleR*.88f;
        float u=uiScale();
        int bounces=0;

        // No arrow: fifteen darker premium trajectory dots form a long selectable aiming guide.
        // The invisible touch track below matches all visible dots.
        for(int i=0;i<15;i++){
            x+=dx*step; y+=dy*step;
            if(x<bubbleR){x=bubbleR+(bubbleR-x);dx=-dx;bounces++;}
            if(x>getWidth()-bubbleR){x=getWidth()-bubbleR-(x-(getWidth()-bubbleR));dx=-dx;bounces++;}
            float pulse=.82f+.18f*(float)Math.sin(ambientTime*7f-i*.55f);
            float rr=Math.max(4.0f,bubbleR*.14f)*pulse;
            paint.setShader(new RadialGradient(x,y,rr*3.8f,
                    Color.argb(72,70,82,105),Color.TRANSPARENT,Shader.TileMode.CLAMP));
            c.drawCircle(x,y,rr*3.8f,paint);paint.setShader(null);
            paint.setShader(new RadialGradient(x-rr*.25f,y-rr*.30f,rr,
                    Color.rgb(108,119,136),Color.rgb(35,43,58),Shader.TileMode.CLAMP));
            c.drawCircle(x,y,rr,paint);paint.setShader(null);
            stroke.setStrokeWidth(1.5f*u);stroke.setColor(Color.argb(220,58,68,86));
            c.drawCircle(x,y,rr,stroke);
            // Keep the guide visible all the way to the extended selectable endpoint.
        }
    }

    private void drawGameToolsTopButton(Canvas c) {
        float u=uiScale();
        float x=39f*u,y=46f*u;
        float pulse=1f+.025f*(float)Math.sin(ambientTime*4.2f);
        RectF main=new RectF(x-28f*u,y-28f*u,x+28f*u,y+28f*u);
        paint.setColor(Color.argb(125,0,0,0));
        c.drawRoundRect(new RectF(main.left,main.top+6f*u,main.right,main.bottom+6f*u),15f*u,15f*u,paint);
        roundedGradient(c,main,15f*u,Color.rgb(72,198,255),Color.rgb(45,76,203));
        stroke.setStrokeWidth(2.3f*u);stroke.setColor(Color.rgb(229,242,255));c.drawRoundRect(main,15f*u,15f*u,stroke);
        c.save();c.scale(pulse,pulse,x,y);
        label(c,toolMenuOpen?"×":"☰",x,y-2f*u,25f*u,Color.WHITE);
        c.restore();

        if(!toolMenuOpen)return;
        float panelTop=96f*u;
        float gap=72f*u;
        float first=132f*u;
        float panelBottom=Math.min(getHeight()*.72f,first+gap*5f+35f*u);
        RectF panel=new RectF(3f*u,panelTop,91f*u,panelBottom);
        paint.setColor(Color.argb(198,16,24,74));c.drawRoundRect(panel,18f*u,18f*u,paint);
        stroke.setStrokeWidth(1.6f*u);stroke.setColor(Color.argb(175,255,255,255));c.drawRoundRect(panel,18f*u,18f*u,stroke);
        String[] glyphs={"Ⅱ","↻","⚙",soundOn?"S":"×","?","‹"};
        int[] tops={Color.rgb(58,174,255),Color.rgb(106,229,66),Color.rgb(66,181,255),Color.rgb(89,218,223),Color.rgb(255,174,64),Color.rgb(75,158,242)};
        int[] bottoms={Color.rgb(34,77,199),Color.rgb(39,159,53),Color.rgb(46,86,207),Color.rgb(29,135,160),Color.rgb(226,96,41),Color.rgb(45,81,174)};
        for(int i=0;i<glyphs.length;i++)toolButton(c,panel.centerX(),first+i*gap,glyphs[i],tops[i],bottoms[i]);
    }

    private void toolButton(Canvas c,float x,float y,String glyph,int top,int bottom) {
        float u=uiScale();float half=28f*u;RectF r=new RectF(x-half,y-half,x+half,y+half);
        paint.setColor(Color.argb(92,5,10,42));c.drawRoundRect(new RectF(r.left,r.top+4f*u,r.right,r.bottom+4f*u),13f*u,13f*u,paint);
        roundedGradient(c,r,13f*u,lighten(top,.08f),darken(bottom,.05f));
        stroke.setStrokeWidth(2.0f*u);stroke.setColor(Color.rgb(229,241,255));c.drawRoundRect(r,13f*u,13f*u,stroke);
        label(c,glyph,x,y,24f*u,Color.WHITE);
    }

    private void drawPowerups(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale(),y=h*.895f;float bw=w*.285f,bh=Math.max(84f*u,h*.078f);
        powerCard(c,new RectF(w*.035f,y-bh/2,w*.035f+bw,y+bh/2),"BOMB",bombCount,power==Power.BOMB,Color.rgb(239,80,71));
        powerCard(c,new RectF(w*.3575f,y-bh/2,w*.3575f+bw,y+bh/2),"WILD",rainbowCount,power==Power.RAINBOW,Color.rgb(156,74,245));
        powerCard(c,new RectF(w*.68f,y-bh/2,w*.68f+bw,y+bh/2),"SWAP",-1,false,Color.rgb(39,151,235));
    }

    private void powerCard(Canvas c,RectF r,String title,int count,boolean selected,int col) {
        float u=uiScale();float pulse=selected?(1f+.035f*(float)Math.sin(ambientTime*7f)):1f;
        float bob=(float)Math.sin(ambientTime*3.0f+(title.hashCode()&7))*(selected?1.5f*u:.35f*u);
        RectF rr=new RectF(r.centerX()-r.width()*pulse/2f,r.centerY()-r.height()*pulse/2f+bob,r.centerX()+r.width()*pulse/2f,r.centerY()+r.height()*pulse/2f+bob);
        int top=title.equals("BOMB")?Color.rgb(126,87,224):(title.equals("WILD")?Color.rgb(169,80,236):Color.rgb(72,171,255));
        int bottom=title.equals("BOMB")?Color.rgb(55,55,154):(title.equals("WILD")?Color.rgb(78,48,168):Color.rgb(37,89,190));
        if(selected){top=lighten(top,.18f);bottom=lighten(bottom,.08f);}
        paint.setColor(Color.argb(110,5,8,42));c.drawRoundRect(new RectF(rr.left,rr.top+6f*u,rr.right,rr.bottom+6f*u),18f*u,18f*u,paint);
        roundedGradient(c,rr,18f*u,top,bottom);
        stroke.setStrokeWidth(selected?4.2f*u:3.1f*u);stroke.setColor(selected?Color.rgb(255,233,105):Color.rgb(225,239,255));c.drawRoundRect(rr,18f*u,18f*u,stroke);
        float ix=rr.left+38f*u;
        if(title.equals("BOMB"))drawBombBubble(c,ix,rr.centerY()-4f*u,22f*u);
        else if(title.equals("WILD"))drawRainbowBubble(c,ix,rr.centerY()-4f*u,22f*u);
        else iconCircle(c,ix,rr.centerY()-4f*u,20f*u,"↔",Color.rgb(81,209,255),Color.rgb(33,91,199));
        label(c,title,rr.centerX()+18f*u,rr.centerY()+6f*u,17.5f*u,Color.WHITE);
        if(count>=0){
            paint.setColor(Color.rgb(213,67,185));c.drawCircle(rr.right-16f*u,rr.top+14f*u,15f*u,paint);
            stroke.setStrokeWidth(1.2f*u);stroke.setColor(Color.rgb(130,38,132));c.drawCircle(rr.right-16f*u,rr.top+14f*u,15f*u,stroke);
            label(c,String.valueOf(count),rr.right-16f*u,rr.top+14f*u,13.5f*u,Color.WHITE);
            if(count==0){int cost=title.equals("BOMB")?BOMB_COST:WILD_COST;label(c,"BUY "+cost,rr.centerX()+18f*u,rr.bottom-12f*u,10.5f*u,Color.rgb(255,238,129));}
        }
    }

    private void drawFeverMeter(Canvas c) {
        float w=getWidth(),u=uiScale();
        float charge=Math.min(1f,combo/5f);
        RectF bg=new RectF(w*.31f,101f*u,w*.68f,118f*u);
        paint.setColor(Color.argb(145,22,28,82));c.drawRoundRect(bg,10f*u,10f*u,paint);
        float shown=feverTimer>0f?Math.min(1f,feverTimer/5.5f):charge;
        if(shown>0f){RectF fg=new RectF(bg.left,bg.top,bg.left+bg.width()*shown,bg.bottom);roundedGradient(c,fg,10f*u,Color.rgb(255,230,65),Color.rgb(255,72,128));}
        label(c,feverTimer>0f?"REALM FEVER x2":"FEVER "+combo+"/5",bg.centerX(),bg.centerY(),9.5f*u,Color.WHITE);
    }

    private void drawDynamicFieldFx(Canvas c){
        if(windForce==0f && gravityForce==0f && formationMode==0)return;
        float w=getWidth(),h=getHeight(),u=uiScale();
        if(windForce!=0f){
            boolean right=windForce>0f;
            for(int i=0;i<5;i++){
                float yy=h*(.22f+i*.105f)+(float)Math.sin(ambientTime*1.1f+i)*8f*u;
                float start=right?w*.08f:w*.92f,end=right?w*.31f:w*.69f;
                stroke.setStrokeWidth((1.4f+i*.22f)*u);stroke.setColor(Color.argb(55+i*9,158,238,255));
                c.drawLine(start,yy,end,yy,stroke);
                float tip=right?1f:-1f;
                c.drawLine(end,yy,end-tip*10f*u,yy-6f*u,stroke);c.drawLine(end,yy,end-tip*10f*u,yy+6f*u,stroke);
            }
            label(c,right?"WIND →":"← WIND",w*.5f,112f*u,9.8f*u,Color.argb(210,188,240,255));
        }
        if(gravityForce!=0f){
            for(int i=0;i<4;i++){
                float xx=w*(.18f+i*.21f)+(float)Math.sin(ambientTime*.7f+i)*5f*u;
                float yy=h*.30f+((ambientTime*.05f+i*.23f)%1f)*h*.30f;
                stroke.setStrokeWidth(1.5f*u);stroke.setColor(Color.argb(65,214,183,255));
                c.drawLine(xx,yy,xx,yy+18f*u,stroke);c.drawLine(xx,yy+18f*u,xx-5f*u,yy+11f*u,stroke);c.drawLine(xx,yy+18f*u,xx+5f*u,yy+11f*u,stroke);
            }
            label(c,"GRAVITY FIELD",w*.5f,126f*u,9.2f*u,Color.argb(205,225,203,255));
        }
        if(formationMode>0){
            String f=formationMode==1?"SWAY FORMATION":formationMode==2?"ROTATING FORMATION":"PULSE FORMATION";
            float rowTop=cellCenter(0,0).y-bubbleR;
            float fy=Math.max(124f*u,rowTop-12f*u);
            label(c,f,w*.5f,fy,8.8f*u,Color.rgb(255,239,172));
        }
    }

    private void updateRealmCompanionAndFusion(int impact){
        if(impact<=0)return;
        if(selectedLevel>=5 && gameMode==GameMode.ADVENTURE){
            companionMeter+=impact>=10?2:1;
            if(companionMeter>=6){
                companionMeter-=6;
                int before=superCharge;
                superCharge=Math.min(100,superCharge+14);
                companionPulse=1f;
                if(superCharge>before){
                    floatingTexts.add(new FloatingText("REALM SPRITE • +14 POWER",getWidth()*.78f,getHeight()*.70f,Color.rgb(180,244,255),20f));
                    audio.play(AudioEngine.FX_MAGIC,.55f,1.22f);
                }
            }
        }
        // Using a paid/earned booster on a strong shot creates a Fusion charge rather than free coins.
        if(shotPower!=Power.NORMAL && impact>=6){
            fusionStreak++;
            int before=superCharge;
            superCharge=Math.min(100,superCharge+18);
            if(superCharge>before){
                floatingTexts.add(new FloatingText("POWER FUSION! +18%",getWidth()*.5f,getHeight()*.48f,Color.rgb(255,210,104),24f));
                addRing(getWidth()*.5f,getHeight()*.48f,Color.rgb(255,211,94),bubbleR*.45f,bubbleR*3.4f,.44f);
            }
        }
    }

    private void drawRealmCompanion(Canvas c){
        if(selectedLevel<5 || screen!=Screen.GAME)return;
        float u=uiScale(),w=getWidth(),h=getHeight();
        float pulse=1f+.10f*(float)Math.sin(ambientTime*4.2f)+companionPulse*.12f;
        float x=w*.885f+(float)Math.sin(ambientTime*.9f)*7f*u;
        float y=h*.735f+(float)Math.cos(ambientTime*1.1f)*9f*u;
        float r=18f*u*pulse;
        paint.setShader(new RadialGradient(x-r*.25f,y-r*.30f,r*1.5f,Color.WHITE,Color.rgb(91,112,246),Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,paint);paint.setShader(null);
        drawStar(c,x,y,r*.48f,Color.rgb(255,222,77));
        stroke.setStrokeWidth(1.4f*u);stroke.setColor(Color.argb(150,210,238,255));
        c.drawCircle(x,y,r*1.34f,stroke);
        label(c,"SPRITE "+companionMeter+"/6",x,y+r*1.85f,8.3f*u,Color.argb(220,235,244,255));
    }

    private void drawSuperPower(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF bg=new RectF(w*.255f,h*.815f,w*.745f,h*.848f);
        int ready=superCharge>=100?1:0;
        paint.setColor(Color.argb(150,18,22,74));c.drawRoundRect(bg,15f*u,15f*u,paint);
        if(superCharge>0){
            RectF fg=new RectF(bg.left,bg.top,bg.left+bg.width()*Math.min(1f,superCharge/100f),bg.bottom);
            roundedGradient(c,fg,15f*u,ready==1?Color.rgb(255,222,63):Color.rgb(75,219,255),ready==1?Color.rgb(255,73,158):Color.rgb(125,72,232));
        }
        float pulse=ready==1?.5f+.5f*(float)Math.sin(ambientTime*7f):0f;
        stroke.setStrokeWidth((2f+ready*pulse*2f)*u);stroke.setColor(ready==1?Color.rgb(255,245,153):Color.argb(170,225,239,255));c.drawRoundRect(bg,15f*u,15f*u,stroke);
        label(c,ready==1?"REALM BLAST • TAP!":"REALM POWER "+superCharge+"%",bg.centerX(),bg.centerY(),11.8f*u,Color.WHITE);
    }

    private boolean inSuperPower(float x,float y){
        float w=getWidth(),h=getHeight();
        return in(x,y,w*.24f,h*.805f,w*.76f,h*.858f);
    }

    private void chargeSuper(int affected,int detached){
        if(affected<=0)return;
        int gain=affected*4+detached*3+Math.max(0,combo-1)*4+(activeBranchRoute==1?5:0);
        if(worldIndex(selectedLevel)==1 && combo>=2)gain+=4; // Candy Clouds: combos charge Realm Power faster.
        int before=superCharge;
        superCharge=Math.min(100,superCharge+gain);
        if(before<100&&superCharge>=100&&!superReadyAnnounced){
            superReadyAnnounced=true;
            floatingTexts.add(new FloatingText("REALM BLAST READY!",getWidth()*.5f,getHeight()*.52f,Color.rgb(255,232,85),28f));
            audio.play(AudioEngine.FX_POWER,1f,1.18f);addRing(shooterX,shooterY,Color.rgb(255,224,74),bubbleR*.7f,bubbleR*5.2f,.62f);haptic(48);
        }
    }

    private void activateSuperPower(){
        if(superCharge<100||shotFlying||overlay!=Overlay.NONE||rowDropTimer>0f)return;
        superCharge=0;superReadyAnnounced=false;power=Power.NORMAL;
        ArrayList<Integer> keys=new ArrayList<>(grid.keySet());
        Collections.sort(keys,(a,b)->{
            Integer va=grid.get(a),vb=grid.get(b);
            boolean sa=va!=null&&va>=100,sb=vb!=null&&vb>=100;
            if(sa!=sb)return sa?-1:1;
            return Integer.compare(rowOf(b),rowOf(a));
        });
        int cap=Math.min(keys.size(),10+Math.min(7,selectedLevel/70));
        int removed=0;
        for(int i=0;i<cap;i++){int k=keys.get(i);if(grid.containsKey(k))removed+=processBubbleRemoval(k,true);}
        int detached=dropDetached();
        clearedBubbles=Math.min(initialBubbleCount,clearedBubbles+removed+detached);
        int pts=(removed*55+detached*70+500);levelScore+=pts;
        if(objective==Objective.BOSS&&bossShield>0){bossShield=Math.max(0,bossShield-2);if(bossShield==0)onBossShieldBroken();}
        screenShake=18f;feverBurst=1f;popFlash=1f;combo=Math.max(combo,3);
        addRing(getWidth()*.5f,getHeight()*.45f,Color.rgb(255,231,80),bubbleR*1.2f,bubbleR*8.0f,.8f);
        addRing(getWidth()*.5f,getHeight()*.45f,Color.rgb(104,222,255),bubbleR*.6f,bubbleR*6.5f,.7f);
        floatingTexts.add(new FloatingText("REALM BLAST! +"+pts,getWidth()*.5f,getHeight()*.43f,Color.rgb(255,239,105),31f));
        audio.play(AudioEngine.FX_FEVER,1f,1.08f);haptic(90);checkEndState();saveGameState();
    }

    private void bossAfterShot(int impact){
        if(bossMaxShield<=0)return;
        if(bossShield>0 && (impact>=4 || combo>=2)){
            int damage=1+(combo>=4?1:0)+(impact>=12?1:0);
            int before=bossShield;
            bossShield=Math.max(0,bossShield-damage);
            if(bossShield<before){
                floatingTexts.add(new FloatingText("BOSS SHIELD -"+(before-bossShield),getWidth()*.5f,getHeight()*.30f,Color.rgb(255,191,110),23f));
                audio.play(AudioEngine.FX_POWER,.78f,1.04f);haptic(30);
            }
            if(bossShield==0){onBossShieldBroken();return;}
        }
        bossShotsUntilAttack--;
        if(bossShotsUntilAttack<=0){
            bossAttack();
            bossShotsUntilAttack=bossPhase>=2?3:4;
        }
        if(bossShield>0 && bossShield<=Math.max(1,bossMaxShield/2) && bossPhase==1){
            bossPhase=2;
            pressureLimit=Math.max(2,pressureLimit-1);
            floatingTexts.add(new FloatingText("BOSS PHASE 2 • FASTER ATTACKS",getWidth()*.5f,getHeight()*.34f,Color.rgb(255,137,133),24f));
        }
    }

    private void bossAttack(){
        if(grid.isEmpty())return;
        ArrayList<Integer> keys=new ArrayList<>(grid.keySet());Collections.shuffle(keys,random);
        int changed=0;
        int active=Math.min(PALETTE.length,4+selectedLevel/80);
        for(int k:keys){
            Integer v=grid.get(k);if(v==null)continue;
            if(v<100){
                int base=(baseColorOf(v)+1+random.nextInt(Math.max(1,active-1)))%Math.max(3,active);
                int newValue=base;
                if(changed==0 && selectedLevel>=50)newValue=makeSpecialBubble(SPECIAL_CHAIN,base);
                else if(changed==1 && selectedLevel>=75)newValue=makeSpecialBubble(SPECIAL_CLOUD,base);
                grid.put(k,newValue);changed++;
            }
            if(changed>=Math.min(8,4+bossPhase*2))break;
        }
        // Spawn attack: fill a few safe top-row holes instead of an unavoidable full row.
        int spawned=0;
        for(int c=0;c<GRID_COLS&&spawned<2+bossPhase;c++){
            int col=(c*3+bossPhase+selectedLevel)%GRID_COLS;
            int k=key(0,col);
            if(!grid.containsKey(k)){grid.put(k,random.nextInt(Math.max(3,active)));spawned++;}
        }
        screenShake=Math.max(screenShake,11f);feverBurst=Math.max(feverBurst,.28f);
        floatingTexts.add(new FloatingText(bossPhase>=2?"BOSS COLOR SHIFT + SPAWN!":"BOSS COLOR SHIFT!",getWidth()*.5f,gridTop+78f,Color.rgb(255,121,130),24f));
        audio.play(AudioEngine.FX_BOUNCE,.75f,.78f);addRing(getWidth()*.5f,gridTop+rowH*2f,Color.rgb(255,91,128),bubbleR*.6f,bubbleR*5f,.52f);haptic(40);
    }

    private void onBossShieldBroken(){
        bossPhase=3;
        shotsLeft+=2; // fairness reward: the final vulnerable phase is always finishable with skill.
        floatingTexts.add(new FloatingText("SHIELD BROKEN! • +2 SHOTS",getWidth()*.5f,getHeight()*.31f,Color.rgb(255,231,91),27f));
        addRing(getWidth()*.5f,gridTop+rowH*2.5f,Color.rgb(255,224,70),bubbleR*.7f,bubbleR*7.2f,.72f);
        screenShake=18f;feverBurst=1f;audio.play(AudioEngine.FX_FEVER,1f,.92f);haptic(75);
    }

    private void drawBossMeter(Canvas c){
        if(objective!=Objective.BOSS||gameMode!=GameMode.ADVENTURE)return;
        float w=getWidth(),u=uiScale();
        boolean shieldUp=bossShield>0;
        float hp=shieldUp?bossShield/(float)Math.max(1,bossMaxShield):Math.max(0f,1f-clearedBubbles/(float)Math.max(1,clearTarget));
        RectF bg=new RectF(w*.24f,124f*u,w*.86f,148f*u);
        paint.setColor(Color.argb(175,48,16,50));c.drawRoundRect(bg,12f*u,12f*u,paint);
        if(hp>0f){RectF fg=new RectF(bg.left,bg.top,bg.left+bg.width()*hp,bg.bottom);roundedGradient(c,fg,12f*u,shieldUp?Color.rgb(115,181,255):Color.rgb(255,100,116),shieldUp?Color.rgb(91,73,210):Color.rgb(176,38,87));}
        stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.argb(180,255,255,255));c.drawRoundRect(bg,12f*u,12f*u,stroke);
        String txt=shieldUp?("BOSS SHIELD  "+bossShield+"/"+Math.max(1,bossMaxShield)):("BOSS CORE  "+Math.round(hp*100)+"%");
        label(c,txt,bg.centerX(),bg.centerY(),10.5f*u,Color.WHITE);
        float bx=bg.left+bg.width()*(.5f+.42f*(float)Math.sin(ambientTime*.85f));float by=bg.top-18f*u;
        paint.setShader(new RadialGradient(bx-5f*u,by-6f*u,22f*u,Color.WHITE,shieldUp?Color.rgb(93,84,224):Color.rgb(205,48,92),Shader.TileMode.CLAMP));c.drawCircle(bx,by,16f*u,paint);paint.setShader(null);
        paint.setColor(Color.WHITE);c.drawCircle(bx-5f*u,by-3f*u,2.5f*u,paint);c.drawCircle(bx+5f*u,by-3f*u,2.5f*u,paint);stroke.setStrokeWidth(2f*u);stroke.setColor(Color.rgb(78,20,52));c.drawArc(new RectF(bx-7f*u,by+1f*u,bx+7f*u,by+10f*u),200f,140f,false,stroke);
    }

    private void drawRingFx(Canvas c) {
        float u=uiScale();
        for(RingFx r:rings){float a=Math.max(0f,Math.min(1f,r.life/r.maxLife));stroke.setStrokeWidth(Math.max(1.4f,3.0f*u*a));stroke.setColor((r.color&0x00FFFFFF)|((int)(180*a)<<24));c.drawCircle(r.x,r.y,r.radius,stroke);}
    }

    private void announceShotPraise(int removed,int detached){
        int impact = removed + detached;
        // Voice praise is intentionally rare: only a genuinely large 6+ bubble shot can trigger it.
        if(impact < 6)return;
        long now=System.currentTimeMillis();
        if(now-lastPraiseAtMs < 3000L)return;

        String msg;
        String spoken;
        int col;
        boolean canAmazing=(now-lastAmazingAtMs)>11000L;
        if((impact>=13 || detached>=9) && canAmazing){
            msg="AMAZING!";spoken="Amazing";col=Color.rgb(255,218,92);lastAmazingAtMs=now;
        }else if(shotBankBounces>0 && impact>=7){
            msg="BANK SHOT!";spoken="Nice bank shot";col=Color.rgb(125,235,255);
        }else if(impact>=10){
            boolean wow=!"WOW!".equals(lastPraiseText) && random.nextBoolean();
            msg=wow?"WOW!":"GREAT SHOT!";spoken=wow?"Wow":"Great shot";col=Color.rgb(163,255,211);
        }else if(impact>=8){
            boolean well=combo>=3 && !"WELL DONE!".equals(lastPraiseText);
            msg=well?"WELL DONE!":"GOOD SHOT!";spoken=well?"Well done":"Good shot";col=Color.rgb(220,241,255);
        }else{
            msg="NICE!";spoken="Nice";col=Color.rgb(218,242,255);
        }
        lastPraiseAtMs=now;lastPraiseText=msg;
        praiseBannerText=msg;praiseBannerColor=col;praiseBannerTimer=1.22f;
        addRing(getWidth()*.5f,getHeight()*.36f,col,bubbleR*.8f,bubbleR*6.4f,.68f);
        audio.playPraiseDelayed(spoken,330L);
        if(shotBankBounces>0 && impact>=7){
            levelScore+=100;
            floatingTexts.add(new FloatingText("PRECISION +100",getWidth()*.5f,getHeight()*.44f,Color.rgb(150,235,255),24f));
        }
    }

    private void drawPraiseBanner(Canvas c){
        if(praiseBannerText==null || praiseBannerTimer<=0f)return;
        float u=uiScale(),w=getWidth(),h=getHeight();
        float life=Math.max(0f,Math.min(1f,praiseBannerTimer/1.18f));
        float age=1f-life;
        float scale;
        if(age<.18f)scale=.62f+(age/.18f)*.58f;
        else if(age<.34f)scale=1.20f-((age-.18f)/.16f)*.18f;
        else scale=1.02f+.035f*(float)Math.sin(ambientTime*12f);
        int alpha=(int)(255f*Math.min(1f,life/.22f));
        float cy=h*.355f;

        paint.setShader(new RadialGradient(w*.5f,cy,w*.32f,
                (praiseBannerColor&0x00FFFFFF)|(Math.min(125,alpha/2)<<24),
                Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(w*.5f,cy,w*.32f,paint);paint.setShader(null);

        for(int i=0;i<8;i++){
            float a=ambientTime*2.2f+i*.785f;
            float sx=w*.5f+(float)Math.cos(a)*w*.20f;
            float sy=cy+(float)Math.sin(a)*42f*u;
            paint.setColor(Color.argb(Math.min(220,alpha),255,255,255));
            c.drawCircle(sx,sy,(2.5f+(i%3))*u,paint);
        }

        c.save();
        c.scale(scale,scale,w*.5f,cy);
        text.setShader(null);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(android.graphics.Typeface.create("sans-serif-black",android.graphics.Typeface.BOLD));
        text.setTextSize(48f*u);
        text.setShadowLayer(8f*u,0,5f*u,Color.argb(Math.min(210,alpha),20,18,70));
        text.setColor((praiseBannerColor&0x00FFFFFF)|(alpha<<24));
        Paint.FontMetrics fm=text.getFontMetrics();
        c.drawText(praiseBannerText,w*.5f,cy-(fm.ascent+fm.descent)/2f,text);
        text.clearShadowLayer();
        c.restore();
    }

    private void addRing(float x,float y,int color,float start,float speed,float life){
        if(rings.size()>40)rings.remove(0);
        rings.add(new RingFx(x,y,color,start,speed,life));
    }

    private void triggerFever() {
        feverTimer=5.5f;feverBurst=1f;
        audio.play(AudioEngine.FX_FEVER,1f,1f);
        haptic(70);
        floatingTexts.add(new FloatingText("REALM FEVER • DOUBLE SCORE!",getWidth()*.5f,getHeight()*.38f,Color.rgb(255,235,78),28f));
        addRing(shooterX,shooterY,Color.rgb(255,226,61),bubbleR*.8f,bubbleR*5.5f,0.65f);
        addRing(shooterX,shooterY,Color.rgb(255,80,175),bubbleR*1.3f,bubbleR*4.2f,0.72f);
        for(int i=0;i<28;i++){float a=random.nextFloat()*6.283f;float sp=140f+random.nextFloat()*420f;int col=PALETTE[random.nextInt(PALETTE.length)];particles.add(new Particle(shooterX,shooterY,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp,col,4f+random.nextFloat()*7f,.65f+random.nextFloat()*.55f));}
    }

    private PointF movingBarrierCenter(int index){
        float w=getWidth(),h=getHeight(),u=uiScale();
        float laneTop=Math.max(gridTop+rowH*3.1f,132f*u),laneBottom=Math.min(dangerY-rowH*1.3f,h*.68f);
        float mid=(laneTop+laneBottom)*.5f,ampX=w*.28f,ampY=Math.max(rowH*1.3f,(laneBottom-laneTop)*.28f);
        float phase=ambientTime*(1.15f+index*.13f)+index*2.2f;
        if(movingBarrierMode==1)return new PointF(w*.5f+(float)Math.sin(phase)*ampX,mid);
        if(movingBarrierMode==2)return new PointF(w*.5f+(float)Math.sin(phase)*ampX,mid+(float)Math.sin(phase*2f)*ampY);
        float side=index==0?.36f:.64f;
        return new PointF(w*side+(float)Math.sin(phase)*w*.13f,mid+(float)Math.cos(phase*.82f)*ampY);
    }

    private int movingBarrierCount(){return movingBarrierMode==3?2:(movingBarrierMode>0?1:0);}

    private void drawMovingBarriers(Canvas c){
        if(movingBarrierMode<=0||gameMode==GameMode.TREASURE_ROOM)return;
        float u=uiScale(),r=Math.max(16f*u,bubbleR*.62f);
        for(int i=0;i<movingBarrierCount();i++){
            PointF b=movingBarrierCenter(i);float pulse=.55f+.45f*(float)Math.sin(ambientTime*5f+i);
            paint.setShader(new RadialGradient(b.x,b.y,r*1.8f,Color.argb((int)(75+55*pulse),103,225,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(b.x,b.y,r*1.8f,paint);paint.setShader(null);
            paint.setColor(Color.rgb(45,58,111));c.drawCircle(b.x,b.y,r,paint);
            stroke.setStrokeWidth(4f*u);stroke.setColor(Color.rgb(125,231,255));c.drawCircle(b.x,b.y,r,stroke);
            stroke.setStrokeWidth(2f*u);stroke.setColor(Color.rgb(255,197,92));c.drawArc(new RectF(b.x-r*.72f,b.y-r*.72f,b.x+r*.72f,b.y+r*.72f),(ambientTime*110f+i*80f)%360f,120f,false,stroke);
            label(c,"↔",b.x,b.y,14f*u,Color.WHITE);
        }
    }

    private boolean bounceOffMovingBarrier(){
        if(movingBarrierMode<=0||barrierCooldown>0f||gameMode==GameMode.TREASURE_ROOM)return false;
        float r=Math.max(16f*uiScale(),bubbleR*.62f),hit=bubbleR*.90f+r;
        for(int i=0;i<movingBarrierCount();i++){
            PointF b=movingBarrierCenter(i);float dx=shotX-b.x,dy=shotY-b.y;float d2=dx*dx+dy*dy;
            if(d2<hit*hit){
                float d=(float)Math.sqrt(Math.max(1f,d2)),nx=dx/d,ny=dy/d;
                float dot=shotVx*nx+shotVy*ny;
                shotVx-=2f*dot*nx;shotVy-=2f*dot*ny;
                shotX=b.x+nx*(hit+2f);shotY=b.y+ny*(hit+2f);
                barrierCooldown=.14f;shotBankBounces++;screenShake=Math.max(screenShake,4f);
                addRing(b.x,b.y,Color.rgb(110,232,255),r*.35f,r*4.2f,.28f);audio.play(AudioEngine.FX_BOUNCE,.65f,1.18f);haptic(12);
                return true;
            }
        }
        return false;
    }

    private void updateShot(float dt) {
        // Dynamic fields bend the trajectory, but caps keep the shot controllable.
        shotFlightTime += dt;
        shotVx += windForce*dt;
        shotVy += gravityForce*dt;
        float maxV=Math.max(1050f,getHeight()*1.35f);
        shotVx=Math.max(-maxV,Math.min(maxV,shotVx));
        shotVy=Math.max(-maxV,Math.min(maxV,shotVy));
        shotX += shotVx * dt;
        shotY += shotVy * dt;
        if (shotX < bubbleR) {
            shotX = bubbleR + (bubbleR-shotX);
            shotVx = Math.abs(shotVx);
            shotBankBounces++;
            bounceFx();
        } else if (shotX > getWidth()-bubbleR) {
            shotX = getWidth()-bubbleR-(shotX-(getWidth()-bubbleR));
            shotVx = -Math.abs(shotVx);
            shotBankBounces++;
            bounceFx();
        }
        bounceOffMovingBarrier();
        if(tryPortalTeleport())return;
        if (shotY <= gridTop - bubbleR*.15f || wouldCollide(shotX,shotY)) {
            settleShot();
            return;
        }
        // v4.1.1 projectile recovery: a moving energy bumper, portal, wind or gravity
        // can redirect the shot back below the launcher. Previously shotFlying could
        // then remain true forever, so no new bubble could be fired. Treat that as a
        // normal miss and immediately unlock the next bubble. The timer is a second
        // fail-safe for any unusual trajectory that never reaches the board.
        if (shotY > shooterY + bubbleR*1.35f || shotFlightTime > 7.5f) {
            recoverEscapedShot();
        }
    }

    private void recoverEscapedShot(){
        if(!shotFlying)return;
        shotFlying=false;
        aiming=false;
        shotFlightTime=0f;
        combo=0;
        misses++;
        floatingTexts.add(new FloatingText("SHOT RETURNED • NEXT READY",shooterX,shooterY-bubbleR*3.0f,Color.rgb(171,235,255),18f));
        audio.play(AudioEngine.FX_BOUNCE,.55f,.88f);
        haptic(16);

        if(objective==Objective.BOSS&&gameMode==GameMode.ADVENTURE)bossAfterShot(0);
        // Use the same hard-mode miss tolerance as a normal landed shot.
        int missLimit=selectedLevel<=3?2:selectedLevel<=60?2:1;
        if(isBossLevel(selectedLevel))missLimit=1;
        if(misses>=missLimit){misses=0;shotsSinceDrop=0;addCeilingRow();return;}
        if(shotsSinceDrop>=pressureLimit&&clearedBubbles<clearTarget){shotsSinceDrop=0;addCeilingRow();return;}
        saveGameState();
        checkEndState();
    }

    private boolean tryPortalTeleport(){
        if(portalCooldown>0f)return false;
        ArrayList<Integer> portals=new ArrayList<>();
        for(Map.Entry<Integer,Integer> e:grid.entrySet())if(e.getValue()!=null&&isPortalBubbleValue(e.getValue()))portals.add(e.getKey());
        if(portals.size()<2)return false;
        int entered=-1;
        for(int k:portals){
            PointF p=cellCenter(rowOf(k),colOf(k));
            if(dist(shotX,shotY,p.x,p.y)<bubbleR*1.05f){entered=k;break;}
        }
        if(entered<0)return false;
        int exit=portals.get(0)==entered?portals.get(1):portals.get(0);
        PointF a=cellCenter(rowOf(entered),colOf(entered)),b=cellCenter(rowOf(exit),colOf(exit));
        float speed=(float)Math.sqrt(shotVx*shotVx+shotVy*shotVy);
        if(speed<1f)speed=900f;
        float ux=shotVx/speed,uy=shotVy/speed;
        shotX=b.x+ux*bubbleR*1.75f;shotY=b.y+uy*bubbleR*1.75f;
        portalCooldown=.30f;
        addRing(a.x,a.y,Color.rgb(184,104,255),bubbleR*.35f,bubbleR*3.4f,.38f);
        addRing(b.x,b.y,Color.rgb(79,225,255),bubbleR*.35f,bubbleR*3.4f,.38f);
        floatingTexts.add(new FloatingText("PORTAL!",b.x,b.y-24f,Color.rgb(188,237,255),20f));
        audio.play(AudioEngine.FX_MAGIC,.72f,1.20f);haptic(18);
        return true;
    }

    private boolean wouldCollide(float x,float y){
        float min=bubbleR*1.78f;
        float min2=min*min;
        for(Integer k:grid.keySet()){
            PointF p=cellCenter(rowOf(k),colOf(k));
            float dx=x-p.x,dy=y-p.y;
            if(dx*dx+dy*dy<min2)return true;
        }
        return false;
    }

    private void loadCannonExplosionFrames() {
        try {
            int[] ids = {
                    R.drawable.collision_fire_01,R.drawable.collision_fire_02,R.drawable.collision_fire_03,
                    R.drawable.collision_fire_04,R.drawable.collision_fire_05,R.drawable.collision_fire_06,
                    R.drawable.collision_fire_07,R.drawable.collision_fire_08,R.drawable.collision_fire_09,
                    R.drawable.collision_fire_10,R.drawable.collision_fire_11,R.drawable.collision_fire_12,
                    R.drawable.collision_fire_13,R.drawable.collision_fire_14,R.drawable.collision_fire_15,
                    R.drawable.collision_fire_16,R.drawable.collision_fire_17,R.drawable.collision_fire_18,
                    R.drawable.collision_fire_19,R.drawable.collision_fire_20,R.drawable.collision_fire_21,
                    R.drawable.collision_fire_22,R.drawable.collision_fire_23,R.drawable.collision_fire_24
            };
            for (int i = 0; i < ids.length; i++) cannonExplosionFrames[i] = BitmapFactory.decodeResource(getResources(), ids[i]);
        } catch (Throwable ignored) {
            for (int i = 0; i < cannonExplosionFrames.length; i++) cannonExplosionFrames[i] = null;
        }
    }

    private void shoot() {
        if (shotFlying || !falling.isEmpty() || overlay != Overlay.NONE || shotsLeft<=0 || rowDropTimer>0f || levelIntroTimer>0f) return;
        // Fire the dedicated C5 cue before changing projectile state so the audio
        // starts on the same input frame as the cannon launch.
        audio.play(AudioEngine.FX_CANNON_C5,1.0f,1.0f);
        shotFlying=true;
        shotFlightTime=0f;
        cannonFireTimer=.48f;cannonRecoil=1.55f;
        float launchDx=(float)Math.cos(aimAngle),launchDy=(float)Math.sin(aimAngle);
        shotX=shooterX+launchDx*bubbleR*.72f;shotY=shooterY+launchDy*bubbleR*.72f;
        shotColor=currentColor;
        shotPower=power;
        shotBankBounces=0;
        float speed=Math.max(920f,getHeight()*1.12f);
        shotVx=(float)Math.cos(aimAngle)*speed;
        shotVy=(float)Math.sin(aimAngle)*speed;
        shotsLeft--;
        haptic(18);
        if(power==Power.BOMB){bombCount--;prefs.edit().putInt("bomb_inventory",bombCount).apply();power=Power.NORMAL;}
        else if(power==Power.RAINBOW){rainbowCount--;prefs.edit().putInt("wild_inventory",rainbowCount).apply();power=Power.NORMAL;}
        shotsSinceDrop++;
        currentColor=nextColor;
        nextColor=pickExistingColor();
    }

    private int processBubbleRemoval(int k, boolean bomb) {
        Integer cc=grid.get(k);
        if(cc==null)return 0;
        PointF q=cellCenter(rowOf(k),colOf(k));
        int base=baseColorOf(cc);
        if(isIceBubbleValue(cc) && !bomb){
            grid.put(k,base);
            if(objective==Objective.ICE_BREAK)objectiveProgress++;
            spawnPop(q,cc,6);addRing(q.x,q.y,Color.rgb(191,241,255),bubbleR*.30f,bubbleR*2.3f,.30f);
            audio.play(AudioEngine.FX_MAGIC,.52f,1.22f);
            return 0;
        }
        if(isArmorBubbleValue(cc) && !bomb){
            // First hit breaks the metal shell; a later colour match removes the bubble.
            grid.put(k,base);spawnPop(q,cc,7);addRing(q.x,q.y,Color.rgb(205,224,255),bubbleR*.32f,bubbleR*2.6f,.34f);
            floatingTexts.add(new FloatingText("ARMOR CRACK!",q.x,q.y-18f,Color.rgb(213,232,255),18f));
            audio.play(AudioEngine.FX_LAND,.72f,.78f);haptic(22);return 0;
        }
        if((isStoneBubbleValue(cc)||isChainBubbleValue(cc)||isCloudBubbleValue(cc)) && !bomb)return 0;

        int row=rowOf(k),col=colOf(k);
        boolean lightning=isLightningBubbleValue(cc);
        boolean magnet=isMagnetBubbleValue(cc);
        boolean paintBubble=isPaintBubbleValue(cc);
        boolean blackHole=isBlackHoleBubbleValue(cc);
        boolean portal=isPortalBubbleValue(cc);

        grid.remove(k);
        if(isChestBubbleValue(cc)){shotChestBonus+=3;if(objective==Objective.TREASURE)objectiveProgress++;}
        if(isStarBubbleValue(cc))shotStarBonus+=90;
        if(isKeyBubbleValue(cc)&&objective==Objective.KEYS)objectiveProgress++;
        if(isBabyBubbleValue(cc)&&objective==Objective.RESCUE)objectiveProgress++;
        if(isIceBubbleValue(cc)&&objective==Objective.ICE_BREAK)objectiveProgress++;
        if(isMysteryBubbleValue(cc)){
            int reward=random.nextInt(16);
            if(reward==0){shotChestBonus+=2;floatingTexts.add(new FloatingText("MYSTERY +2 COINS",q.x,q.y-18f,Color.rgb(255,225,82),20f));}
            else if(reward==1){shotsLeft+=1;floatingTexts.add(new FloatingText("MYSTERY +1 SHOT",q.x,q.y-18f,Color.rgb(126,233,255),20f));}
            else if(reward==2){bombCount++;prefs.edit().putInt("bomb_inventory",bombCount).apply();floatingTexts.add(new FloatingText("FREE BOMB!",q.x,q.y-18f,Color.rgb(255,135,92),20f));}
            else if(reward==3){rainbowCount++;prefs.edit().putInt("wild_inventory",rainbowCount).apply();floatingTexts.add(new FloatingText("FREE WILD!",q.x,q.y-18f,Color.rgb(211,123,255),20f));}
            else {shotMysteryScore+=220;floatingTexts.add(new FloatingText("MYSTERY +220 SCORE",q.x,q.y-18f,Color.WHITE,20f));}
            audio.play(AudioEngine.FX_BONUS,.92f,1.08f);
        }
        spawnPop(q,cc,bomb?12:8);

        int extra=0;
        if(lightning){
            extra=triggerLightningBubble(row,col,base);
            floatingTexts.add(new FloatingText("LIGHTNING!",q.x,q.y-24f,Color.rgb(255,244,104),21f));
        }else if(magnet){
            triggerMagnetBubble(row,col,base);
            floatingTexts.add(new FloatingText("MAGNET PULSE!",q.x,q.y-24f,Color.rgb(126,240,255),20f));
        }else if(paintBubble){
            triggerPaintBubble(row,col,base);
            floatingTexts.add(new FloatingText("COLOR PAINT!",q.x,q.y-24f,Color.rgb(255,171,245),20f));
        }else if(blackHole){
            extra=triggerBlackHoleBubble(row,col);
            floatingTexts.add(new FloatingText("BLACK HOLE!",q.x,q.y-24f,Color.rgb(223,175,255),21f));
        }else if(portal){
            shotMysteryScore+=80;
            addRing(q.x,q.y,Color.rgb(161,106,255),bubbleR*.3f,bubbleR*3.1f,.36f);
        }
        return 1+extra;
    }

    private int removeEffectTargetDirect(int k){
        Integer v=grid.remove(k);
        if(v==null)return 0;
        PointF p=cellCenter(rowOf(k),colOf(k));
        if(isChestBubbleValue(v)){shotChestBonus+=2;if(objective==Objective.TREASURE)objectiveProgress++;}
        if(isStarBubbleValue(v))shotStarBonus+=55;
        if(isKeyBubbleValue(v)&&objective==Objective.KEYS)objectiveProgress++;
        if(isBabyBubbleValue(v)&&objective==Objective.RESCUE)objectiveProgress++;
        if(isIceBubbleValue(v)&&objective==Objective.ICE_BREAK)objectiveProgress++;
        spawnPop(p,v,6);
        return 1;
    }

    private int triggerLightningBubble(int row,int col,int base){
        int removed=0;
        for(int d=1;d<=3;d++){
            int left=col-d,right=col+d;
            if(left>=0)removed+=removeEffectTargetDirect(key(row,left));
            if(right<GRID_COLS)removed+=removeEffectTargetDirect(key(row,right));
        }
        for(int rr=Math.max(0,row-1);rr<=Math.min(GRID_ROWS-1,row+1);rr++){
            if(rr==row)continue;
            removed+=removeEffectTargetDirect(key(rr,col));
        }
        PointF p=cellCenter(row,col);
        addRing(p.x,p.y,Color.rgb(255,236,84),bubbleR*.2f,bubbleR*5.8f,.44f);
        audio.play(AudioEngine.FX_POWER,.9f,1.28f);
        return removed;
    }

    private void triggerMagnetBubble(int row,int col,int base){
        HashSet<Integer> targets=new HashSet<>();
        for(int nk:neighborKeys(row,col))if(nk!=-999)targets.add(nk);
        for(int nk:new ArrayList<>(targets)){
            Integer v=grid.get(nk);
            if(v!=null && !isStoneBubbleValue(v)&&!isChainBubbleValue(v)&&!isCloudBubbleValue(v)&&!isPortalBubbleValue(v)){
                grid.put(nk,base);
                PointF p=cellCenter(rowOf(nk),colOf(nk));addRing(p.x,p.y,Color.rgb(102,236,255),bubbleR*.12f,bubbleR*1.5f,.24f);
            }
        }
        audio.play(AudioEngine.FX_MAGIC,.76f,.92f);
    }

    private void triggerPaintBubble(int row,int col,int base){
        HashSet<Integer> targets=new HashSet<>();
        for(int nk:neighborKeys(row,col))if(nk!=-999)targets.add(nk);
        for(int nk:new ArrayList<>(targets))for(int nn:neighborKeys(rowOf(nk),colOf(nk)))if(nn!=-999&&targets.size()<15)targets.add(nn);
        int changed=0;
        for(int nk:targets){
            Integer v=grid.get(nk);
            if(v!=null&&!isStoneBubbleValue(v)&&!isChainBubbleValue(v)&&!isCloudBubbleValue(v)&&!isPortalBubbleValue(v)){
                grid.put(nk,base);changed++;
                if(changed>=11)break;
            }
        }
        PointF p=cellCenter(row,col);addRing(p.x,p.y,PALETTE[base],bubbleR*.4f,bubbleR*5f,.46f);
        audio.play(AudioEngine.FX_MAGIC,.82f,1.10f);
    }

    private int triggerBlackHoleBubble(int row,int col){
        HashSet<Integer> targets=new HashSet<>();
        ArrayDeque<Integer> q=new ArrayDeque<>();
        for(int nk:neighborKeys(row,col))if(nk!=-999&&grid.containsKey(nk)){targets.add(nk);q.add(nk);}
        int seedCount=q.size();
        while(!q.isEmpty()&&targets.size()<12){
            int k=q.removeFirst();
            for(int nk:neighborKeys(rowOf(k),colOf(k))){
                if(nk!=-999&&grid.containsKey(nk)&&targets.add(nk)&&targets.size()<12 && seedCount>0)q.addLast(nk);
            }
        }
        int removed=0;
        for(int k:targets)removed+=removeEffectTargetDirect(k);
        PointF p=cellCenter(row,col);addRing(p.x,p.y,Color.rgb(69,31,112),bubbleR*.4f,bubbleR*7.2f,.58f);
        screenShake=Math.max(screenShake,14f);audio.play(AudioEngine.FX_FEVER,.88f,.72f);haptic(58);
        return removed;
    }

    private void reactToNearbyObstacles(Set<Integer> popped){
        HashSet<Integer> touched=new HashSet<>();
        for(int pk:popped){
            for(int nk:neighborKeys(rowOf(pk),colOf(pk))){
                if(nk==-999||!touched.add(nk))continue;
                Integer v=grid.get(nk);if(v==null)continue;
                PointF q=cellCenter(rowOf(nk),colOf(nk));
                if(isChainBubbleValue(v)){
                    grid.put(nk,baseColorOf(v));spawnPop(q,v,4);addRing(q.x,q.y,Color.rgb(255,223,133),bubbleR*.25f,bubbleR*1.9f,.26f);
                }else if(isCloudBubbleValue(v)){
                    grid.put(nk,baseColorOf(v));spawnPop(q,v,4);addRing(q.x,q.y,Color.rgb(225,241,255),bubbleR*.25f,bubbleR*2.0f,.28f);
                }else if(isIceBubbleValue(v)){
                    grid.put(nk,baseColorOf(v));if(objective==Objective.ICE_BREAK)objectiveProgress++;spawnPop(q,v,5);addRing(q.x,q.y,Color.rgb(182,239,255),bubbleR*.25f,bubbleR*2.2f,.30f);
                }else if(isArmorBubbleValue(v)){
                    grid.put(nk,baseColorOf(v));spawnPop(q,v,5);addRing(q.x,q.y,Color.rgb(205,224,255),bubbleR*.22f,bubbleR*1.9f,.28f);
                }
            }
        }
    }

    private void triggerPerfectShot(PointF p,int impact){
        perfectShotTimer=.72f;
        int bonus=150+impact*15;levelScore+=bonus;
        floatingTexts.add(new FloatingText("PERFECT BANK SHOT! +"+bonus,getWidth()*.5f,getHeight()*.39f,Color.rgb(255,235,94),30f));
        feverBurst=Math.max(feverBurst,.7f);screenShake=Math.max(screenShake,13f);
        addRing(p.x,p.y,Color.rgb(255,225,88),bubbleR*.5f,bubbleR*5.2f,.55f);
        audio.play(AudioEngine.FX_MAGIC,1f,1.18f);haptic(55);
    }

    private void triggerCannonMatchBurst(PointF p,int colorIndex,int affected){
        // v5.5.8: compact Option 5 fire VFX localized to the exact collision point.
        cannonBurstTimer=0.72f;
        cannonBurstX=p.x;
        cannonBurstY=p.y;
        cannonBurstColor=PALETTE[Math.max(0,Math.min(PALETTE.length-1,baseColorOf(colorIndex)))];
        cannonBurstPower=Math.min(1.72f,1.00f+affected*.11f);
        float u=uiScale();
        float powerScale=cannonBurstPower;
        int pieces=28+Math.min(30,affected*4);
        for(int i=0;i<pieces;i++){
            float a=random.nextFloat()*6.2831855f;
            float sp=180f+random.nextFloat()*560f*powerScale;
            int col=(i%7==0)?Color.WHITE:(i%3==0?Color.rgb(255,194,66):Color.rgb(255,86+random.nextInt(55),18));
            particles.add(new Particle(p.x,p.y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp-25f,col,2.2f+random.nextFloat()*5.2f,.34f+random.nextFloat()*.55f));
        }
        // Match-only persistent debris. Use a wide, upward-and-outward fan rather
        // than a fully random circle: later bursts must visibly spread beyond the
        // pile left by earlier matches. This method is called only from the >=3
        // same-colour match branch in settleShot().
        int chunks=20+Math.min(22,affected*2);
        int baseDebris=cannonBurstColor;
        int[] concreteCols={darken(baseDebris,.62f),darken(baseDebris,.48f),darken(baseDebris,.38f),darken(baseDebris,.30f)};
        for(int i=0;i<chunks;i++){
            float side=(i%2==0)?-1f:1f;
            float spread=random.nextFloat();
            float vx=side*(190f+spread*420f*powerScale);
            // Keep the initial arc visible; gravity brings each chunk down to the floor.
            float vy=-250f-random.nextFloat()*330f;
            float sz=(7.0f+random.nextFloat()*11.5f)*u;
            float originJitter=(random.nextFloat()-.5f)*bubbleR*.24f;
            glassShards.add(new GlassShard(p.x+originJitter,
                    p.y+(random.nextFloat()-.5f)*bubbleR*.18f,vx,vy,sz*(.78f+random.nextFloat()*.65f),
                    sz*(.72f+random.nextFloat()*.62f),(random.nextFloat()-.5f)*22f,
                    concreteCols[random.nextInt(concreteCols.length)],2.4f+random.nextFloat()*1.2f,true));
        }
        for(int i=0;i<18+affected*2;i++){
            float a=random.nextFloat()*6.2831855f;
            float sp=70f+random.nextFloat()*300f;
            int dust=Color.rgb(145+random.nextInt(45),140+random.nextInt(38),128+random.nextInt(35));
            particles.add(new Particle(p.x,p.y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp-120f,dust,
                    2.5f+random.nextFloat()*5.5f,.55f+random.nextFloat()*.55f));
        }
        // No global flash: the fireball itself supplies the local illumination.
        screenShake=Math.max(screenShake,Math.min(18f,9.5f+affected*.85f));
        audio.play(AudioEngine.FX_EXPLOSION_E1,1.0f,0.94f+Math.min(.18f,affected*.012f));
        haptic(Math.min(100,58+affected*7));
    }

    private void drawCannonImpactFx(Canvas c){
        if(cannonBurstTimer<=0f)return;
        float u=uiScale();
        float t=clamp01(1f-cannonBurstTimer/.72f);
        int frame=Math.min(cannonExplosionFrames.length-1,(int)(t*cannonExplosionFrames.length));
        Bitmap b=cannonExplosionFrames[frame];
        if(b!=null && !b.isRecycled()){
            float power=Math.min(1.72f,cannonBurstPower);
            float size=bubbleR*(3.45f+0.82f*power);
            // Keep the real-fire sprite tightly localized to the actual collision point.
            float wobble=1f+.035f*(float)Math.sin(ambientTime*17f);
            size*=wobble;
            RectF dst=new RectF(cannonBurstX-size,cannonBurstY-size,cannonBurstX+size,cannonBurstY+size);
            Paint old=paint;
            int alpha=(int)(255f*(1f-clamp01((t-.78f)/.22f)));
            old.setAlpha(Math.max(0,Math.min(255,alpha)));
            c.drawBitmap(b,null,dst,old);
            old.setAlpha(255);
        }
        // A few physical hot embers supplement the footage-like fire without drawing rings or lines.
        float fade=1f-clamp01((t-.34f)/.38f);
        for(int i=0;i<9;i++){
            float a=i*.83f+ambientTime*1.1f;
            float d=bubbleR*(1.2f+i%4*.45f)*cannonBurstPower;
            float ex=cannonBurstX+(float)Math.cos(a)*d;
            float ey=cannonBurstY+(float)Math.sin(a)*d*.72f-(t*t)*bubbleR*(.25f+i*.04f);
            paint.setColor(Color.argb((int)(150*fade),255,140+(i%3)*35,38));
            c.drawCircle(ex,ey,(1.1f+(i%3)*.7f)*u,paint);
        }
    }

    private void settleShot() {
        shotFlying=false;
        shotFlightTime=0f;
        int[] cell=findNearestOpenCell(shotX,shotY);
        if(cell==null){addCeilingRow();return;}
        int row=cell[0],col=cell[1];
        int placedColor=shotColor;
        if(shotPower==Power.RAINBOW){Integer n=findBestWildColor(row,col);if(n!=null)placedColor=n;}
        grid.put(key(row,col),placedColor);
        PointF p=cellCenter(row,col);
        impactX=p.x;impactY=p.y;impactTimer=.82f;impactStrength=Math.max(15f,bubbleR*.72f);screenShake=Math.max(screenShake,16f);
        spawnLandingSparkles(p.x,p.y,placedColor);
        // Debris is generated only by a valid 3+ match explosion below.
        // A landing without a match must not create debris.
        haptic(30);

        int removed=0;int affected=0;shotChestBonus=0;shotStarBonus=0;shotMysteryScore=0;
        HashSet<Integer> poppedKeys=new HashSet<>();
        if(shotPower==Power.BOMB){
            HashSet<Integer> blast=new HashSet<>();blast.add(key(row,col));for(int nk:neighborKeys(row,col))if(nk!=-999&&grid.containsKey(nk))blast.add(nk);
            // Bombs also crack a second ring on harder levels.
            if(selectedLevel>=120){HashSet<Integer> ring2=new HashSet<>();for(int bk:blast)for(int nk:neighborKeys(rowOf(bk),colOf(bk)))if(nk!=-999&&grid.containsKey(nk))ring2.add(nk);int cap=0;for(int k:ring2){if(cap++>=4)break;blast.add(k);}}
            for(int k:blast){if(grid.containsKey(k)){affected++;removed+=processBubbleRemoval(k,true);poppedKeys.add(k);}}
            screenShake=15f;haptic(62);combo=Math.max(1,combo+1);misses=0;
        }else{
            Set<Integer> match=floodSame(row,col,placedColor);
            if(match.size()>=3 || (shotPower==Power.RAINBOW && match.size()>=2)){
                combo++;
                for(int k:match){affected++;removed+=processBubbleRemoval(k,false);poppedKeys.add(k);}
                PointF burstPoint=cellCenter(row,col);
                // Two matching bubbles already on the board + the fired bubble create
                // the new cannon-burst/shatter moment. Larger matches scale it up.
                triggerCannonMatchBurst(burstPoint,placedColor,match.size());
                reactToNearbyObstacles(match);
                if(combo>=2)audio.play(AudioEngine.FX_COMBO,.8f,Math.min(1.4f,1f+combo*.05f));
                screenShake=Math.min(20f,5f+affected*1.0f);haptic(Math.min(82,24+affected*5));misses=0;
            }else{combo=0;misses++;addRing(p.x,p.y,Color.WHITE,bubbleR*.18f,bubbleR*1.75f,.22f);haptic(26);}
        }

        if(affected>0){
            impactTimer=.82f;impactStrength=Math.max(15f,bubbleR*.72f);
            int detached=dropDetached();
            int clearedThisShot=Math.max(0,removed-(grid.containsKey(key(row,col))?0:1))+detached;
            clearedBubbles=Math.min(initialBubbleCount,clearedBubbles+Math.max(0,clearedThisShot));
            chargeSuper(Math.max(affected,removed),detached);
            updateRealmCompanionAndFusion(affected+detached);
            if(combo>=5&&feverTimer<=0f)triggerFever();
            int multiplier=feverTimer>0f?2:1;
            int points=(removed*38+detached*60+Math.max(0,combo-1)*55+shotStarBonus+shotMysteryScore)*multiplier;
            levelScore+=points;
            if(shotChestBonus>0){coins+=shotChestBonus;prefs.edit().putInt("coins",coins).apply();audio.play(AudioEngine.FX_TREASURE,.95f,1f);floatingTexts.add(new FloatingText("TREASURE +"+shotChestBonus+" COINS",getWidth()*.5f,getHeight()*.34f,Color.rgb(255,228,92),28f));}
            if(shotStarBonus>0)floatingTexts.add(new FloatingText("STAR +"+shotStarBonus,getWidth()*.5f,getHeight()*.30f,Color.rgb(181,245,255),28f));
            popFlash=Math.min(1f,.28f+affected*.035f);
            floatingTexts.add(new FloatingText((multiplier>1?"x2  ":"")+"+"+points,p.x,p.y-20f,Color.WHITE,26f));
            announceShotPraise(affected,detached);
            if(combo>=2)floatingTexts.add(new FloatingText("COMBO x"+combo,getWidth()*.5f,getHeight()*.42f,Color.rgb(255,225,54),31f));
            if(combo>=4){int bonusScore=90+Math.min(260,combo*24);levelScore+=bonusScore;audio.play(AudioEngine.FX_STREAK,.9f,1f+Math.min(.3f,combo*.03f));floatingTexts.add(new FloatingText("STREAK +"+bonusScore+" SCORE",getWidth()*.5f,getHeight()*.47f,Color.rgb(255,237,90),24f));}
            int impact=affected+detached;if(shotBankBounces>0&&impact>=8)triggerPerfectShot(p,impact);
            float clearProgress=clearedBubbles/(float)Math.max(1,clearTarget);
            if(!almostThereAnnounced&&clearProgress>=.82f){almostThereAnnounced=true;floatingTexts.add(new FloatingText("ALMOST THERE!",getWidth()*.5f,getHeight()*.48f,Color.rgb(255,235,104),28f));audio.play(AudioEngine.FX_MAGIC,.72f,1.10f);feverBurst=Math.max(feverBurst,.32f);}
        }

        if(objective==Objective.BOSS&&gameMode==GameMode.ADVENTURE)bossAfterShot(Math.max(affected,removed));
        int missLimit=selectedLevel<=3?2:selectedLevel<=60?2:1;if(isBossLevel(selectedLevel))missLimit=1;
        // Resolve a completed objective before pressure rows can interrupt the win.
        pruneFloatingSingles();
        checkEndState();
        if(overlay!=Overlay.NONE){saveGameState();return;}
        if(misses>=missLimit){misses=0;shotsSinceDrop=0;addCeilingRow();return;}
        if(shotsSinceDrop>=pressureLimit&&clearedBubbles<clearTarget){shotsSinceDrop=0;addCeilingRow();return;}
        saveGameState();
    }

    private int[] findNearestOpenCell(float x,float y){
        float best=Float.MAX_VALUE;int br=-1,bc=-1;
        for(int r=0;r<GRID_ROWS;r++){
            for(int c=0;c<GRID_COLS;c++){
                int k=key(r,c);if(grid.containsKey(k))continue;
                PointF p=cellCenter(r,c);float dx=x-p.x,dy=y-p.y;float d=dx*dx+dy*dy;
                if(d<best){best=d;br=r;bc=c;}
            }
        }
        if(br<0)return null;
        // Keep shots connected to ceiling or an existing bubble.
        if(br>0){
            boolean connected=false;for(int nk:neighborKeys(br,bc))if(grid.containsKey(nk)){connected=true;break;}
            if(!connected){
                float altBest=Float.MAX_VALUE;int ar=-1,ac=-1;
                for(int r=0;r<GRID_ROWS;r++)for(int c=0;c<GRID_COLS;c++){
                    if(grid.containsKey(key(r,c)))continue;
                    boolean conn=r==0;for(int nk:neighborKeys(r,c))if(grid.containsKey(nk)){conn=true;break;}
                    if(!conn)continue;
                    PointF p=cellCenter(r,c);float dx=x-p.x,dy=y-p.y;float d=dx*dx+dy*dy;
                    if(d<altBest){altBest=d;ar=r;ac=c;}
                }
                if(ar>=0){br=ar;bc=ac;}
            }
        }
        return new int[]{br,bc};
    }

    private Set<Integer> floodSame(int row,int col,int color){
        int targetBase=baseColorOf(color);
        HashSet<Integer> out=new HashSet<>();ArrayDeque<Integer> q=new ArrayDeque<>();
        int start=key(row,col);q.add(start);out.add(start);
        // A normal hex-neighbour flood is kept, but we also accept same-colour bubbles
        // that are visibly touching. This protects matching from snap/parity/formation
        // edge cases: if the player can see the bubbles touching, the cluster will pop.
        final float touchLimit=bubbleR*2.20f;
        final float touchLimitSq=touchLimit*touchLimit;
        while(!q.isEmpty()){
            int k=q.removeFirst();int r=rowOf(k),c=colOf(k);
            PointF kp=cellCenter(r,c);
            // Fast path: exact logical neighbours.
            for(int nk:neighborKeys(r,c)){
                Integer nc=grid.get(nk);
                if(nc!=null && !isStoneBubbleValue(nc) && !isChainBubbleValue(nc) && !isCloudBubbleValue(nc)
                        && baseColorOf(nc)==targetBase && out.add(nk)){q.addLast(nk);}
            }
            // Reliability path: any visually touching same-colour bubble.
            for(Map.Entry<Integer,Integer> e:grid.entrySet()){
                int nk=e.getKey();if(out.contains(nk))continue;
                Integer nc=e.getValue();
                if(nc==null || isStoneBubbleValue(nc) || isChainBubbleValue(nc) || isCloudBubbleValue(nc)
                        || baseColorOf(nc)!=targetBase)continue;
                PointF np=cellCenter(rowOf(nk),colOf(nk));
                float dx=kp.x-np.x,dy=kp.y-np.y;
                if(dx*dx+dy*dy<=touchLimitSq){out.add(nk);q.addLast(nk);}
            }
        }
        return out;
    }

    private int dropDetached(){
        HashSet<Integer> connected=new HashSet<>();ArrayDeque<Integer> q=new ArrayDeque<>();
        for(int c=0;c<GRID_COLS;c++){int k=key(0,c);if(grid.containsKey(k)){connected.add(k);q.add(k);}}
        while(!q.isEmpty()){
            int k=q.removeFirst();for(int nk:neighborKeys(rowOf(k),colOf(k)))if(grid.containsKey(nk)&&connected.add(nk))q.addLast(nk);
        }
        ArrayList<Integer> loose=new ArrayList<>();for(int k:grid.keySet())if(!connected.contains(k))loose.add(k);
        for(int k:loose){
            Integer col=grid.remove(k);
            if(col!=null){
                if(isBabyBubbleValue(col)&&objective==Objective.RESCUE)objectiveProgress++;
                if(isKeyBubbleValue(col)&&objective==Objective.KEYS)objectiveProgress++;
                if(isIceBubbleValue(col)&&objective==Objective.ICE_BREAK)objectiveProgress++;
                if(isChestBubbleValue(col)){if(objective==Objective.TREASURE)objectiveProgress++;coins+=2;prefs.edit().putInt("coins",coins).apply();}
                if(isMysteryBubbleValue(col)){coins+=1;prefs.edit().putInt("coins",coins).apply();}
                PointF p=cellCenter(rowOf(k),colOf(k));
                falling.add(new FallingBubble(p.x,p.y,(random.nextFloat()-.5f)*130f,-80f-random.nextFloat()*160f,baseColorOf(col),(random.nextFloat()-.5f)*210f));
            }
        }
        if(!loose.isEmpty()){audio.play(AudioEngine.FX_COMBO,.78f,1.15f);audio.play(AudioEngine.FX_DROP,.66f,1f);screenShake=Math.max(screenShake,10f);feverBurst=Math.max(feverBurst,.35f);addRing(getWidth()*.5f,gridTop+rowH*3f,Color.rgb(133,228,255),bubbleR*1.0f,bubbleR*5.0f,.58f);}
        return loose.size();
    }

    private void addCeilingRowNoCheck(){
        HashMap<Integer,Integer> moved=new HashMap<>();
        for(Map.Entry<Integer,Integer> e:grid.entrySet()){
            int r=rowOf(e.getKey()),c=colOf(e.getKey());
            if(r+1<GRID_ROWS)moved.put(key(r+1,c),e.getValue());
        }
        grid.clear();grid.putAll(moved);
        // Moving every old cell down by one row flips the geometric odd/even row.
        // Flip the phase too, so every existing bubble keeps exactly the same X
        // coordinate and only moves downward when a pressure row is inserted.
        gridParityPhase ^= 1;
        int difficultyLevel=gameMode==GameMode.SURVIVAL?Math.max(selectedLevel,survivalWave*12):selectedLevel;
        int active=difficultyLevel<=2?3:difficultyLevel<=28?4:difficultyLevel<=90?5:difficultyLevel<=210?6:Math.min(PALETTE.length,8);
        float fillChance=gameMode==GameMode.SURVIVAL?Math.min(.99f,.91f+survivalWave*.008f):(difficultyLevel<=25?.92f:difficultyLevel<=180?.95f:.98f);
        int world=worldIndex(Math.max(1,difficultyLevel));
        for(int c=0;c<GRID_COLS;c++)if(random.nextFloat()<fillChance){
            int base=random.nextInt(active);int value=base;float hazard=random.nextFloat();
            if(difficultyLevel>=12&&hazard<.035f)value=makeSpecialBubble(SPECIAL_LIGHTNING,base);
            else if(difficultyLevel>=25&&hazard<.060f)value=makeSpecialBubble(SPECIAL_MAGNET,base);
            else if(difficultyLevel>=45&&hazard<.080f)value=makeSpecialBubble(SPECIAL_PAINT,base);
            else if(difficultyLevel>=85&&hazard<.095f)value=makeSpecialBubble(SPECIAL_BLACK_HOLE,base);
            else if(difficultyLevel>=35&&(world==5||world==11)&&hazard<.18f)value=makeSpecialBubble(SPECIAL_ICE,base);
            else if(difficultyLevel>=110&&(world==7||world==15)&&hazard<.11f)value=makeSpecialBubble(SPECIAL_CHAIN,base);
            else if(difficultyLevel>=140&&(world==8||world==16)&&hazard<.09f)value=makeSpecialBubble(SPECIAL_CLOUD,base);
            else if(difficultyLevel>=200&&(world==10||world==17)&&hazard<.07f)value=makeSpecialBubble(SPECIAL_STONE,base);
            grid.put(key(0,c),value);
        }
        rowDropTimer=.38f;
    }

    private void addCeilingRow(){
        addCeilingRowNoCheck();
        String msg=gameMode==GameMode.SURVIVAL?("SURVIVAL WAVE "+survivalWave+" ↓"):(isBossLevel(selectedLevel)?"BOSS ATTACK ↓":"BUBBLE WAVE ↓");
        floatingTexts.add(new FloatingText(msg,getWidth()*.5f,gridTop+90f,Color.rgb(255,126,92),27f));
        addRing(getWidth()*.5f,gridTop+rowH,Color.rgb(255,155,78),bubbleR*.6f,bubbleR*4.5f,.55f);
        screenShake=10f;audio.play(AudioEngine.FX_BOUNCE,.72f,.72f);haptic(38);
        pruneFloatingSingles();
        saveGameState();
        checkEndState();
    }

    private void pruneFloatingSingles(){
        ArrayList<Integer> looseSingles=new ArrayList<>();
        for(int k:new ArrayList<>(grid.keySet())){
            int row=rowOf(k),col=colOf(k);
            if(row<=0)continue;
            int occupied=0;
            for(int nk:neighborKeys(row,col))if(grid.containsKey(nk))occupied++;
            if(occupied==0)looseSingles.add(k);
        }
        for(int k:looseSingles){
            Integer col=grid.remove(k);
            if(col!=null){
                if(isBabyBubbleValue(col)&&objective==Objective.RESCUE)objectiveProgress++;
                if(isKeyBubbleValue(col)&&objective==Objective.KEYS)objectiveProgress++;
                if(isIceBubbleValue(col)&&objective==Objective.ICE_BREAK)objectiveProgress++;
                if(isChestBubbleValue(col)&&objective==Objective.TREASURE)objectiveProgress++;
                PointF p=cellCenter(rowOf(k),colOf(k));
                spawnPop(p,col,7);
                audio.play(AudioEngine.FX_POP,.85f,1.02f);
                falling.add(new FallingBubble(p.x,p.y,0f,240f,baseColorOf(col),(random.nextFloat()-.5f)*160f));
                clearedBubbles++;
            }
        }
    }

    private void checkEndState(){
        boolean danger=false;
        for(int k:grid.keySet())if(cellCenter(rowOf(k),colOf(k)).y+bubbleR>dangerY){danger=true;break;}

        if(gameMode==GameMode.SURVIVAL){
            if(danger){loseLevel();return;}
            boolean waveCleared=grid.isEmpty()||clearedBubbles>=clearTarget||grid.size()<=Math.max(8,initialBubbleCount/3);
            if(waveCleared){
                survivalWave++;
                int waveBonus=100+survivalWave*35;levelScore+=waveBonus;
                superCharge=Math.min(100,superCharge+18);
                floatingTexts.add(new FloatingText("WAVE "+survivalWave+" • +"+waveBonus,getWidth()*.5f,getHeight()*.42f,Color.rgb(255,231,91),27f));
                buildSurvivalWave(false);
                initialBubbleCount=Math.max(1,grid.size());clearTarget=Math.max(1,(int)Math.ceil(initialBubbleCount*.58f));clearedBubbles=0;
                shotsSinceDrop=0;pressureLimit=Math.max(3,5-survivalWave/6);
                configureDynamicLevelSystems(Math.max(selectedLevel,survivalWave*12));
                currentColor=pickExistingColor();nextColor=pickExistingColor();
                audio.play(AudioEngine.FX_LEVEL_UP_CHIME,.92f,1.04f);haptic(45);
            }
            return;
        }

        boolean clearEnough=grid.isEmpty()||clearedBubbles>=clearTarget;
        // Collect/rescue/ice/treasure stages finish as soon as the displayed
        // objective reaches its target; they must not require a hidden clear quota.
        if(gameMode==GameMode.ADVENTURE && objective!=Objective.CLEAR
                && objective!=Objective.LIMITED && objective!=Objective.BOSS
                && objectiveMet()){winLevel();return;}
        // Safety valve: if the player has completely cleared a boss board, break any tiny
        // shield remainder so a perfectly played level can never become unwinnable.
        if(objective==Objective.BOSS && grid.isEmpty() && bossShield>0){
            bossShield=0;onBossShieldBroken();
        }
        if(clearEnough&&objectiveMet()){winLevel();return;}
        if(shotsLeft<=0){ showRewardOffer(1); return; }
        if(danger){loseLevel();}
    }

    private void winTreasureRoom(){
        overlay=Overlay.WIN;winCelebrationTimer=0f;winStarSoundStage=0;lastLevelWasUnlock=false;
        lastWinStars=3;lastWinClearPercent=Math.min(100,Math.round(clearedBubbles*100f/Math.max(1,initialBubbleCount)));
        int reward=8+Math.min(10,objectiveProgress*2);
        lastChestBonus=reward;lastBossBonus=0;lastWinReward=reward;milestoneText="TREASURE ROOM CLEARED • BONUS STASH";
        coins+=reward;prefs.edit().putInt("coins",coins).apply();
        audio.play(AudioEngine.FX_TREASURE,1f,1.08f);audio.play(AudioEngine.FX_WIN,.88f,1f);haptic(130);
        feverBurst=1f;screenShake=13f;
        for(int i=0;i<90;i++){int color=PALETTE[random.nextInt(PALETTE.length)];particles.add(new Particle(getWidth()*.5f,getHeight()*.42f,(random.nextFloat()-.5f)*720f,-random.nextFloat()*680f,color,3f+random.nextFloat()*8f,1.2f+random.nextFloat()*.9f));}
    }

    private void winLevel(){
        if(gameMode==GameMode.TREASURE_ROOM){winTreasureRoom();return;}
        if(gameMode==GameMode.SURVIVAL)return;
        boolean challenge=dailyChallengeMode;
        boolean newlyUnlocked=!challenge && selectedLevel>=maxUnlocked && selectedLevel<MAP_LEVELS;
        lastLevelWasUnlock=newlyUnlocked;winStarSoundStage=0;
        overlay=Overlay.WIN;winCelebrationTimer=0f;audio.play(AudioEngine.FX_CLEAR90,1f,1f);audio.play(AudioEngine.FX_WIN,.88f,1f);haptic(140);
        lastWinClearPercent=Math.min(100,Math.round(clearedBubbles*100f/Math.max(1,initialBubbleCount)));
        int stars=1;
        if(lastWinClearPercent>=Math.min(100,Math.round(objectiveClearRatio()*100f)+5) && shotsLeft>=3)stars=2;
        if(lastWinClearPercent>=Math.min(100,Math.round(objectiveClearRatio()*100f)+12) && shotsLeft>=7 && levelScore>=targetScore)stars=3;
        lastWinStars=stars;
        if(!challenge){
            int old=prefs.getInt("stars_"+selectedLevel,0);
            if(stars>old){totalStars+=stars-old;prefs.edit().putInt("stars_"+selectedLevel,stars).putInt("totalStars",totalStars).apply();}
        }

        if(challenge){winStreak=prefs.getInt("win_streak",0);}
        else {winStreak=prefs.getInt("win_streak",0)+1;prefs.edit().putInt("win_streak",winStreak).putInt("loss_streak_"+selectedLevel,0).apply();}
        // v5 economy: progression stays fair while coins and boosters retain meaningful value.
        int reward=2+stars*2;lastChestBonus=0;lastBossBonus=0;milestoneText=null;
        if(lastWinClearPercent>=98)reward+=1;
        if(objective!=Objective.CLEAR)reward+=1;
        if(!challenge&&isChestLevel(selectedLevel)){lastChestBonus=4;reward+=lastChestBonus;audio.play(AudioEngine.FX_TREASURE,1f,1.03f);}
        if(selectedLevel%25==0 && !challenge){reward+=3;}
        if(!challenge&&isBossLevel(selectedLevel)){lastBossBonus=6;reward+=lastBossBonus;milestoneText="BOSS DOWN • +6 COINS";}

        if(!challenge&&winStreak==3){reward+=2;milestoneText="3 WIN STREAK • +2 COINS";}
        else if(!challenge&&winStreak==5){reward+=3;milestoneText="5 WIN STREAK • +3 COINS";}
        else if(!challenge&&winStreak>0&&winStreak%10==0){reward+=5;milestoneText=winStreak+" WIN STREAK • +5 COINS";}

        String event=dailyEventName();
        if(event.equals("DOUBLE COIN DAY"))reward*=2;
        else if(event.equals("TREASURE HUNT")&&isChestLevel(selectedLevel))reward+=3;
        else if(event.equals("BUBBLE RUSH")&&shotsLeft>=7)reward+=2;
        else if(event.equals("BOSS BOUNTY")&&isBossLevel(selectedLevel))reward+=4;
        if(challenge){
            if(!isDailyChallengeClaimed()){reward+=8;prefs.edit().putString("daily_challenge_done",todayKey()).apply();milestoneText="DAILY CHALLENGE COMPLETE • +8 BONUS";}
            else {reward=2;milestoneText="DAILY REPLAY • +2 BONUS";}
        }

        if(!challenge){
            int chestTier=totalStars/30;int claimed=prefs.getInt("star_chest_tier",0);
            if(chestTier>claimed){
                reward+=6;
                // Star chests favor progression/score; boosters stay rare so the coin shop retains value.
                if(chestTier%4==0)bombCount++;
                prefs.edit().putInt("star_chest_tier",chestTier).putInt("bomb_inventory",bombCount).putInt("wild_inventory",rainbowCount).apply();
                milestoneText="30-STAR MEGA CHEST UNLOCKED!";audio.play(AudioEngine.FX_TREASURE,1f,1.12f);
            }
            int skinTier=Math.min(4,totalStars/60);int oldSkin=prefs.getInt("cannon_skin_tier",0);
            if(skinTier>oldSkin){prefs.edit().putInt("cannon_skin_tier",skinTier).apply();milestoneText="NEW CANNON SKIN UNLOCKED • TIER "+skinTier;audio.play(AudioEngine.FX_MAGIC,.95f,1.16f);}
        }

        if(!challenge && selectedLevel%25==0 && !prefs.getBoolean("relic_level_"+selectedLevel,false)){
            relicCount++;
            prefs.edit().putInt("relic_count",relicCount).putBoolean("relic_level_"+selectedLevel,true).apply();
            milestoneText="REALM RELIC FOUND • "+relicCount+"/20";
            audio.play(AudioEngine.FX_MAGIC,.9f,1.22f);
        }

        if(!challenge && (selectedLevel==25||selectedLevel==50||selectedLevel==100||selectedLevel==250||selectedLevel==500||selectedLevel==750||selectedLevel==1000)){
            int milestoneBonus=selectedLevel>=250?20:selectedLevel>=100?14:10;reward+=milestoneBonus;if(selectedLevel%100==0)bombCount++;prefs.edit().putInt("bomb_inventory",bombCount).putInt("wild_inventory",rainbowCount).apply();milestoneText="LEVEL "+selectedLevel+" MILESTONE • BONUS";
        }
        if(!challenge&&activeBranchRoute==2){reward+=2;milestoneText="TREASURE ROUTE • +2 COINS";}
        else if(!challenge&&activeBranchRoute==1&&superCharge>=75){reward+=1;milestoneText="POWER ROUTE MASTERED";}
        treasureRoomPending=!challenge&&isTreasureRoomAvailableAfter(selectedLevel);

        lastWinReward=reward;coins+=reward;int best=Math.max(displayedBest,levelScore);
        SharedPreferences.Editor ed=prefs.edit().putInt("coins",coins);
        if(challenge)ed.putInt("daily_best",Math.max(prefs.getInt("daily_best",0),levelScore));else ed.putInt("best_"+selectedLevel,best);
        if(!challenge&&selectedLevel>=maxUnlocked&&selectedLevel<MAP_LEVELS){maxUnlocked=selectedLevel+1;ed.putInt("maxUnlocked",maxUnlocked);}
        ed.apply();clearSavedGame();
        if(newlyUnlocked)audio.playLevelUpDelayed(1050L);
        feverBurst=1f;screenShake=14f;addRing(getWidth()*.5f,getHeight()*.42f,Color.rgb(255,220,55),30f,520f,.85f);addRing(getWidth()*.5f,getHeight()*.42f,Color.rgb(96,224,255),55f,430f,.92f);
        if(milestoneText!=null)floatingTexts.add(new FloatingText(milestoneText,getWidth()*.5f,getHeight()*.55f,Color.rgb(255,231,103),24f));
        for(int i=0;i<145;i++){int color=PALETTE[random.nextInt(PALETTE.length)];particles.add(new Particle(getWidth()*.5f,getHeight()*.42f,(random.nextFloat()-.5f)*860f,-random.nextFloat()*820f,color,3f+random.nextFloat()*9f,1.5f+random.nextFloat()*1.2f));}
    }

    private void loseLevel(){
        // Session modes must not erase an Adventure run that was saved before entering them.
        if(gameMode==GameMode.ADVENTURE)clearSavedGame();
        if(gameMode==GameMode.SURVIVAL){
            survivalBest=Math.max(prefs.getInt("survival_best",0),levelScore);
            prefs.edit().putInt("survival_best",survivalBest).apply();
            levelLossStreak=0;winStreak=prefs.getInt("win_streak",0);
        }else if(gameMode==GameMode.TREASURE_ROOM){
            levelLossStreak=0;winStreak=prefs.getInt("win_streak",0);
        }else if(dailyChallengeMode){levelLossStreak=0;winStreak=prefs.getInt("win_streak",0);}
        else {levelLossStreak=prefs.getInt("loss_streak_"+selectedLevel,0)+1;prefs.edit().putInt("loss_streak_"+selectedLevel,levelLossStreak).putInt("win_streak",0).apply();winStreak=0;}
        overlay=Overlay.LOSE;loseCelebrationTimer=0f;audio.play(AudioEngine.FX_FAIL,.9f,1f);haptic(90);
        if(gameMode==GameMode.SURVIVAL)floatingTexts.add(new FloatingText("SURVIVAL BEST "+survivalBest,getWidth()*.5f,getHeight()*.50f,Color.rgb(255,226,92),22f));
        else if(gameMode==GameMode.TREASURE_ROOM)floatingTexts.add(new FloatingText("TREASURE ROOM ENDED",getWidth()*.5f,getHeight()*.50f,Color.rgb(255,213,106),22f));
        else if(levelLossStreak>=3)floatingTexts.add(new FloatingText("COMEBACK BOOST READY • +3 SHOTS",getWidth()*.5f,getHeight()*.50f,Color.rgb(151,235,255),22f));
    }

    private int pickExistingColor(){
        if(grid.isEmpty())return random.nextInt(3);
        ArrayList<Integer> list=new ArrayList<>();
        for(Integer c:grid.values()){if(c==null||isStoneBubbleValue(c)||isChainBubbleValue(c)||isCloudBubbleValue(c))continue;int base=baseColorOf(c);if(!list.contains(base))list.add(base);}
        if(list.isEmpty())for(Integer c:grid.values()){if(c!=null){int base=baseColorOf(c);if(!list.contains(base))list.add(base);}}
        return list.isEmpty()?random.nextInt(3):list.get(random.nextInt(list.size()));
    }

    // Select the Wild color that produces the largest real connected match.
    // The old implementation picked a random adjacent color, often wasting Wild.
    private Integer findBestWildColor(int row,int col){
        int shotKey=key(row,col);
        Integer previous=grid.get(shotKey);
        Integer best=null;
        int bestCount=-1;
        HashSet<Integer> candidates=new HashSet<>();
        for(int nk:neighborKeys(row,col)){
            Integer color=grid.get(nk);
            if(color!=null&&!isStoneBubbleValue(color)&&!isChainBubbleValue(color)
                    &&!isCloudBubbleValue(color))candidates.add(baseColorOf(color));
        }
        for(int color:candidates){
            grid.put(shotKey,color);
            int count=floodSame(row,col,color).size();
            if(count>bestCount){bestCount=count;best=color;}
        }
        if(previous==null)grid.remove(shotKey);else grid.put(shotKey,previous);
        return best;
    }

    private Integer findNeighborColor(int row,int col){
        ArrayList<Integer> options=new ArrayList<>();for(int k:neighborKeys(row,col)){Integer c=grid.get(k);if(c!=null&&!isStoneBubbleValue(c)&&!isChainBubbleValue(c)&&!isCloudBubbleValue(c))options.add(baseColorOf(c));}
        return options.isEmpty()?null:options.get(random.nextInt(options.size()));
    }

    private int[] neighborKeys(int row,int col){
        int[][] d;
        if(((row+gridParityPhase)&1)==0)d=new int[][]{{-1,-1},{-1,0},{0,-1},{0,1},{1,-1},{1,0}};
        else d=new int[][]{{-1,0},{-1,1},{0,-1},{0,1},{1,0},{1,1}};
        int[] out=new int[6];for(int i=0;i<6;i++){int r=row+d[i][0],c=col+d[i][1];out[i]=(r<0||r>=GRID_ROWS||c<0||c>=GRID_COLS)?-999:key(r,c);}return out;
    }

    private float boardStartLiftPx(){
        float rowsLift;
        if(selectedLevel<=5) rowsLift=1.25f;
        else if(selectedLevel<=25) rowsLift=1.00f;
        else if(selectedLevel<=120) rowsLift=0.72f;
        else rowsLift=0.50f;
        if(gameMode==GameMode.SURVIVAL) rowsLift*=0.42f;
        if(gameMode==GameMode.TREASURE_ROOM) rowsLift*=0.30f;
        float progress=clearTarget<=0?0f:clamp01(clearedBubbles/(float)Math.max(1,clearTarget));
        return rowH*rowsLift*(1f-progress);
    }

    private PointF cellCenter(int row,int col){
        // 10-column staggered hex grid. v4.0 can animate the whole formation while keeping
        // collision/snapping tied to the exact same transformed positions.
        float usable=getWidth()-bubbleR*2.2f;
        float spacing=usable/(GRID_COLS-.5f);
        float x=bubbleR*1.1f+col*spacing+(((row+gridParityPhase)&1)==1?spacing*.5f:0f);
        float y=gridTop+row*rowH-boardStartLiftPx();
        if(screen==Screen.GAME && formationMode>0){
            float cx=getWidth()*.5f, cy=gridTop+rowH*4.6f;
            if(formationMode==1){
                x += (float)Math.sin(ambientTime*.78f+row*.37f)*Math.min(10f,bubbleR*.32f);
            }else if(formationMode==2){
                float ang=(float)Math.toRadians(2.65f*Math.sin(ambientTime*.43f));
                float dx=x-cx,dy=y-cy;
                float ca=(float)Math.cos(ang),sa=(float)Math.sin(ang);
                x=cx+dx*ca-dy*sa;
                y=cy+dx*sa+dy*ca;
            }else{
                float scale=1f+.012f*(float)Math.sin(ambientTime*.72f);
                x=cx+(x-cx)*scale;
                y += (float)Math.sin(ambientTime*.9f+col*.42f+row*.15f)*Math.min(7f,bubbleR*.22f);
            }
        }
        return new PointF(x,y);
    }

    private int key(int row,int col){return row*100+col;}
    private int rowOf(int key){return key/100;}
    private int colOf(int key){return key%100;}

    // ---------------------------------------------------------------
    // Bubble rendering and particles
    // ---------------------------------------------------------------

    private void recycleSprites(){
        for(Bitmap b:bubbleSprites)if(b!=null&&!b.isRecycled())b.recycle();
    }

    private void buildBubbleSprites(){
        recycleSprites();
        bubbleSprites=new Bitmap[PALETTE.length];
        int size=Math.max(48,(int)(bubbleR*2.45f));
        for(int i=0;i<PALETTE.length;i++)bubbleSprites[i]=makeBubbleBitmap(size,PALETTE[i]);
    }

    private Bitmap makeBubbleBitmap(int size, int base){
        Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        float cx=size*.5f,cy=size*.5f,r=size*.405f;
        // IMPORTANT: no detached black shadow is baked into the sprite. That old shadow
        // created the half-circle visible under every bubble on some phones.
        int ultra=lighten(base,.52f), light=lighten(base,.22f), mid=lighten(base,.025f), dark=darken(base,.64f);
        // Richer enamel body: keep the highlight compact so the base color remains visible.
        p.setShader(new RadialGradient(cx-r*.34f,cy-r*.42f,r*1.22f,
                new int[]{Color.rgb(246,250,255),ultra,light,mid,base,dark},
                new float[]{0f,.035f,.12f,.32f,.73f,1f},Shader.TileMode.CLAMP));
        c.drawCircle(cx,cy,r,p);p.setShader(null);
        // Subsurface lower glow keeps the bubble dimensional without a black crescent.
        p.setShader(new RadialGradient(cx+r*.08f,cy+r*.42f,r*.92f,
                new int[]{Color.argb(0,255,255,255),Color.argb(38,255,255,255),Color.argb(88,0,0,0)},
                new float[]{0f,.55f,1f},Shader.TileMode.CLAMP));
        c.drawCircle(cx,cy,r*.94f,p);p.setShader(null);
        // Strong glass reflections.
        p.setColor(Color.argb(205,255,255,255));
        c.drawOval(new RectF(cx-r*.61f,cy-r*.65f,cx-r*.13f,cy-r*.27f),p);
        p.setColor(Color.argb(112,255,255,255));
        c.drawOval(new RectF(cx+r*.00f,cy-r*.56f,cx+r*.24f,cy-r*.32f),p);
        p.setColor(Color.argb(55,255,255,255));
        c.drawArc(new RectF(cx-r*.80f,cy-r*.73f,cx+r*.80f,cy+r*.80f),30f,118f,false,p);
        // Clean outer glass rim and a subtle inner lower contour.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f,r*.075f));p.setColor(Color.argb(225,255,255,255));
        c.drawArc(new RectF(cx-r*.88f,cy-r*.88f,cx+r*.88f,cy+r*.88f),202f,112f,false,p);
        p.setStrokeWidth(Math.max(1.7f,r*.055f));p.setColor(dark);
        c.drawCircle(cx,cy,r,p);
        p.setStrokeWidth(Math.max(1.4f,r*.038f));p.setColor(Color.argb(165,255,255,255));
        c.drawArc(new RectF(cx-r*.77f,cy-r*.77f,cx+r*.77f,cy+r*.77f),42f,105f,false,p);
        p.setStrokeWidth(Math.max(1.2f,r*.032f));p.setColor(Color.argb(95,255,255,255));
        c.drawArc(new RectF(cx-r*.66f,cy-r*.66f,cx+r*.66f,cy+r*.66f),66f,74f,false,p);
        p.setStyle(Paint.Style.FILL);
        return b;
    }

    private void drawBubbleSprite(Canvas c,int colorIndex,float x,float y,float radius){
        int idx=Math.max(0,Math.min(PALETTE.length-1,colorIndex));
        int base=PALETTE[idx];
        Bitmap b=(bubbleSprites!=null&&idx<bubbleSprites.length)?bubbleSprites[idx]:null;
        if(b!=null&&!b.isRecycled()){
            // Pre-rendered glass shading is cached. Avoid per-bubble gradients, arcs,
            // sparkles and RectF allocations every frame to prevent garbage-collection stutter.
            float ss=radius*2.18f;
            bubbleDrawRect.set(x-ss*.5f,y-ss*.5f,x+ss*.5f,y+ss*.5f);
            c.drawBitmap(b,null,bubbleDrawRect,bubbleBitmapPaint);
        }else{
            paint.setShader(new RadialGradient(x-radius*.28f,y-radius*.32f,Math.max(1f,radius*1.42f),new int[]{Color.rgb(246,250,255),lighten(base,.18f),base,darken(base,.55f)},new float[]{0f,.045f,.68f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(x,y,radius,paint);paint.setShader(null);
            stroke.setStrokeWidth(Math.max(1.8f,radius*.075f));stroke.setColor(darken(base,.60f));c.drawCircle(x,y,radius,stroke);
        }
        if(idx==1){paint.setColor(Color.argb(190,255,255,255));c.drawCircle(x,y+radius*.22f,Math.max(2f,radius*.075f),paint);}
        else if(idx==2){drawStar(c,x,y+radius*.20f,radius*.105f,Color.argb(220,255,255,255));}
        else if(idx==5){Path mark=new Path();float mr=radius*.16f;mark.moveTo(x,y-mr);mark.lineTo(x+mr,y);mark.lineTo(x,y+mr);mark.lineTo(x-mr,y);mark.close();paint.setColor(Color.argb(220,255,255,255));c.drawPath(mark,paint);stroke.setStrokeWidth(Math.max(1.2f,radius*.04f));stroke.setColor(Color.argb(175,10,105,108));c.drawPath(mark,stroke);}
        else if(idx==7){stroke.setStrokeWidth(Math.max(1.3f,radius*.05f));stroke.setColor(Color.argb(205,122,148,190));c.drawCircle(x,y+radius*.18f,radius*.13f,stroke);}
    }

    private void drawBoardBubble(Canvas c,int value,float x,float y,float radius){
        int base=baseColorOf(value);
        float d=dist(x,y,impactX,impactY);
        float impactSquash=1f;
        if(impactTimer>0f && d<bubbleR*4.8f){
            float wave=Math.max(0f,1f-d/(bubbleR*4.8f));
            impactSquash += 0.026f*wave*(float)Math.sin((.46f-impactTimer)*34f);
        }
        float renderRadius=radius*impactSquash;
        drawBubbleSprite(c,base,x,y,renderRadius);
        float u=uiScale();
        radius=renderRadius;
        if(isChestBubbleValue(value)){
            float q=radius*.72f;RectF box=new RectF(x-q*.46f,y+q*.02f,x+q*.46f,y+q*.48f);
            roundedGradient(c,box,radius*.12f,Color.rgb(255,214,86),Color.rgb(214,120,29));
            stroke.setStrokeWidth(Math.max(1.4f,radius*.06f));stroke.setColor(Color.rgb(132,82,26));c.drawRoundRect(box,radius*.12f,radius*.12f,stroke);
            paint.setColor(Color.rgb(132,82,26));c.drawRect(x-q*.46f,y-q*.06f,x+q*.46f,y+q*.08f,paint);paint.setColor(Color.WHITE);c.drawCircle(x,y-q*.26f,radius*.15f,paint);
        } else if(isStarBubbleValue(value)){
            paint.setShader(new RadialGradient(x,y,radius*.95f,Color.argb(165,255,246,145),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x,y,radius*.95f,paint);paint.setShader(null);drawStar(c,x,y,radius*.34f,Color.rgb(255,230,88));
        } else if(isIceBubbleValue(value)){
            paint.setColor(Color.argb(92,220,247,255));c.drawCircle(x,y,radius*.91f,paint);stroke.setStrokeWidth(Math.max(2f,radius*.075f));stroke.setColor(Color.rgb(190,238,255));c.drawCircle(x,y,radius*.86f,stroke);
            stroke.setStrokeWidth(Math.max(1.4f,radius*.05f));stroke.setColor(Color.WHITE);for(int i=0;i<3;i++){float a=(float)(i*Math.PI/3);c.drawLine(x-(float)Math.cos(a)*radius*.48f,y-(float)Math.sin(a)*radius*.48f,x+(float)Math.cos(a)*radius*.48f,y+(float)Math.sin(a)*radius*.48f,stroke);}
        } else if(isStoneBubbleValue(value)){
            paint.setColor(Color.argb(215,89,93,112));c.drawCircle(x,y,radius*.84f,paint);stroke.setStrokeWidth(Math.max(2f,radius*.08f));stroke.setColor(Color.rgb(48,51,67));c.drawCircle(x,y,radius*.84f,stroke);
            stroke.setStrokeWidth(Math.max(1.5f,radius*.055f));stroke.setColor(Color.rgb(182,187,204));c.drawLine(x-radius*.34f,y-radius*.18f,x+radius*.24f,y+radius*.16f,stroke);c.drawLine(x-radius*.12f,y-radius*.42f,x+radius*.08f,y-radius*.03f,stroke);
        } else if(isChainBubbleValue(value)){
            stroke.setStrokeWidth(Math.max(3f,radius*.13f));stroke.setColor(Color.rgb(235,220,159));for(int i=-1;i<=1;i++)c.drawOval(new RectF(x+i*radius*.30f-radius*.18f,y-radius*.16f,x+i*radius*.30f+radius*.18f,y+radius*.16f),stroke);
        } else if(isCloudBubbleValue(value)){
            paint.setColor(Color.argb(205,231,239,250));c.drawCircle(x-radius*.23f,y,radius*.42f,paint);c.drawCircle(x+radius*.18f,y-radius*.10f,radius*.47f,paint);c.drawCircle(x+radius*.32f,y+radius*.12f,radius*.34f,paint);label(c,"?",x,y,18f*u,Color.rgb(73,86,139));
        } else if(isArmorBubbleValue(value)){
            paint.setShader(new RadialGradient(x-radius*.28f,y-radius*.30f,radius*.95f,Color.rgb(244,250,255),Color.rgb(93,112,151),Shader.TileMode.CLAMP));c.drawCircle(x,y,radius*.88f,paint);paint.setShader(null);
            stroke.setStrokeWidth(Math.max(3f,radius*.10f));stroke.setColor(Color.rgb(54,67,103));c.drawCircle(x,y,radius*.83f,stroke);
            stroke.setStrokeWidth(Math.max(1.5f,radius*.05f));stroke.setColor(Color.rgb(207,225,248));for(int i=0;i<6;i++){float a=i*1.0472f;c.drawLine(x+(float)Math.cos(a)*radius*.48f,y+(float)Math.sin(a)*radius*.48f,x+(float)Math.cos(a)*radius*.75f,y+(float)Math.sin(a)*radius*.75f,stroke);}label(c,"2",x,y,16f*u,Color.WHITE);
        } else if(isKeyBubbleValue(value)){
            paint.setColor(Color.rgb(255,221,72));c.drawCircle(x-radius*.12f,y-radius*.05f,radius*.22f,paint);stroke.setStrokeWidth(Math.max(3f,radius*.12f));stroke.setColor(Color.rgb(255,221,72));c.drawLine(x+radius*.05f,y+radius*.08f,x+radius*.45f,y+radius*.42f,stroke);c.drawLine(x+radius*.30f,y+radius*.26f,x+radius*.44f,y+radius*.13f,stroke);
        } else if(isMysteryBubbleValue(value)){
            paint.setShader(new RadialGradient(x,y,radius*.82f,Color.rgb(255,250,177),Color.rgb(170,84,238),Shader.TileMode.CLAMP));c.drawCircle(x,y,radius*.64f,paint);paint.setShader(null);labelOutline(c,"?",x,y,25f*u,Color.WHITE,Color.rgb(76,42,129));
        } else if(isLightningBubbleValue(value)){
            float pulse=.72f+.28f*(float)Math.sin(ambientTime*7f+x*.01f);
            paint.setShader(new RadialGradient(x,y,radius*.92f,Color.argb((int)(150+80*pulse),255,247,127),Color.argb(20,255,188,34),Shader.TileMode.CLAMP));c.drawCircle(x,y,radius*.82f,paint);paint.setShader(null);
            Path bolt=new Path();bolt.moveTo(x+radius*.08f,y-radius*.55f);bolt.lineTo(x-radius*.25f,y-radius*.02f);bolt.lineTo(x-radius*.02f,y-radius*.02f);bolt.lineTo(x-radius*.18f,y+radius*.52f);bolt.lineTo(x+radius*.34f,y-radius*.14f);bolt.lineTo(x+radius*.10f,y-radius*.14f);bolt.close();paint.setColor(Color.WHITE);c.drawPath(bolt,paint);
        } else if(isMagnetBubbleValue(value)){
            stroke.setStrokeWidth(Math.max(3f,radius*.12f));stroke.setColor(Color.WHITE);
            RectF arc=new RectF(x-radius*.45f,y-radius*.42f,x+radius*.45f,y+radius*.50f);c.drawArc(arc,25f,130f,false,stroke);
            paint.setColor(Color.rgb(255,95,110));c.drawRect(x-radius*.47f,y+radius*.18f,x-radius*.24f,y+radius*.48f,paint);paint.setColor(Color.rgb(89,191,255));c.drawRect(x+radius*.24f,y+radius*.18f,x+radius*.47f,y+radius*.48f,paint);
            addStaticGlow(c,x,y,radius,Color.rgb(110,226,255));
        } else if(isPaintBubbleValue(value)){
            for(int i=0;i<6;i++){float a=ambientTime*.45f+i*1.047f;float px=x+(float)Math.cos(a)*radius*.48f,py=y+(float)Math.sin(a)*radius*.48f;paint.setColor(PALETTE[(base+i)%PALETTE.length]);c.drawCircle(px,py,radius*.13f,paint);}
            paint.setColor(Color.WHITE);c.drawCircle(x,y,radius*.23f,paint);stroke.setStrokeWidth(Math.max(1.5f,radius*.05f));stroke.setColor(PALETTE[(base+3)%PALETTE.length]);c.drawLine(x-radius*.28f,y+radius*.35f,x+radius*.32f,y-radius*.36f,stroke);
        } else if(isBlackHoleBubbleValue(value)){
            paint.setShader(new RadialGradient(x,y,radius*.92f,new int[]{Color.rgb(10,8,25),Color.rgb(66,32,108),Color.rgb(174,83,245),Color.TRANSPARENT},new float[]{0f,.42f,.72f,1f},Shader.TileMode.CLAMP));c.drawCircle(x,y,radius*.92f,paint);paint.setShader(null);
            stroke.setStrokeWidth(Math.max(2f,radius*.065f));stroke.setColor(Color.argb(210,226,180,255));c.drawArc(new RectF(x-radius*.72f,y-radius*.45f,x+radius*.72f,y+radius*.45f),(ambientTime*75f)%360f,210f,false,stroke);
        } else if(isPortalBubbleValue(value)){
            float a=(ambientTime*90f)%360f;paint.setColor(Color.argb(120,24,18,70));c.drawCircle(x,y,radius*.56f,paint);
            stroke.setStrokeWidth(Math.max(3f,radius*.10f));stroke.setColor(Color.rgb(120,225,255));c.drawArc(new RectF(x-radius*.66f,y-radius*.66f,x+radius*.66f,y+radius*.66f),a,145f,false,stroke);
            stroke.setColor(Color.rgb(196,101,255));c.drawArc(new RectF(x-radius*.52f,y-radius*.52f,x+radius*.52f,y+radius*.52f),-a,170f,false,stroke);
            paint.setColor(Color.WHITE);c.drawCircle(x,y,radius*.11f,paint);
        } else if(isBabyBubbleValue(value)){
            paint.setColor(Color.rgb(255,238,209));c.drawCircle(x,y,radius*.45f,paint);paint.setColor(Color.rgb(84,63,73));c.drawCircle(x-radius*.15f,y-radius*.06f,radius*.045f,paint);c.drawCircle(x+radius*.15f,y-radius*.06f,radius*.045f,paint);stroke.setStrokeWidth(Math.max(1.5f,radius*.05f));stroke.setColor(Color.rgb(205,96,128));c.drawArc(new RectF(x-radius*.15f,y+radius*.04f,x+radius*.15f,y+radius*.24f),10f,160f,false,stroke);
        }
    }

    private void addStaticGlow(Canvas c,float x,float y,float r,int color){
        paint.setShader(new RadialGradient(x,y,r*1.08f,(color&0x00FFFFFF)|0x50000000,Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r*1.08f,paint);paint.setShader(null);
    }

    private void drawBombBubble(Canvas c,float x,float y,float r){
        paint.setShader(new RadialGradient(x-r*.35f,y-r*.4f,r*1.4f,new int[]{Color.rgb(110,116,145),Color.rgb(36,39,55),Color.rgb(7,8,14)},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);
        stroke.setStrokeWidth(2f);stroke.setColor(Color.argb(160,255,255,255));c.drawCircle(x,y,r,stroke);
        stroke.setStrokeWidth(r*.14f);stroke.setColor(Color.rgb(210,151,65));c.drawLine(x+r*.42f,y-r*.42f,x+r*.78f,y-r*.83f,stroke);
        paint.setColor(Color.rgb(255,92,46));c.drawCircle(x+r*.82f,y-r*.88f,r*.16f,paint);
        paint.setColor(Color.WHITE);c.drawCircle(x-r*.35f,y-r*.36f,r*.16f,paint);
    }

    private void drawRainbowBubble(Canvas c,float x,float y,float r){
        int bands=6;for(int i=bands;i>=1;i--){paint.setColor(PALETTE[(i+(int)(ambientTime*5))%PALETTE.length]);c.drawCircle(x,y,r*i/bands,paint);}paint.setColor(Color.argb(190,255,255,255));c.drawCircle(x-r*.33f,y-r*.37f,r*.18f,paint);stroke.setStrokeWidth(2f);stroke.setColor(Color.WHITE);c.drawCircle(x,y,r,stroke);
    }


    /** Small impact debris for every landed shot; settled pieces persist until level reset. */
    private void spawnShotImpactDebris(PointF p, int colorIndex) {
        float u = uiScale();
        int col = PALETTE[Math.max(0, Math.min(PALETTE.length - 1, baseColorOf(colorIndex)))];
        int[] shades = {darken(col, .18f), darken(col, .08f), lighten(col, .06f)};
        for (int i = 0; i < 8; i++) {
            float a = (float)(Math.PI * 2.0 * i / 8.0) + (random.nextFloat() - .5f) * .45f;
            float speed = 95f + random.nextFloat() * 155f;
            float size = (3.8f + random.nextFloat() * 5.2f) * u;
            glassShards.add(new GlassShard(
                    p.x + (random.nextFloat() - .5f) * bubbleR * .22f,
                    p.y + (random.nextFloat() - .5f) * bubbleR * .18f,
                    (float)Math.cos(a) * speed,
                    (float)Math.sin(a) * speed - 105f,
                    size * (.8f + random.nextFloat() * .5f),
                    size * (.75f + random.nextFloat() * .55f),
                    (random.nextFloat() - .5f) * 18f,
                    shades[random.nextInt(shades.length)], 2.0f, true));
        }
    }

    private void spawnPop(PointF p,int colorIndex,int count){
        int baseIdx=Math.max(0,Math.min(PALETTE.length-1,baseColorOf(colorIndex)));
        int col=PALETTE[baseIdx];
        int debrisCount=Math.min(64,14+count*4);
        int[] debrisCols={col,darken(col,.10f),lighten(col,.06f),darken(col,.18f)};
        float u=uiScale();
        for(int i=0;i<debrisCount;i++){
            float a=random.nextFloat()*6.2831855f;
            float sp=120f+random.nextFloat()*430f+(feverTimer>0f?90f:0f);
            float vx=(float)Math.cos(a)*sp;
            float vy=(float)Math.sin(a)*sp-105f-random.nextFloat()*125f;
            float sz=(6.0f+random.nextFloat()*13.5f)*u*(i%7==0?1.35f:1f);
            glassShards.add(new GlassShard(p.x+(random.nextFloat()-.5f)*bubbleR*.16f,p.y+(random.nextFloat()-.5f)*bubbleR*.16f,
                    vx,vy,sz*(.72f+random.nextFloat()*.70f),sz*(.58f+random.nextFloat()*.62f),
                    (random.nextFloat()-.5f)*26f,debrisCols[random.nextInt(debrisCols.length)],2.8f+random.nextFloat()*1.8f,true));
        }
        for(int i=0;i<Math.min(14,3+count*2);i++){
            float a=random.nextFloat()*6.2831855f,sp=80f+random.nextFloat()*300f;
            particles.add(new Particle(p.x,p.y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp-55f,
                    darken(col,.10f),1.6f+random.nextFloat()*3.8f,.28f+random.nextFloat()*.38f));
        }
        for(int i=0;i<Math.min(7,count+2);i++){
            float a=random.nextFloat()*6.2831855f,sp=110f+random.nextFloat()*250f;
            particles.add(new Particle(p.x,p.y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp-30f,
                    i%3==0?Color.WHITE:Color.rgb(255,220,118),1.2f+random.nextFloat()*2.3f,.16f+random.nextFloat()*.20f));
        }
    }

    // ---------------------------------------------------------------
    // Overlays
    // ---------------------------------------------------------------

    private void drawOverlay(Canvas c){
        paint.setColor(Color.argb(170,15,12,55));c.drawRect(0,0,getWidth(),getHeight(),paint);
        float w=getWidth(),h=getHeight(),u=uiScale();
        for(int i=0;i<12;i++){
            float ph=ambientTime*(.16f+i*.006f)+i*.73f;
            float x=((i*.091f)+ambientTime*.0026f*(1+i%3))%1.08f*w;
            float y=h*(.08f+((i*17)%82)/100f)+(float)Math.sin(ph)*8f*u;
            float tw=.45f+.55f*(float)Math.abs(Math.sin(ambientTime*2f+i));
            paint.setColor(Color.argb((int)(22+42*tw),255,255,255));c.drawCircle(x,y,(1.2f+(i%3)*.7f)*u,paint);
        }
        for(int i=0;i<5;i++){
            float x=w*(.08f+i*.22f)+(float)Math.sin(ambientTime*.10f+i)*9f*u;
            float y=h*(.18f+(i%3)*.26f);float r=w*(.018f+(i%2)*.008f);int col=PALETTE[(i+worldIndex(Math.max(1,selectedLevel)))%PALETTE.length];
            paint.setShader(new RadialGradient(x-r*.3f,y-r*.35f,r*1.35f,Color.argb(48,255,255,255),Color.argb(16,Color.red(col),Color.green(col),Color.blue(col)),Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);
        }
        switch(overlay){
            case SETTINGS:drawSettings(c);break;
            case HELP:drawHelp(c);break;
            case PRIVACY:drawPrivacy(c);break;
            case PAUSE:drawPause(c);break;
            case WIN:drawWin(c);break;
            case LOSE:drawLose(c);break;
            case EXIT_CONFIRM:drawExitConfirm(c);break;
            case RESET_CONFIRM:drawResetConfirm(c);break;
            case LEADERBOARD:drawLeaderboard(c);break;
            case SHOP:drawShop(c);break;
            case REWARD_OFFER:drawRewardOffer(c);break;
            default:break;
        }
    }

    private RectF panelRect() {
        float w=getWidth(),h=getHeight();return new RectF(w*.055f,h*.105f,w*.945f,h*.815f);
    }

    private void drawPanelHeader(Canvas c,RectF panel,String title) {
        drawPanelHeader(c,panel,title,true);
    }

    private void drawPanelHeader(Canvas c,RectF panel,String title,boolean showClose) {
        float u=uiScale();
        paint.setColor(Color.argb(242,236,246,255));c.drawRoundRect(panel,24f*u,24f*u,paint);
        stroke.setStrokeWidth(3f*u);stroke.setColor(Color.argb(230,174,211,255));c.drawRoundRect(panel,24f*u,24f*u,stroke);
        RectF header=new RectF(panel.left,panel.top,panel.right,panel.top+76f*u);
        roundedGradient(c,header,24f*u,Color.rgb(82,190,248),Color.rgb(43,99,218));
        paint.setColor(Color.rgb(43,99,218));c.drawRect(header.left,header.bottom-22f*u,header.right,header.bottom,paint);
        stroke.setStrokeWidth(1.6f*u);stroke.setColor(Color.argb(170,225,243,255));c.drawLine(header.left+12f*u,header.bottom,header.right-12f*u,header.bottom,stroke);
        labelOutline(c,title,panel.centerX(),panel.top+35f*u,31.5f*u,Color.WHITE,Color.rgb(37,78,170));
        if(showClose) iconCircle(c,panel.right-34f*u,panel.top+34f*u,24f*u,"×",Color.rgb(159,205,246),Color.rgb(74,112,184));
    }

    private void drawSettings(Canvas c) {
        RectF p=panelRect();float u=uiScale();drawPanelHeader(c,p,"SETTINGS");
        float y=p.top+124f*u;drawSettingRow(c,p,"SOUND FX","S",soundOn,y);y+=96f*u;drawSettingRow(c,p,"AIM GUIDE","◎",aimGuideOn,y);y+=96f*u;drawSettingRow(c,p,"HAPTICS","✦",hapticsOn,y);
        RectF privacy=new RectF(p.left+18f*u,p.bottom-150f*u,p.right-18f*u,p.bottom-94f*u);button(c,privacy,"PRIVACY POLICY",Color.rgb(79,174,242),Color.rgb(48,89,187));
        RectF reset=new RectF(p.left+18f*u,p.bottom-80f*u,p.right-18f*u,p.bottom-24f*u);button(c,reset,"RESET PROGRESS",Color.rgb(245,91,70),Color.rgb(177,47,64));
    }

    private void settingSquare(Canvas c,float x,float y,String glyph,boolean on,int col) {
        float u=uiScale(),sz=74f*u;RectF r=new RectF(x-sz/2,y-sz/2,x+sz/2,y+sz/2);paint.setColor(Color.argb(110,0,0,0));c.drawRoundRect(new RectF(r.left,r.top+7f*u,r.right,r.bottom+7f*u),15f*u,15f*u,paint);roundedGradient(c,r,15f*u,on?lighten(col,.22f):Color.rgb(174,181,205),on?darken(col,.12f):Color.rgb(116,126,159));paint.setColor(Color.argb(140,255,255,255));c.drawRoundRect(new RectF(r.left+3f*u,r.top+3f*u,r.right-3f*u,r.top+r.height()*.42f),12f*u,12f*u,paint);stroke.setStrokeWidth(2.6f*u);stroke.setColor(Color.WHITE);c.drawRoundRect(r,15f*u,15f*u,stroke);label(c,glyph,x,y,glyph.length()>2?18f*u:28f*u,Color.WHITE);
    }

    private void drawSettingRow(Canvas c, RectF p, String title, boolean on, float y) { drawSettingRow(c,p,title,"•",on,y); }

    private void drawSettingRow(Canvas c,RectF p,String title,String glyph,boolean on,float y) {
        float u=uiScale();RectF row=new RectF(p.left+12f*u,y-43f*u,p.right-12f*u,y+43f*u);
        paint.setColor(Color.argb(35,12,23,65));c.drawRoundRect(new RectF(row.left,row.top+3f*u,row.right,row.bottom+3f*u),17f*u,17f*u,paint);
        roundedGradient(c,row,17f*u,Color.rgb(240,247,255),Color.rgb(202,220,248));
        // No top-half white 3D slab. Keep only a thin contained rim.
        stroke.setStrokeWidth(1.5f*u);stroke.setColor(Color.argb(185,255,255,255));
        c.drawRoundRect(new RectF(row.left+2f*u,row.top+2f*u,row.right-2f*u,row.bottom-2f*u),15f*u,15f*u,stroke);
        iconCircle(c,row.left+40f*u,row.centerY(),30f*u,glyph,Color.rgb(93,199,255),Color.rgb(69,82,204));
        labelLeft(c,title,row.left+84f*u,row.centerY(),21.5f*u,Color.rgb(50,63,113));
        drawToggle(c,row.right-64f*u,row.centerY(),on);
    }

    private void drawToggle(Canvas c,float x,float y,boolean on) {
        float u=uiScale();
        RectF r=new RectF(x-52f*u,y-26f*u,x+52f*u,y+26f*u);
        // Higher-contrast switch: darker saturated track, crisp rim and outlined knob.
        paint.setColor(Color.argb(95,10,20,55));
        c.drawRoundRect(new RectF(r.left,r.top+4f*u,r.right,r.bottom+4f*u),23f*u,23f*u,paint);
        roundedGradient(c,r,22f*u,
                on?Color.rgb(48,210,126):Color.rgb(142,151,180),
                on?Color.rgb(6,126,75):Color.rgb(82,94,132));
        stroke.setStrokeWidth(2.1f*u);
        stroke.setColor(on?Color.rgb(207,255,231):Color.rgb(226,234,255));
        c.drawRoundRect(r,22f*u,22f*u,stroke);
        paint.setColor(Color.argb(48,255,255,255));
        c.drawRoundRect(new RectF(r.left+3f*u,r.top+3f*u,r.right-3f*u,r.top+r.height()*.40f),18f*u,18f*u,paint);
        float knobX=x+(on?27f:-27f)*u;
        paint.setColor(Color.argb(80,0,0,0));c.drawCircle(knobX, y+2.8f*u,20.5f*u,paint);
        paint.setColor(Color.WHITE);c.drawCircle(knobX,y,19.5f*u,paint);
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.rgb(63,78,139));c.drawCircle(knobX,y,19.5f*u,stroke);
        labelOutline(c,on?"ON":"OFF",x+(on?-13f:13f)*u,y,10.8f*u,Color.WHITE,Color.rgb(33,66,89));
    }

    private void drawHelp(Canvas c) {
        RectF p=panelRect();float u=uiScale();drawPanelHeader(c,p,"HOW TO PLAY");
        float x=p.left+55f*u,y=p.top+112f*u;float gap=70f*u;
        String[] tips={
                "Aim + release • bank shots reward precision",
                "Match 3+ • combos charge REALM FEVER",
                "Portals • wind • gravity bend the shot",
                "Lightning • Magnet • Paint • Black Hole",
                "Ice • armor • chains • clouds need smart clears",
                "Moving boards + energy bumpers change angles",
                "Objectives • Bosses • Survival • route forks"
        };
        for(int i=0;i<tips.length;i++){
            RectF row=new RectF(p.left+18f*u,y-30f*u,p.right-18f*u,y+30f*u);
            paint.setColor(Color.argb(235,229,239,255));c.drawRoundRect(row,16f*u,16f*u,paint);
            roundedGradient(c,row,16f*u,Color.rgb(249,252,255),Color.rgb(216,230,252));
            stroke.setStrokeWidth(1.6f*u);stroke.setColor(Color.rgb(195,216,246));c.drawRoundRect(row,16f*u,16f*u,stroke);
            if(i==0)drawBubbleSprite(c,1,x,y,22f*u);
            else if(i==1){drawBubbleSprite(c,0,x-7f*u,y,14f*u);drawBubbleSprite(c,0,x+8f*u,y,14f*u);drawBubbleSprite(c,0,x,y-13f*u,14f*u);}
            else if(i==2)drawBoardBubble(c,makeSpecialBubble(SPECIAL_PORTAL,1),x,y,21f*u);
            else if(i==3)drawBoardBubble(c,makeSpecialBubble(SPECIAL_LIGHTNING,2),x,y,21f*u);
            else if(i==4)drawBoardBubble(c,makeSpecialBubble(SPECIAL_ARMOR,1),x,y,21f*u);
            else if(i==5)iconCircle(c,x,y,21f*u,"↔",Color.rgb(255,184,71),Color.rgb(216,70,96));
            else iconCircle(c,x,y,21f*u,"∞",Color.rgb(82,232,186),Color.rgb(34,99,184));
            labelLeft(c,tips[i],x+48f*u,y,16.9f*u,Color.rgb(42,54,103));
            y+=gap;
        }
    }

    private String appVersionName() {
        try {
            android.content.pm.PackageInfo info=getContext().getPackageManager()
                    .getPackageInfo(getContext().getPackageName(),0);
            return info.versionName==null?"5.5.26":info.versionName;
        } catch (Throwable ignored) {
            return "5.0.6";
        }
    }

    private void drawPrivacy(Canvas c) {
        RectF p=panelRect();float u=uiScale();drawPanelHeader(c,p,"PRIVACY POLICY");
        float x=p.left+26f*u,y=p.top+103f*u;
        labelLeft(c,"Bubble Realm Adventure • v"+appVersionName(),x,y,16.2f*u,Color.rgb(55,69,118));y+=42f*u;
        String[] lines={
                "• Developer: Memon Digital Studio • no account required.",
                "• Progress/settings/coins stay local; Android app backup is off.",
                "• Local data stays until Reset, clear app data, or uninstall.",
                "• Purchases use Google Play Billing; card details are not stored.",
                "• Ads use Google Mobile Ads (AdMob).",
                "• UMP handles ad privacy choices where required.",
                "• Google/AdMob may process ad, device and service data.",
                "• Privacy/support: developer contact on Google Play."
        };
        for(String line:lines){
            RectF row=new RectF(p.left+16f*u,y-24f*u,p.right-16f*u,y+24f*u);
            roundedGradient(c,row,12f*u,Color.rgb(248,252,255),Color.rgb(222,235,253));
            stroke.setStrokeWidth(1.2f*u);stroke.setColor(Color.rgb(198,218,245));c.drawRoundRect(row,12f*u,12f*u,stroke);
            labelLeft(c,line,x,y,13.6f*u,Color.rgb(54,66,111));y+=57f*u;
        }
        MainActivity hs=host();
        if(hs!=null && hs.isAdPrivacyOptionsRequired()){
            RectF adPrivacy=new RectF(p.left+28f*u,p.bottom-92f*u,p.right-28f*u,p.bottom-42f*u);
            button(c,adPrivacy,"AD PRIVACY OPTIONS",Color.rgb(129,95,226),Color.rgb(65,65,174));
        }
        label(c,"Developer contact and full policy URL are available on Google Play.",p.centerX(),p.bottom-18f*u,11.8f*u,Color.rgb(72,82,126));
    }

    private void drawLeaderboard(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.06f,h*.08f,w*.94f,h*.88f);
        drawPanelHeader(c,p,"SCOREBOARDS");
        label(c,"LOCAL HALL OF FAME",p.centerX(),p.top+108f*u,21f*u,Color.rgb(67,76,126));
        RectF bestCard=new RectF(p.left+14f*u,p.top+140f*u,p.right-14f*u,p.top+226f*u);
        paint.setColor(Color.rgb(83,76,202));c.drawRoundRect(bestCard,18f*u,18f*u,paint);
        roundedGradient(c,bestCard,18f*u,Color.rgb(128,103,241),Color.rgb(61,63,177));
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.argb(210,220,218,255));c.drawRoundRect(bestCard,18f*u,18f*u,stroke);
        drawStar(c,bestCard.left+30f*u,bestCard.centerY(),18f*u,Color.rgb(255,214,73));
        labelLeft(c,"BEST SCORE",bestCard.left+62f*u,bestCard.centerY(),20.5f*u,Color.WHITE);
        label(c,String.valueOf(globalBestScore()),bestCard.right-72f*u,bestCard.centerY(),31f*u,Color.WHITE);

        int[][] top=localTopScores(6);
        float y=p.top+252f*u;
        if(top.length==0){label(c,"Complete a level to create your first score!",p.centerX(),y+38f*u,15.5f*u,Color.rgb(91,100,143));}
        for(int i=0;i<top.length;i++){
            RectF row=new RectF(p.left+14f*u,y+i*68f*u,p.right-14f*u,y+58f*u+i*68f*u);
            paint.setColor(i==0?Color.rgb(224,235,255):Color.rgb(236,243,255));c.drawRoundRect(row,14f*u,14f*u,paint);
            drawStar(c,row.left+28f*u,row.centerY(),i==0?16f*u:13f*u,i==0?Color.rgb(255,203,42):Color.rgb(116,145,213));
            labelLeft(c,"#"+(i+1)+"   LEVEL "+top[i][0],row.left+58f*u,row.centerY(),18f*u,Color.rgb(57,69,117));
            label(c,String.valueOf(top[i][1]),row.right-62f*u,row.centerY(),21f*u,Color.rgb(50,61,111));
        }

        RectF local=new RectF(p.left+18f*u,p.bottom-76f*u,p.right-18f*u,p.bottom-20f*u);
        roundedGradient(c,local,15f*u,Color.rgb(96,153,232),Color.rgb(62,92,183));
        label(c,"OFFLINE SCOREBOARD • STORED ON THIS DEVICE",local.centerX(),local.centerY(),13.2f*u,Color.WHITE);
    }

    private void showRewardOffer(int type){
        if(overlay!=Overlay.NONE)return;
        rewardOfferType=Math.max(1,Math.min(3,type));
        aiming=false;toolMenuOpen=false;overlay=Overlay.REWARD_OFFER;
        clickFx();invalidate();
    }

    private void drawRewardOffer(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.075f,h*.22f,w*.925f,h*.72f);
        drawPanelHeader(c,p,rewardOfferType==1?"NO MOVES LEFT":(rewardOfferType==2?"BOMB EMPTY":"WILD EMPTY"),false);
        String title=rewardOfferType==1?"WATCH AN AD • +5 MOVES":(rewardOfferType==2?"WATCH AN AD • +1 BOMB":"WATCH AN AD • +1 WILD");
        String sub=rewardOfferType==1?"Keep this level going without spending coins.":"Watch one rewarded ad or buy this booster with coins.";
        labelOutline(c,title,p.centerX(),p.top+165f*u,38f*u,Color.WHITE,Color.rgb(48,64,150));
        label(c,sub,p.centerX(),p.top+215f*u,23f*u,Color.rgb(72,82,125));
        RectF watch=new RectF(p.left+28f*u,p.top+270f*u,p.right-28f*u,p.top+338f*u);
        button(c,watch,"WATCH AD",Color.rgb(178,94,244),Color.rgb(92,51,188));
        if(rewardOfferType==2 || rewardOfferType==3){
            int cost=rewardOfferType==2?BOMB_COST:WILD_COST;
            RectF buy=new RectF(p.left+28f*u,p.top+348f*u,p.right-28f*u,p.top+412f*u);
            button(c,buy,"BUY WITH COINS • "+cost,Color.rgb(255,190,63),Color.rgb(203,102,22));
            label(c,"YOUR COINS: "+coins,p.centerX(),p.top+439f*u,20f*u,Color.rgb(77,87,132));
        }else{
            label(c,"Watch a rewarded ad to continue.",p.centerX(),p.top+382f*u,14.5f*u,Color.rgb(103,108,150));
        }
        label(c,"NOT NOW",p.centerX(),p.bottom-26f*u,18f*u,Color.rgb(86,94,136));
    }

    private void drawShop(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.05f,h*.07f,w*.95f,h*.91f);
        drawPanelHeader(c,p,"COIN SHOP");
        RectF balance=new RectF(p.left+18f*u,p.top+92f*u,p.right-18f*u,p.top+150f*u);
        paint.setColor(Color.rgb(58,65,166));c.drawRoundRect(balance,18f*u,18f*u,paint);
        roundedGradient(c,balance,18f*u,Color.rgb(96,103,222),Color.rgb(47,54,145));
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.argb(205,219,226,255));c.drawRoundRect(balance,18f*u,18f*u,stroke);
        drawStar(c,balance.left+24f*u,balance.centerY(),12f*u,Color.rgb(255,216,70));
        labelLeft(c,"YOUR COINS",balance.left+48f*u,balance.centerY(),16.5f*u,Color.WHITE);
        label(c,String.valueOf(coins),balance.right-60f*u,balance.centerY(),25f*u,Color.rgb(255,229,88));

        float mid=p.centerX();
        RectF daily=new RectF(p.left+18f*u,p.top+168f*u,mid-7f*u,p.top+228f*u);
        RectF rewardAd=new RectF(mid+7f*u,p.top+168f*u,p.right-18f*u,p.top+228f*u);
        button(c,daily,isDailyGiftClaimed()?"DAILY ✓":"DAILY +"+DAILY_COIN_REWARD,Color.rgb(72,188,255),Color.rgb(47,82,205));
        button(c,rewardAd,"WATCH AD +7",Color.rgb(178,94,244),Color.rgb(92,51,188));
        label(c,"OPTIONAL COIN PACKS • LOCAL PRICE FROM GOOGLE PLAY",p.centerX(),p.top+251f*u,11.7f*u,Color.rgb(83,92,137));
        label(c,"BOOSTERS • BOMB "+BOMB_COST+" • WILD "+WILD_COST+" COINS",p.centerX(),p.top+272f*u,11.8f*u,Color.rgb(83,92,137));

        float sy=p.top+288f*u;float gap=14f*u;float cardW=(p.width()-42f*u)/2f;float cardH=142f*u;
        shopPackCard(c,new RectF(p.left+14f*u,sy,p.left+14f*u+cardW,sy+cardH),BillingManager.COINS_500,"500 COINS");
        shopPackCard(c,new RectF(p.left+28f*u+cardW,sy,p.right-14f*u,sy+cardH),BillingManager.COINS_1200,"1,200 COINS");
        sy+=cardH+gap;
        shopPackCard(c,new RectF(p.left+14f*u,sy,p.left+14f*u+cardW,sy+cardH),BillingManager.COINS_2500,"2,500 COINS");
        shopPackCard(c,new RectF(p.left+28f*u+cardW,sy,p.right-14f*u,sy+cardH),BillingManager.COINS_1800,"1,800 COINS");
    }

    private void shopPackCard(Canvas c,RectF r,String productId,String title){
        float u=uiScale();
        paint.setColor(Color.argb(28,8,15,60));c.drawRoundRect(new RectF(r.left,r.top+3f*u,r.right,r.bottom+3f*u),17f*u,17f*u,paint);
        paint.setColor(Color.rgb(221,233,255));c.drawRoundRect(r,17f*u,17f*u,paint);
        roundedGradient(c,r,17f*u,Color.rgb(241,247,255),Color.rgb(204,220,250));
        stroke.setStrokeWidth(1.6f*u);stroke.setColor(Color.argb(215,255,255,255));c.drawRoundRect(new RectF(r.left+1.5f*u,r.top+1.5f*u,r.right-1.5f*u,r.bottom-1.5f*u),15.5f*u,15.5f*u,stroke);
        paint.setShader(new RadialGradient(r.centerX(),r.top+42f*u,32f*u,new int[]{Color.WHITE,Color.rgb(255,217,55),Color.rgb(207,128,12)},null,Shader.TileMode.CLAMP));c.drawCircle(r.centerX(),r.top+41f*u,27f*u,paint);paint.setShader(null);
        float tw=.5f+.5f*(float)Math.sin(ambientTime*3.2f+r.centerX()*.02f);paint.setColor(Color.argb((int)(95+120*tw),255,255,255));c.drawCircle(r.centerX()-8f*u,r.top+27f*u,(1.6f+1.4f*tw)*u,paint);
        label(c,title,r.centerX(),r.top+91f*u,17f*u,Color.rgb(55,68,117));
        MainActivity hs=host();String price=hs==null?"UNAVAILABLE":hs.getCoinPackPrice(productId);
        int pc=price.equals("UNAVAILABLE")?Color.rgb(145,151,174):Color.rgb(103,66,177);
        label(c,price,r.centerX(),r.top+121f*u,price.length()>11?15f*u:20f*u,pc);
    }

    private void drawPause(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.055f,h*.14f,w*.945f,h*.84f);
        drawPanelHeader(c,p,"GAME PAUSED");
        label(c,"LEVEL "+selectedLevel+"   •   SCORE "+levelScore,p.centerX(),p.top+91f*u,16f*u,Color.rgb(64,76,126));

        RectF cont=new RectF(p.left+20f*u,p.top+118f*u,p.right-20f*u,p.top+184f*u);
        RectF fresh=new RectF(p.left+20f*u,p.top+202f*u,p.right-20f*u,p.top+268f*u);
        RectF settings=new RectF(p.left+20f*u,p.top+286f*u,p.right-20f*u,p.top+352f*u);
        RectF map=new RectF(p.left+20f*u,p.bottom-88f*u,p.right-20f*u,p.bottom-24f*u);
        pauseActionButton(c,cont,"▶","CONTINUE",Color.rgb(62,229,121),Color.rgb(0,154,81));
        pauseActionButton(c,fresh,"↻","NEW GAME",Color.rgb(255,178,62),Color.rgb(232,82,60));
        pauseActionButton(c,settings,"⚙","SETTINGS",Color.rgb(170,111,246),Color.rgb(91,51,181));
        String backLabel=gameMode==GameMode.SURVIVAL?"BACK TO HOME":gameMode==GameMode.TREASURE_ROOM?"LEAVE TREASURE ROOM":"SAVE & BACK TO MAP";
        pauseActionButton(c,map,"⌂",backLabel,Color.rgb(67,176,255),Color.rgb(44,78,190));
    }

    private void pauseActionButton(Canvas c,RectF r,String glyph,String title,int top,int bottom) {
        // Pause buttons now use the exact same premium button treatment as Home:
        // contained glass highlight, animated edge shine and soft external glow.
        button(c,r,"",top,bottom);
        float u=uiScale();
        float ix=r.left+42f*u;
        iconCircle(c,ix,r.centerY(),24f*u,glyph,lighten(top,.12f),darken(bottom,.10f));
        labelLeft(c,title,r.left+79f*u,r.centerY(),19f*u,Color.WHITE);
    }

    private void drawExitConfirm(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.10f,h*.31f,w*.90f,h*.64f);
        card(c,p,26f*u,Color.rgb(240,246,255));
        RectF head=new RectF(p.left,p.top,p.right,p.top+74f*u);roundedGradient(c,head,26f*u,Color.rgb(67,188,255),Color.rgb(47,82,205));
        paint.setColor(Color.rgb(240,246,255));c.drawRect(p.left,p.top+52f*u,p.right,p.top+76f*u,paint);
        label(c,"EXIT GAME?",p.centerX(),p.top+34f*u,27f*u,Color.WHITE);
        label(c,"Do you want to close Bubble Realm Adventure?",p.centerX(),p.top+112f*u,16f*u,Color.rgb(61,73,122));
        RectF no=new RectF(p.left+20f*u,p.bottom-86f*u,p.centerX()-8f*u,p.bottom-26f*u);
        RectF yes=new RectF(p.centerX()+8f*u,p.bottom-86f*u,p.right-20f*u,p.bottom-26f*u);
        button(c,no,"NO",Color.rgb(73,188,255),Color.rgb(45,85,205));
        button(c,yes,"YES, EXIT",Color.rgb(255,141,72),Color.rgb(226,62,62));
    }

    private void drawResetConfirm(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        RectF p=new RectF(w*.085f,h*.28f,w*.915f,h*.67f);
        drawPanelHeader(c,p,"RESET GAME?");
        label(c,"All level progress will be erased",p.centerX(),p.top+116f*u,17f*u,Color.rgb(63,74,121));
        label(c,"Coins, stars, boosters and scores reset too",p.centerX(),p.top+158f*u,13.5f*u,Color.rgb(93,102,145));
        RectF no=new RectF(p.left+20f*u,p.bottom-92f*u,p.centerX()-8f*u,p.bottom-28f*u);
        RectF yes=new RectF(p.centerX()+8f*u,p.bottom-92f*u,p.right-20f*u,p.bottom-28f*u);
        button(c,no,"CANCEL",Color.rgb(77,190,255),Color.rgb(45,86,204));
        button(c,yes,"RESET",Color.rgb(255,145,78),Color.rgb(213,58,72));
    }

    private void resetGameProgress(){
        SharedPreferences.Editor reset=prefs.edit().clear();
        reset.putBoolean("sound",soundOn).putBoolean("music",musicOn)
                .putBoolean("aimGuide",aimGuideOn).putBoolean("haptics",hapticsOn)
                .putInt("coins",STARTING_COINS).putInt("maxUnlocked",1).putInt("totalStars",0).putInt("relic_count",0)
                .putInt("bomb_inventory",STARTING_BOMBS).putInt("wild_inventory",STARTING_WILDS)
                .putBoolean("starter_boosters_v28",true)
                .putBoolean("starter_boosters_v2112_one_each",true);
        reset.commit();
        coins=STARTING_COINS;maxUnlocked=1;selectedLevel=1;totalStars=0;relicCount=0;
        bombCount=STARTING_BOMBS;rainbowCount=STARTING_WILDS;
        currentColor=0;nextColor=1;levelScore=0;clearedBubbles=0;
        grid.clear();particles.clear();glassShards.clear();debrisFloorY=-1f;falling.clear();floatingTexts.clear();rings.clear();
        praiseBannerText=null;praiseBannerTimer=0f;toolMenuOpen=false;winCelebrationTimer=0f;
        clearSavedGame();
        screen=Screen.HOME;overlay=Overlay.NONE;audio.setMusicTheme(12);
        audio.play(AudioEngine.FX_LEVEL_UP_CHIME,.85f,.90f);haptic(60);
    }

    private void exitApp() {
        Context ctx=getContext();
        if(ctx instanceof Activity)((Activity)ctx).finish();
    }

    private float clamp01(float v){return Math.max(0f,Math.min(1f,v));}
    private float easeOutCubic(float x){x=clamp01(x);float q=1f-x;return 1f-q*q*q;}

    private float easeOutBack(float t){
        t=clamp01(t);
        float c1=1.70158f,c3=c1+1f;
        float q=t-1f;
        return 1f+c3*q*q*q+c1*q*q;
    }

    private void drawWinStarCinematic(Canvas c,float sx,float sy,int index,boolean earned,float u){
        if(!earned){
            drawStar(c,sx,sy,29f*u,Color.rgb(188,197,219));
            stroke.setStrokeWidth(1.4f*u);stroke.setColor(Color.argb(95,255,255,255));
            c.drawCircle(sx,sy,36f*u,stroke);
            return;
        }

        float delay=.16f+index*.26f;
        float local=winCelebrationTimer-delay;
        if(local<=0f){
            drawStar(c,sx,sy,29f*u,Color.rgb(188,197,219));
            return;
        }

        float travel=clamp01(local/.48f);
        float eased=easeOutBack(travel);
        float startX=index==0?sx-160f*u:(index==1?sx:sx+160f*u);
        float startY=index==1?sy-165f*u:sy-100f*u;
        float arc=(float)Math.sin(travel*Math.PI)*(-54f*u);
        float x=startX+(sx-startX)*eased;
        float y=startY+(sy-startY)*eased+arc;

        // Comet trail during flight.
        if(travel<1f){
            for(int j=1;j<=6;j++){
                float tt=Math.max(0f,travel-j*.055f);
                float ee=easeOutBack(tt);
                float tx=startX+(sx-startX)*ee;
                float ty=startY+(sy-startY)*ee+(float)Math.sin(tt*Math.PI)*(-54f*u);
                int a=(int)(150*(1f-j/7f)*(1f-travel*.35f));
                paint.setColor(Color.argb(Math.max(0,a),255,232,105));
                c.drawCircle(tx,ty,(7f-j*.65f)*u,paint);
            }
        }

        float rot=(1f-travel)*(index==1?540f:(index==0?-720f:720f));
        float scale=.55f+.47f*eased;
        if(local>.48f){
            float settle=clamp01((local-.48f)/.38f);
            scale=1f+.15f*(1f-settle)*(float)Math.sin(settle*Math.PI*3f);
            x=sx;y=sy;rot=0f;
        }

        // Glow + expanding halo.
        float haloPulse=.5f+.5f*(float)Math.sin(ambientTime*7f+index);
        paint.setShader(new RadialGradient(sx,sy,(48f+7f*haloPulse)*u,
                Color.argb(100,255,221,72),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(sx,sy,(48f+7f*haloPulse)*u,paint);paint.setShader(null);

        c.save();
        c.rotate(rot,x,y);
        c.scale(scale,scale,x,y);
        drawStar(c,x,y,(index==1?38f:34f)*u,Color.rgb(255,205,33));
        c.restore();

        // Arrival burst.
        float burst=local-.42f;
        if(burst>0f && burst<.52f){
            float bp=clamp01(burst/.52f);
            stroke.setStrokeWidth((3.4f*(1f-bp)+.8f)*u);
            stroke.setColor(Color.argb((int)(205*(1f-bp)),255,240,130));
            c.drawCircle(sx,sy,(35f+58f*bp)*u,stroke);
            for(int k=0;k<10;k++){
                float a=k*.628f+index*.32f;
                float rr=(32f+62f*bp)*u;
                float px=sx+(float)Math.cos(a)*rr;
                float py=sy+(float)Math.sin(a)*rr;
                paint.setColor(Color.argb((int)(230*(1f-bp)),255,255,255));
                c.drawCircle(px,py,(3.5f*(1f-bp)+1.2f)*u,paint);
            }
        }

        // Settled slow sparkle orbit.
        if(local>.65f){
            for(int k=0;k<4;k++){
                float a=ambientTime*(1.5f+k*.12f)+k*1.57f+index;
                float rr=(42f+k*2f)*u;
                paint.setColor(Color.argb(115,255,255,255));
                c.drawCircle(sx+(float)Math.cos(a)*rr,sy+(float)Math.sin(a)*rr,1.7f*u,paint);
            }
        }
    }

    private void drawLevelUpBanner(Canvas c,RectF p,float u){
        if(!lastLevelWasUnlock)return;
        float local=winCelebrationTimer-1.00f;
        if(local<=0f)return;
        float show=clamp01(local/.38f);
        float scale=.60f+.42f*easeOutBack(show);
        float alpha=Math.min(1f,local/.18f);
        float y=p.top+118f*u;
        float half=124f*u*scale;

        paint.setShader(new RadialGradient(p.centerX(),y,160f*u,
                new int[]{
                        Color.argb((int)(105*alpha),121,230,255),
                        Color.argb((int)(30*alpha),180,90,255),
                        Color.TRANSPARENT
                },
                new float[]{0f,.55f,1f},
                Shader.TileMode.CLAMP));
        c.drawCircle(p.centerX(),y,160f*u,paint);paint.setShader(null);
        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.argb((int)(150*alpha),110,235,255));
        c.save();c.rotate(ambientTime*55f,p.centerX(),y);c.drawArc(new RectF(p.centerX()-150f*u,y-150f*u,p.centerX()+150f*u,y+150f*u),-25f,70f,false,stroke);c.drawArc(new RectF(p.centerX()-130f*u,y-130f*u,p.centerX()+130f*u,y+130f*u),150f,65f,false,stroke);c.restore();

        RectF badge=new RectF(p.centerX()-half,y-24f*u*scale,p.centerX()+half,y+24f*u*scale);
        roundedGradient(c,badge,22f*u*scale,Color.rgb(70,211,255),Color.rgb(117,77,228));
        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.argb((int)(235*alpha),255,255,255));
        c.drawRoundRect(badge,22f*u*scale,22f*u*scale,stroke);
        paint.setColor(Color.argb((int)(95*alpha),255,255,255));
        c.drawRoundRect(new RectF(badge.left+5f*u,badge.top+4f*u,badge.right-5f*u,badge.centerY()),18f*u,18f*u,paint);
        label(c,"LEVEL UP!",p.centerX(),y,20f*u*scale,Color.WHITE);
    }

    private void drawWinClapConfetti(Canvas c, RectF area, float u){
        float local=Math.max(0f,winCelebrationTimer-.04f);
        float pulse=.84f+.16f*(float)Math.sin(ambientTime*8.2f);
        float cy=area.centerY()+8f*u;

        paint.setShader(new RadialGradient(area.centerX(),cy,170f*u,
                Color.argb(92,255,236,140),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(area.centerX(),cy,170f*u,paint);paint.setShader(null);

        // Big applause rings across the screen.
        for(int ring=0; ring<4; ring++){
            float rr=(70f+ring*42f)*u + (local*(44f+ring*12f)*u)%(78f*u);
            stroke.setStrokeWidth((5.2f-ring*.9f)*u);
            stroke.setColor(Color.argb(120-ring*18,255,227,102));
            c.drawCircle(area.centerX(),cy,rr,stroke);
        }

        // Strong confetti shower over almost the whole screen.
        int[][] confettiCols=new int[][]{{255,221,83},{93,226,255},{255,112,172},{118,241,129},{255,149,81},{186,132,255}};
        for(int i=0;i<68;i++){
            float sx=area.left+16f*u+((i*23)%100)/100f*(area.width()-32f*u);
            float yy=area.top+32f*u+((local*(132f+(i%6)*16f)*u)+(i*17f*u))%(area.height()-76f*u);
            float rx=(float)Math.sin(ambientTime*2.2f+i*.61f)*10f*u;
            int[] cc=confettiCols[i%confettiCols.length];
            stroke.setStrokeWidth((3.0f+(i%3)) * u);
            stroke.setColor(Color.argb(235,cc[0],cc[1],cc[2]));
            c.drawLine(sx-rx,yy-5f*u,sx+rx,yy+5f*u,stroke);
            paint.setColor(Color.argb(205,255,255,255));
            c.drawCircle(sx+rx*.55f,yy-7f*u,1.7f*u,paint);
        }

        // Larger clap hands and flash lines.
        int skin=Color.rgb(255,215,150),skinDark=Color.rgb(230,182,110);
        for(int side=-1;side<=1;side+=2){
            float cx=area.centerX()+side*92f*u;
            float cp=1f+.08f*(float)Math.sin(ambientTime*9f+side);
            RectF palm=new RectF(cx-24f*u*cp,cy-38f*u*cp,cx+22f*u*cp,cy+34f*u*cp);
            paint.setColor(skinDark);c.drawRoundRect(new RectF(palm.left,palm.top+4f*u,palm.right,palm.bottom+4f*u),13f*u,13f*u,paint);
            paint.setColor(skin);c.drawRoundRect(palm,13f*u,13f*u,paint);
            for(int f=0;f<4;f++){
                float fy=palm.top+6f*u+f*13f*u;
                float fl=side<0?cx-36f*u:cx+10f*u;
                float fr=side<0?cx-10f*u:cx+36f*u;
                paint.setColor(skin);c.drawRoundRect(new RectF(fl,fy,fr,fy+10f*u),4.6f*u,4.6f*u,paint);
            }
            stroke.setStrokeWidth(3.2f*u);
            stroke.setColor(Color.argb(230,255,232,98));
            for(int k=0;k<4;k++){
                float lx=cx+side*(34f+k*11f)*u;
                c.drawLine(lx,cy-24f*u+k*15f*u,lx+side*17f*u,cy-37f*u+k*15f*u,stroke);
            }
        }

        label(c,"CLAP!",area.centerX(),cy+95f*u*pulse,20f*u*pulse,Color.rgb(255,245,185));
    }

    private void drawWinFireworksBurst(Canvas c, RectF area, float u){
        float local=Math.max(0f,winCelebrationTimer-.02f);
        float[][] centers=new float[][]{
                {area.width()*.18f,area.height()*.20f},
                {area.width()*.50f,area.height()*.14f},
                {area.width()*.82f,area.height()*.22f},
                {area.width()*.28f,area.height()*.72f},
                {area.width()*.72f,area.height()*.68f}
        };
        int[] cols=new int[]{Color.rgb(255,224,86),Color.rgb(102,223,255),Color.rgb(255,111,165),Color.rgb(180,132,255),Color.rgb(112,244,146)};
        for(int ci=0;ci<centers.length;ci++){
            float cx=centers[ci][0],cy=centers[ci][1];
            int col=cols[ci%cols.length];
            paint.setShader(new RadialGradient(cx,cy,84f*u,Color.argb(86,Color.red(col),Color.green(col),Color.blue(col)),Color.TRANSPARENT,Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,84f*u,paint);paint.setShader(null);
            float radius=(34f+((local*(150f+(ci%3)*20f)*u)+ci*22f*u)%(95f*u));
            for(int i=0;i<18;i++){
                float a=(float)(Math.PI*2*i/18f+ci*.24f+ambientTime*.045f);
                float x=cx+(float)Math.cos(a)*radius;
                float y=cy+(float)Math.sin(a)*radius;
                stroke.setStrokeWidth(3.2f*u);
                stroke.setColor(cols[(ci+i)%cols.length]);
                c.drawLine(cx,cy,x,y,stroke);
                paint.setColor(Color.WHITE);c.drawCircle(x,y,3.4f*u,paint);
                paint.setColor(Color.argb(170,255,255,255));c.drawCircle(x,y,1.5f*u,paint);
            }
            for(int s=0;s<8;s++){
                float a=(float)(Math.PI*2*s/8f-local*.9f+ci);
                float rr=radius*.46f;
                float x=cx+(float)Math.cos(a)*rr;
                float y=cy+(float)Math.sin(a)*rr;
                drawStar(c,x,y,4.5f*u,Color.rgb(255,240,160));
            }
        }
    }

    private void drawWinStarRain(Canvas c, RectF area, float u){
        float local=Math.max(0f,winCelebrationTimer-.02f);
        // Shiny top aura.
        for(int i=0;i<3;i++){
            stroke.setStrokeWidth((10f-i*2f)*u);
            stroke.setColor(Color.argb(34-i*6,255,245,190));
            c.drawArc(new RectF(area.width()*.15f,area.top+(12f+i*12f)*u,area.width()*.85f,area.top+(160f+i*20f)*u),200f,140f,false,stroke);
        }
        for(int i=0;i<36;i++){
            float sx=area.left+18f*u+((i*29)%100)/100f*(area.width()-36f*u);
            float dropSpan=Math.max(80f*u,area.height()-42f*u);
            float yy=area.top+10f*u+((local*(136f+(i%5)*18f)*u)+(i*28f*u))%dropSpan;
            float tw=.78f+.22f*(float)Math.sin(ambientTime*3.8f+i*.55f);
            float rr=(7.8f+(i%4)*2.3f)*u*tw;
            paint.setShader(new RadialGradient(sx,yy,rr*3.0f,Color.argb(70,255,238,155),Color.TRANSPARENT,Shader.TileMode.CLAMP));
            c.drawCircle(sx,yy,rr*3.0f,paint);paint.setShader(null);
            drawStar(c,sx,yy,rr,Color.rgb(255,221,78));
            stroke.setStrokeWidth(1.7f*u);
            stroke.setColor(Color.argb(150,255,255,255));
            c.drawLine(sx,yy-16f*u,sx,yy-30f*u,stroke);
            paint.setColor(Color.argb(210,255,255,255));
            c.drawCircle(sx,yy-18f*u,1.6f*u,paint);
        }
        // bottom sparkles
        for(int i=0;i<14;i++){
            float x=area.left+30f*u+i*(area.width()-60f*u)/13f;
            float y=area.bottom-54f*u+(float)Math.sin(ambientTime*2.2f+i)*14f*u;
            drawStar(c,x,y,(4.6f+(i%3))*u,Color.rgb(255,244,175));
        }
    }

    private void drawWinCelebrationByStars(Canvas c, RectF panel, float u){
        RectF full=new RectF(0f,0f,getWidth(),getHeight());
        c.save();
        // Full-screen celebration, not limited to the popup panel.
        if(lastWinStars>=3) drawWinStarRain(c,full,u);
        else if(lastWinStars==2) drawWinFireworksBurst(c,full,u);
        else drawWinClapConfetti(c,full,u);
        c.restore();
    }

    private void drawWin(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();RectF p=new RectF(w*.075f,h*.135f,w*.925f,h*.735f);float appear=easeOutBack(clamp01(winCelebrationTimer/.32f));c.save();c.scale(appear,appear,p.centerX(),p.centerY());
        String winTitle=gameMode==GameMode.TREASURE_ROOM?"TREASURE ROOM!":(dailyChallengeMode?"DAILY COMPLETE!":(isBossLevel(selectedLevel)?"BOSS CLEARED!":"AWESOME!"));
        drawPanelHeader(c,p,winTitle);
        drawWinCelebrationByStars(c,p,u);
        // Premium animated completion crown + a larger, explicit level title.
        float cy=p.top+104f*u;
        for(int i=0;i<3;i++){float sx=p.centerX()+(i-1)*72f*u;drawWinStarCinematic(c,sx,cy,i,i<lastWinStars,u);}
        float completeY=p.top+158f*u;
        float completePulse=1f+.045f*(float)Math.sin(ambientTime*7.0f);
        RectF completeRibbon=new RectF(p.left+34f*u,completeY-27f*u,p.right-34f*u,completeY+27f*u);
        roundedGradient(c,completeRibbon,18f*u,Color.rgb(63,125,232),Color.rgb(39,73,171));
        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.argb(220,225,242,255));c.drawRoundRect(completeRibbon,18f*u,18f*u,stroke);
        c.save();c.scale(completePulse,completePulse,p.centerX(),completeY);
        String completeText=gameMode==GameMode.TREASURE_ROOM?"BONUS COMPLETE!":(dailyChallengeMode?"DAILY COMPLETE!":(isBossLevel(selectedLevel)?"BOSS LEVEL COMPLETE!":"LEVEL "+selectedLevel+" COMPLETE!"));
        labelOutline(c,completeText,p.centerX(),completeY,23.5f*u,Color.WHITE,Color.rgb(38,69,156));
        c.restore();
        float shine=((ambientTime*.62f)%1.35f)-.18f;
        float sx2=p.left+(p.width()*shine);
        paint.setShader(new LinearGradient(sx2-34f*u,0,sx2+34f*u,0,Color.TRANSPARENT,Color.argb(120,255,255,255),Shader.TileMode.MIRROR));
        c.drawRect(completeRibbon.left,completeRibbon.top,completeRibbon.right,completeRibbon.bottom,paint);paint.setShader(null);
        RectF score=new RectF(p.left+28f*u,p.top+190f*u,p.right-28f*u,p.top+266f*u);roundedGradient(c,score,18f*u,Color.rgb(69,82,176),Color.rgb(28,39,115));label(c,"SCORE",score.centerX(),score.top+20f*u,12.5f*u,Color.rgb(188,226,255));label(c,String.valueOf(levelScore),score.centerX(),score.top+52f*u,31f*u,Color.WHITE);
        RectF reward=new RectF(p.left+28f*u,p.top+282f*u,p.right-28f*u,p.top+338f*u);roundedGradient(c,reward,16f*u,Color.rgb(53,65,151),Color.rgb(30,37,104));paint.setShader(new RadialGradient(reward.left+28f*u,reward.centerY(),15f*u,Color.WHITE,Color.rgb(231,151,28),Shader.TileMode.CLAMP));c.drawCircle(reward.left+28f*u,reward.centerY(),14f*u,paint);paint.setShader(null);label(c,"COINS EARNED  +"+lastWinReward,reward.centerX()+10f*u,reward.centerY(),17f*u,Color.rgb(255,220,79));
        RectF next=new RectF(p.left+24f*u,p.top+358f*u,p.right-24f*u,p.top+414f*u);
        String nextText;
        if(gameMode==GameMode.TREASURE_ROOM)nextText="CONTINUE • LEVEL "+treasureReturnLevel;
        else if(dailyChallengeMode)nextText="BACK HOME";
        else if(treasureRoomPending)nextText="ENTER TREASURE ROOM";
        else {int nl=selectedLevel<MAP_LEVELS?selectedLevel+1:selectedLevel;nextText=(nl!=selectedLevel&&isBranchChoiceLevel(nl)&&branchRouteForLevel(nl)==0)?"CHOOSE ROUTE":(selectedLevel<MAP_LEVELS?"NEXT LEVEL":"PLAY AGAIN");}
        button(c,next,nextText,Color.rgb(117,226,60),Color.rgb(33,157,18));
        RectF replay=new RectF(p.left+24f*u,p.top+428f*u,p.centerX()-8f*u,p.top+482f*u);RectF map=new RectF(p.centerX()+8f*u,p.top+428f*u,p.right-24f*u,p.top+482f*u);button(c,replay,"REPLAY",Color.rgb(75,180,255),Color.rgb(41,86,198));button(c,map,"BACK TO MAP",Color.rgb(255,178,53),Color.rgb(224,87,20));
        if(lastChestBonus>0)label(c,"CHEST BONUS +"+lastChestBonus,p.centerX(),p.top+506f*u,12.2f*u,Color.rgb(255,190,70));if(lastBossBonus>0)label(c,"BOSS BONUS +"+lastBossBonus+" COINS",p.centerX(),p.top+526f*u,11.8f*u,Color.rgb(255,190,70));if(treasureRoomPending&&gameMode==GameMode.ADVENTURE)label(c,"BONUS TREASURE ROOM UNLOCKED!",p.centerX(),p.top+526f*u,11.8f*u,Color.rgb(255,207,78));if(milestoneText!=null)label(c,milestoneText,p.centerX(),p.top+548f*u,11.2f*u,Color.rgb(255,222,100));c.restore();
    }

    private void drawLose(Canvas c) {
        float w=getWidth(),h=getHeight(),u=uiScale();RectF p=new RectF(w*.10f,h*.20f,w*.90f,h*.615f);float appear=easeOutBack(clamp01(loseCelebrationTimer/.28f));c.save();c.scale(appear,appear,p.centerX(),p.centerY());drawPanelHeader(c,p,"GAME OVER");
        paint.setShader(new RadialGradient(p.centerX(),p.top+116f*u,90f*u,Color.argb(95,255,105,105),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(p.centerX(),p.top+116f*u,90f*u,paint);paint.setShader(null);drawBubbleSprite(c,3,p.centerX(),p.top+116f*u,34f*u);
        String loseTip=gameMode==GameMode.SURVIVAL?("SURVIVAL BEST "+Math.max(survivalBest,levelScore)):(gameMode==GameMode.TREASURE_ROOM?"TREASURE ROOM • TRY AGAIN":(levelLossStreak>=3?"COMEBACK BOOST READY: +3 SHOTS":"TRY A BOOSTER OR A BANK SHOT"));
        label(c,loseTip,p.centerX(),p.top+166f*u,15.5f*u,Color.rgb(111,68,170));
        RectF score=new RectF(p.left+24f*u,p.top+192f*u,p.right-24f*u,p.top+264f*u);roundedGradient(c,score,18f*u,Color.rgb(69,82,176),Color.rgb(28,39,115));label(c,"SCORE",score.centerX(),score.top+20f*u,12f*u,Color.rgb(188,226,255));label(c,String.valueOf(levelScore),score.centerX(),score.top+50f*u,28f*u,Color.WHITE);
        if(gameMode==GameMode.ADVENTURE && !dailyChallengeMode && !continueUsedThisLevel){
            RectF cont=new RectF(p.left+22f*u,p.top+282f*u,p.right-22f*u,p.top+338f*u);
            button(c,cont,"CONTINUE +4 SHOTS • "+CONTINUE_COST+" COINS",Color.rgb(114,210,96),Color.rgb(42,139,74));
        }
        button(c,new RectF(p.left+22f*u,p.bottom-91f*u,p.right-22f*u,p.bottom-39f*u),"TRY AGAIN",Color.rgb(255,178,53),Color.rgb(224,87,20));label(c,"BACK TO MAP",p.centerX(),p.bottom-17f*u,12.8f*u,Color.rgb(80,87,137));c.restore();
    }

    // ---------------------------------------------------------------
    // Touch handling
    // ---------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e){
        try {
        float x=e.getX(),y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            downX=x;downY=y;downTime=System.currentTimeMillis();
            if(screen==Screen.GAME&&overlay==Overlay.NONE&&(inToolsToggle(x,y)||toolMenuIndexAt(x,y)>=0)){
                aiming=false;return true;
            }
            if(screen==Screen.MAP&&overlay==Overlay.NONE){mapTouchStartY=y;mapScrollStart=mapScroll;mapDragging=false;}
            if(screen==Screen.GAME&&overlay==Overlay.NONE&&!shotInputBlocked()&&inShooterAimZone(x,y)){aiming=true;updateAim(x,y);}
            return true;
        }
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            if(screen==Screen.MAP&&overlay==Overlay.NONE){float dy=y-mapTouchStartY;if(Math.abs(dy)>8f)mapDragging=true;mapScroll=Math.max(0f,Math.min(maxMapScroll(),mapScrollStart+dy));}
            if(screen==Screen.GAME&&overlay==Overlay.NONE&&aiming){updateAim(x,y);}return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP){
            if(overlay!=Overlay.NONE){handleOverlayTap(x,y);aiming=false;return true;}
            if(screen==Screen.GAME){
                if(aiming && overlay==Overlay.NONE && !shotInputBlocked()){
                    shoot();
                    aiming=false;
                    return true;
                }
                if(inToolsToggle(x,y)){toolMenuOpen=!toolMenuOpen;clickFx();aiming=false;return true;}
                int toolIdx=toolMenuIndexAt(x,y);
                if(toolIdx>=0){handleToolAction(toolIdx);aiming=false;return true;}
                if(toolMenuOpen && x<98f*uiScale()){aiming=false;return true;}
            }
            switch(screen){
                case SPLASH:
                    // Ignore taps during loading; only the completed timer may open Home.
                    if (System.currentTimeMillis() - splashStarted >= SPLASH_DURATION_MS) {
                        screen=Screen.HOME; clickFx();
                    }
                    break;
                case HOME:handleHomeTap(x,y);break;
                case MAP:handleMapTap(x,y);break;
                case GAME:handleGameTap(x,y);break;
            }
            aiming=false;return true;
        }
        return true;
        } catch (Throwable t) {
            renderError = "Touch " + t.getClass().getSimpleName() + (t.getMessage() == null ? "" : (": " + t.getMessage()));
            invalidate();
            return true;
        }
    }

    private void handleHomeTap(float x,float y) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        if(in(x,y,w*.64f,h*.312f,w*.925f,h*.374f)){startSurvivalMode();return;}
        if(dist(x,y,w*.365f-20f*u,32.5f*u)<24f*u){overlay=Overlay.SHOP;clickFx();return;}
        if(dist(x,y,w*.975f-20f*u,32.5f*u)<24f*u){overlay=Overlay.LEADERBOARD;clickFx();return;}
        if(hasContinueOption()){
            if(in(x,y,w*.11f,h*.375f,w*.89f,h*.455f)){
                if(hasSavedGame())loadGameState(); else startLevel(Math.max(1,maxUnlocked));
                clickFx();return;
            }
            if(in(x,y,w*.13f,h*.485f,w*.87f,h*.56f)){screen=Screen.MAP;clickFx();return;}
            if(in(x,y,w*.16f,h*.585f,w*.84f,h*.655f)){startDailyChallenge();return;}
            if(in(x,y,w*.16f,h*.675f,w*.84f,h*.745f)){claimDailyGift();return;}
            if(in(x,y,w*.16f,h*.758f,w*.84f,h*.828f)){watchHomeRewardAd();return;}
        }else{
            if(in(x,y,w*.12f,h*.415f,w*.88f,h*.500f)){screen=Screen.MAP;clickFx();return;}
            if(in(x,y,w*.15f,h*.525f,w*.85f,h*.603f)){startDailyChallenge();return;}
            if(in(x,y,w*.15f,h*.625f,w*.85f,h*.703f)){claimDailyGift();return;}
            if(in(x,y,w*.15f,h*.720f,w*.85f,h*.798f)){watchHomeRewardAd();return;}
        }
        if(dist(x,y,w*.12f,h*.870f)<w*.095f){settingsReturnScreen=Screen.HOME;overlay=Overlay.HELP;clickFx();return;}
        if(dist(x,y,w*.38f,h*.870f)<w*.095f){overlay=Overlay.LEADERBOARD;clickFx();return;}
        if(dist(x,y,w*.62f,h*.870f)<w*.095f){overlay=Overlay.SHOP;clickFx();return;}
        if(dist(x,y,w*.88f,h*.870f)<w*.095f){settingsReturnScreen=Screen.HOME;overlay=Overlay.SETTINGS;clickFx();return;}
        if(in(x,y,w*.32f,h*.945f,w*.68f,h*.985f)){overlay=Overlay.EXIT_CONFIRM;clickFx();return;}
    }

    private void watchHomeRewardAd(){
        MainActivity hs=host();
        if(hs!=null)hs.showRewardedCoins();
        else floatingTexts.add(new FloatingText("ADS ARE UNAVAILABLE",getWidth()*.5f,getHeight()*.58f,Color.WHITE,20f));
        clickFx();
    }

    private void handleMapTap(float x,float y) {
        float w=getWidth(),u=uiScale();if(mapDragging)return;
        if(dist(x,y,w*.365f-20f*u,32.5f*u)<24f*u){overlay=Overlay.SHOP;clickFx();return;}
        if(dist(x,y,w*.975f-20f*u,32.5f*u)<24f*u){overlay=Overlay.LEADERBOARD;clickFx();return;}
        if(dist(x,y,w*.09f,66f*u)<46f*u){screen=Screen.HOME;audio.setMusicTheme(12);clickFx();return;}
        if(dist(x,y,w*.91f,66f*u)<46f*u){settingsReturnScreen=Screen.MAP;overlay=Overlay.SETTINGS;clickFx();return;}
        for(int level=2;level<=maxUnlocked;level++){
            if(!isBranchChoiceLevel(level)||branchRouteForLevel(level)!=0)continue;
            PointF a=branchNode(level,1),b=branchNode(level,2);
            if(dist(x,y,a.x,a.y)<38f*u){prefs.edit().putInt("route_"+level,1).apply();activeBranchRoute=1;floatingTexts.add(new FloatingText("POWER ROUTE SELECTED",a.x,a.y-30f*u,Color.rgb(128,231,255),22f));startLevel(level);return;}
            if(dist(x,y,b.x,b.y)<38f*u){prefs.edit().putInt("route_"+level,2).apply();activeBranchRoute=2;floatingTexts.add(new FloatingText("TREASURE ROUTE SELECTED",b.x,b.y-30f*u,Color.rgb(255,218,96),22f));startLevel(level);return;}
        }
        for(int level=1;level<=maxUnlocked;level++){
            PointF q=mapNode(level);
            if(dist(x,y,q.x,q.y)<43f*u){
                if(isBranchChoiceLevel(level)&&branchRouteForLevel(level)==0){floatingTexts.add(new FloatingText("CHOOSE POWER OR TREASURE ROUTE",q.x,q.y-42f*u,Color.rgb(255,237,118),20f));audio.play(AudioEngine.FX_UI_OPEN,.8f,1.05f);return;}
                startLevel(level);return;
            }
        }
    }

    private boolean inToolsToggle(float x,float y){
        float u=uiScale();return dist(x,y,39f*u,46f*u)<38f*u;
    }

    private int toolMenuIndexAt(float x,float y){
        if(!toolMenuOpen)return -1;
        float u=uiScale(),h=getHeight();
        float panelTop=96f*u,gap=72f*u;
        if(x>96f*u || y<panelTop || y>Math.min(h*.74f,132f*u+gap*5f+35f*u))return -1;
        float first=132f*u;
        int idx=Math.round((y-first)/gap);
        if(idx<0||idx>5)return -1;
        return Math.abs(y-(first+idx*gap))<=31f*u?idx:-1;
    }

    private void handleToolAction(int idx){
        toolMenuOpen=false;
        if(idx==0){saveGameState();overlay=Overlay.PAUSE;clickFx();return;}
        if(idx==1){
            if(gameMode==GameMode.SURVIVAL)startSurvivalMode();
            else if(gameMode==GameMode.TREASURE_ROOM)startTreasureRoom(Math.max(1,treasureReturnLevel-1));
            else if(dailyChallengeMode)startDailyChallenge();
            else {clearSavedGame();startLevel(selectedLevel);}
            return;
        }
        if(idx==2){saveGameState();settingsReturnScreen=Screen.GAME;overlay=Overlay.SETTINGS;clickFx();return;}
        if(idx==3){soundOn=!soundOn;audio.setSoundEnabled(soundOn);saveSettings();clickFx();return;}
        if(idx==4){saveGameState();settingsReturnScreen=Screen.GAME;overlay=Overlay.HELP;clickFx();return;}
        if(idx==5){
            saveGameState();
            if(gameMode==GameMode.SURVIVAL){gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
            else if(dailyChallengeMode){dailyChallengeMode=false;gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
            else {gameMode=GameMode.ADVENTURE;screen=Screen.MAP;audio.setMusicTheme(12);}
            overlay=Overlay.NONE;clickFx();
        }
    }

    private boolean inShooterAimZone(float x,float y){
        // Invisible aiming track: launcher -> all 15 visible guide dots.
        // The rest of the playfield stays non-shootable, so touching bubbles or
        // upper-board space can never accidentally fire a shot.
        float u=uiScale();
        float dx=x-shooterX,dy=y-shooterY;
        float launcherR=Math.max(46f*u,bubbleR*1.55f);
        if(dx*dx+dy*dy<=launcherR*launcherR)return true;

        float adx=(float)Math.cos(aimAngle),ady=(float)Math.sin(aimAngle);
        float step=bubbleR*.88f;
        // Fifteen visible dots define the complete invisible aiming track.
        float trackLen=step*15.6f+bubbleR*.70f;
        float vx=adx*trackLen,vy=ady*trackLen;
        float len2=vx*vx+vy*vy;
        if(len2<=0.01f)return false;
        float t=((x-shooterX)*vx+(y-shooterY)*vy)/len2;
        if(t<0f||t>1f)return false;
        float px=shooterX+t*vx,py=shooterY+t*vy;
        float hitRadius=Math.max(28f*u,bubbleR*.58f);
        float hx=x-px,hy=y-py;
        return hx*hx+hy*hy<=hitRadius*hitRadius;
    }

    private boolean shotInputBlocked(){
        return shotFlying || !falling.isEmpty() || overlay!=Overlay.NONE || rowDropTimer>0f || levelIntroTimer>0f || shotsLeft<=0;
    }

    private void handleGameTap(float x,float y) {
        float w=getWidth(),h=getHeight(),u=uiScale();
        if(inSuperPower(x,y)){if(superCharge>=100)activateSuperPower();else {floatingTexts.add(new FloatingText("BUILD COMBOS TO CHARGE REALM POWER",w*.5f,h*.74f,Color.rgb(187,231,255),19f));clickFx();}return;}
        float py=h*.895f,bw=w*.285f,bh=Math.max(84f*u,h*.078f);
        RectF bomb=new RectF(w*.035f,py-bh/2,w*.035f+bw,py+bh/2),rain=new RectF(w*.3575f,py-bh/2,w*.3575f+bw,py+bh/2),swap=new RectF(w*.68f,py-bh/2,w*.68f+bw,py+bh/2);
        if(in(x,y,bomb.left,bomb.top,bomb.right,bomb.bottom)){if(bombCount<=0){showRewardOffer(2);return;}power=power==Power.BOMB?Power.NORMAL:Power.BOMB;audio.play(AudioEngine.FX_POWER,.9f,.92f);clickFx();return;}
        if(in(x,y,rain.left,rain.top,rain.right,rain.bottom)){if(rainbowCount<=0){showRewardOffer(3);return;}power=power==Power.RAINBOW?Power.NORMAL:Power.RAINBOW;audio.play(AudioEngine.FX_POWER,.9f,1.08f);clickFx();return;}
        if(in(x,y,swap.left,swap.top,swap.right,swap.bottom)){int tmp=currentColor;currentColor=nextColor;nextColor=tmp;audio.play(AudioEngine.FX_SWAP,.8f,1f);clickFx();return;}
        if(aiming&&!shotInputBlocked()){updateAim(x,y);shoot();return;}
        // Shooting is intentionally restricted to the launcher zone. Touching a bubble
        // or the upper board never fires a shot; start the aim from the bottom launcher.
        if(inShooterAimZone(x,y)&&!shotInputBlocked()){updateAim(x,y);shoot();}
    }

    private void handleOverlayTap(float x,float y) {
        RectF p=panelRect();float u=uiScale();
        if(overlay==Overlay.REWARD_OFFER){
            float w=getWidth(),h=getHeight();
            RectF q=new RectF(w*.075f,h*.22f,w*.925f,h*.72f);
            if(in(x,y,q.left+28f*u,q.top+270f*u,q.right-28f*u,q.top+338f*u)){
                MainActivity hs=host();
                if(hs!=null){hs.showRewardedGameReward(rewardOfferType);clickFx();}
                return;
            }
            if((rewardOfferType==2 || rewardOfferType==3) && in(x,y,q.left+28f*u,q.top+348f*u,q.right-28f*u,q.top+412f*u)){
                buyBoosterWithCoins(rewardOfferType==2?Power.BOMB:Power.RAINBOW);
                if(overlay==Overlay.REWARD_OFFER){overlay=Overlay.NONE;rewardOfferType=0;}
                clickFx();return;
            }
            if(y>q.bottom-62f*u || dist(x,y,q.right-34f*u,q.top+34f*u)<42f*u){overlay=Overlay.NONE;rewardOfferType=0;clickFx();return;}
            return;
        }
        if(overlay==Overlay.PRIVACY){
            if(dist(x,y,p.right-34f*u,p.top+34f*u)<46f*u){overlay=Overlay.SETTINGS;clickFx();return;}
            MainActivity hs=host();
            if(hs!=null && hs.isAdPrivacyOptionsRequired()){
                RectF adPrivacy=new RectF(p.left+28f*u,p.bottom-92f*u,p.right-28f*u,p.bottom-42f*u);
                if(in(x,y,adPrivacy.left,adPrivacy.top,adPrivacy.right,adPrivacy.bottom)){hs.showAdPrivacyOptions();clickFx();return;}
            }
        }
        if((overlay==Overlay.SETTINGS||overlay==Overlay.HELP)&&dist(x,y,p.right-34f*u,p.top+34f*u)<46f*u){overlay=(overlay==Overlay.SETTINGS&&settingsReturnScreen==Screen.GAME&&screen==Screen.GAME)?Overlay.PAUSE:Overlay.NONE;clickFx();return;}
        if(overlay==Overlay.LEADERBOARD){RectF q=new RectF(getWidth()*.06f,getHeight()*.08f,getWidth()*.94f,getHeight()*.88f);if(dist(x,y,q.right-34f*u,q.top+34f*u)<46f*u){overlay=Overlay.NONE;clickFx();return;}}
        if(overlay==Overlay.SHOP){RectF q=new RectF(getWidth()*.05f,getHeight()*.07f,getWidth()*.95f,getHeight()*.91f);if(dist(x,y,q.right-34f*u,q.top+34f*u)<46f*u){overlay=Overlay.NONE;clickFx();return;}}
        if(overlay==Overlay.SETTINGS){float y0=p.top+124f*u;if(Math.abs(y-y0)<46f*u){soundOn=!soundOn;audio.setSoundEnabled(soundOn);saveSettings();clickFx();return;}if(Math.abs(y-(y0+96f*u))<46f*u){aimGuideOn=!aimGuideOn;saveSettings();clickFx();return;}if(Math.abs(y-(y0+192f*u))<46f*u){hapticsOn=!hapticsOn;saveSettings();clickFx();return;}if(in(x,y,p.left+18f*u,p.bottom-150f*u,p.right-18f*u,p.bottom-94f*u)){overlay=Overlay.PRIVACY;clickFx();return;}if(in(x,y,p.left+18f*u,p.bottom-80f*u,p.right-18f*u,p.bottom-24f*u)){overlay=Overlay.RESET_CONFIRM;clickFx();return;}}
        if(overlay==Overlay.SHOP){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.05f,h*.07f,w*.95f,h*.91f);MainActivity hs=host();
            float mid=q.centerX();
            RectF daily=new RectF(q.left+18f*u,q.top+168f*u,mid-7f*u,q.top+228f*u);
            RectF rewardAd=new RectF(mid+7f*u,q.top+168f*u,q.right-18f*u,q.top+228f*u);
            if(in(x,y,daily.left,daily.top,daily.right,daily.bottom)){claimDailyGift();clickFx();return;}
            if(in(x,y,rewardAd.left,rewardAd.top,rewardAd.right,rewardAd.bottom)){
                if(hs!=null)hs.showRewardedCoins();clickFx();return;
            }
            float sy=q.top+288f*u,gap=14f*u,cardW=(q.width()-42f*u)/2f,cardH=142f*u;
            RectF a=new RectF(q.left+14f*u,sy,q.left+14f*u+cardW,sy+cardH);
            RectF b=new RectF(q.left+28f*u+cardW,sy,q.right-14f*u,sy+cardH);sy+=cardH+gap;
            RectF c1=new RectF(q.left+14f*u,sy,q.left+14f*u+cardW,sy+cardH);
            RectF d=new RectF(q.left+28f*u+cardW,sy,q.right-14f*u,sy+cardH);
            if(hs!=null){if(in(x,y,a.left,a.top,a.right,a.bottom)){hs.buyCoinPack(BillingManager.COINS_500);clickFx();return;}if(in(x,y,b.left,b.top,b.right,b.bottom)){hs.buyCoinPack(BillingManager.COINS_1200);clickFx();return;}if(in(x,y,c1.left,c1.top,c1.right,c1.bottom)){hs.buyCoinPack(BillingManager.COINS_2500);clickFx();return;}if(in(x,y,d.left,d.top,d.right,d.bottom)){hs.buyCoinPack(BillingManager.COINS_1800);clickFx();return;}}
        }
        if(overlay==Overlay.PAUSE){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.055f,h*.14f,w*.945f,h*.84f);
            if(dist(x,y,q.right-34f*u,q.top+34f*u)<46f*u){overlay=Overlay.NONE;saveGameState();clickFx();return;}
            if(in(x,y,q.left+20f*u,q.top+118f*u,q.right-20f*u,q.top+184f*u)){overlay=Overlay.NONE;saveGameState();clickFx();return;}
            if(in(x,y,q.left+20f*u,q.top+202f*u,q.right-20f*u,q.top+268f*u)){
                if(gameMode==GameMode.SURVIVAL)startSurvivalMode();
                else if(gameMode==GameMode.TREASURE_ROOM)startTreasureRoom(Math.max(1,treasureReturnLevel-1));
                else if(dailyChallengeMode)startDailyChallenge();
            else {clearSavedGame();startLevel(selectedLevel);}
                return;
            }
            if(in(x,y,q.left+20f*u,q.top+286f*u,q.right-20f*u,q.top+352f*u)){settingsReturnScreen=Screen.GAME;overlay=Overlay.SETTINGS;clickFx();return;}
            if(in(x,y,q.left+20f*u,q.bottom-88f*u,q.right-20f*u,q.bottom-24f*u)){
                saveGameState();overlay=Overlay.NONE;
                if(gameMode==GameMode.SURVIVAL){gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
                else if(dailyChallengeMode){dailyChallengeMode=false;gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
                else {gameMode=GameMode.ADVENTURE;screen=Screen.MAP;audio.setMusicTheme(12);}
                clickFx();return;
            }
        }
        if(overlay==Overlay.RESET_CONFIRM){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.085f,h*.28f,w*.915f,h*.67f);
            if(dist(x,y,q.right-36f*u,q.top+36f*u)<48f*u){overlay=Overlay.SETTINGS;clickFx();return;}
            RectF no=new RectF(q.left+20f*u,q.bottom-92f*u,q.centerX()-8f*u,q.bottom-28f*u);
            RectF yes=new RectF(q.centerX()+8f*u,q.bottom-92f*u,q.right-20f*u,q.bottom-28f*u);
            if(in(x,y,no.left,no.top,no.right,no.bottom)){overlay=Overlay.SETTINGS;clickFx();return;}
            if(in(x,y,yes.left,yes.top,yes.right,yes.bottom)){clickFx();resetGameProgress();return;}
        }
        if(overlay==Overlay.EXIT_CONFIRM){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.10f,h*.31f,w*.90f,h*.64f);
            RectF no=new RectF(q.left+20f*u,q.bottom-86f*u,q.centerX()-8f*u,q.bottom-26f*u);
            RectF yes=new RectF(q.centerX()+8f*u,q.bottom-86f*u,q.right-20f*u,q.bottom-26f*u);
            if(in(x,y,no.left,no.top,no.right,no.bottom)){overlay=Overlay.NONE;clickFx();return;}
            if(in(x,y,yes.left,yes.top,yes.right,yes.bottom)){clickFx();exitApp();return;}
        }
        if(overlay==Overlay.WIN){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.075f,h*.135f,w*.925f,h*.735f);
            if(dist(x,y,q.right-34f*u,q.top+34f*u)<40f*u){
                clickFx();
                overlay=Overlay.NONE;
                if(gameMode==GameMode.TREASURE_ROOM){screen=Screen.MAP;gameMode=GameMode.ADVENTURE;audio.setMusicTheme(12);}
                else {screen=dailyChallengeMode?Screen.HOME:Screen.MAP;dailyChallengeMode=false;audio.setMusicTheme(12);}
                return;
            }
            if(in(x,y,q.left+24f*u,q.top+358f*u,q.right-24f*u,q.top+414f*u)){
                clickFx();
                if(gameMode==GameMode.TREASURE_ROOM){
                    final int next=treasureReturnLevel;afterLevelAd(() -> startLevel(next));
                }else if(dailyChallengeMode){
                    afterLevelAd(() -> {dailyChallengeMode=false;overlay=Overlay.NONE;screen=Screen.HOME;audio.setMusicTheme(12);});
                }else if(treasureRoomPending){
                    final int from=selectedLevel;afterLevelAd(() -> startTreasureRoom(from));
                }else{
                    final int next=selectedLevel<MAP_LEVELS?selectedLevel+1:selectedLevel;
                    if(next!=selectedLevel&&isBranchChoiceLevel(next)&&branchRouteForLevel(next)==0){
                        afterLevelAd(() -> {overlay=Overlay.NONE;screen=Screen.MAP;audio.setMusicTheme(12);});
                    }else afterLevelAd(() -> startLevel(next));
                }
                return;
            }
            if(in(x,y,q.left+24f*u,q.top+428f*u,q.centerX()-8f*u,q.top+482f*u)){
                clickFx();
                if(gameMode==GameMode.TREASURE_ROOM)startTreasureRoom(Math.max(1,treasureReturnLevel-1));
                else if(dailyChallengeMode)startDailyChallenge();
                else startLevel(selectedLevel);
                return;
            }
            if(in(x,y,q.centerX()+8f*u,q.top+428f*u,q.right-24f*u,q.top+482f*u)){
                clickFx();
                overlay=Overlay.NONE;
                if(gameMode==GameMode.TREASURE_ROOM){gameMode=GameMode.ADVENTURE;screen=Screen.MAP;audio.setMusicTheme(12);}
                else {screen=dailyChallengeMode?Screen.HOME:Screen.MAP;dailyChallengeMode=false;audio.setMusicTheme(12);}
                return;
            }
        }
        if(overlay==Overlay.LOSE){
            float w=getWidth(),h=getHeight();RectF q=new RectF(w*.10f,h*.20f,w*.90f,h*.615f);
            if(gameMode==GameMode.ADVENTURE && !dailyChallengeMode && !continueUsedThisLevel){
                RectF cont=new RectF(q.left+22f*u,q.top+282f*u,q.right-22f*u,q.top+338f*u);
                if(in(x,y,cont.left,cont.top,cont.right,cont.bottom)){
                    if(coins>=CONTINUE_COST){
                        coins-=CONTINUE_COST;continueUsedThisLevel=true;shotsLeft=4;misses=0;shotsSinceDrop=0;rowDropTimer=0f;overlay=Overlay.NONE;
                        prefs.edit().putInt("coins",coins).apply();saveGameState();
                        floatingTexts.add(new FloatingText("CONTINUE • +4 SHOTS",w*.5f,h*.52f,Color.rgb(165,245,177),26f));
                        audio.play(AudioEngine.FX_POWER,.92f,1.08f);haptic(45);return;
                    }else{
                        floatingTexts.add(new FloatingText("NEED "+CONTINUE_COST+" COINS",w*.5f,h*.52f,Color.rgb(255,201,119),24f));
                        audio.play(AudioEngine.FX_UI_OPEN,.72f,.92f);haptic(22);return;
                    }
                }
            }
            if(dist(x,y,q.right-34f*u,q.top+34f*u)<40f*u){
                overlay=Overlay.NONE;
                if(gameMode==GameMode.SURVIVAL){gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
                else if(gameMode==GameMode.TREASURE_ROOM){gameMode=GameMode.ADVENTURE;screen=Screen.MAP;audio.setMusicTheme(12);}
                else {screen=dailyChallengeMode?Screen.HOME:Screen.MAP;dailyChallengeMode=false;}
                clickFx();return;
            }
            if(in(x,y,q.left+22f*u,q.bottom-91f*u,q.right-22f*u,q.bottom-39f*u)){
                clearSavedGame();
                if(gameMode==GameMode.SURVIVAL)startSurvivalMode();
                else if(gameMode==GameMode.TREASURE_ROOM)startTreasureRoom(Math.max(1,treasureReturnLevel-1));
                else if(dailyChallengeMode)startDailyChallenge();
                else startLevel(selectedLevel);
                return;
            }
            if(y>q.bottom-31f*u){
                overlay=Overlay.NONE;
                if(gameMode==GameMode.SURVIVAL){gameMode=GameMode.ADVENTURE;screen=Screen.HOME;audio.setMusicTheme(12);}
                else if(gameMode==GameMode.TREASURE_ROOM){gameMode=GameMode.ADVENTURE;screen=Screen.MAP;audio.setMusicTheme(12);}
                else {screen=dailyChallengeMode?Screen.HOME:Screen.MAP;dailyChallengeMode=false;}
                clickFx();return;
            }
        }
    }

    private void afterLevelAd(Runnable action){
        // Interstitial is triggered after every 2 completed Adventure levels (2, 4, 6, 8...) when NEXT LEVEL / CONTINUE is pressed.
        // Daily Challenge, Treasure Room and Survival never force an interstitial.
        if(dailyChallengeMode || gameMode!=GameMode.ADVENTURE || selectedLevel<2 || (selectedLevel%2)!=0){if(action!=null)action.run();return;}
        MainActivity hs=host();
        if(hs!=null)hs.showLevelEndAd(action);
        else if(action!=null)action.run();
    }

    private void updateAim(float x,float y){
        float a=(float)Math.atan2(y-shooterY,x-shooterX);
        float min=(float)(-Math.PI+0.20),max=-0.20f;
        if(a>max)a=max;if(a<min)a=min;aimAngle=a;
    }

    private int worldIndex(int level){return Math.max(0,Math.min(19,(level-1)/25));}
    private String worldName(int level){
        String[] n={"SKY GARDENS","CANDY CLOUDS","SUNSET SHORES","OCEAN GLOW","MOONLIGHT","AURORA PEAKS","CRYSTAL CAVES","NEON CITY","DREAM FOREST","STAR TEMPLE","VOLCANO RIDGE","FROST KINGDOM","GOLDEN DUNES","GALAXY GARDEN","SPRING VALLEY","CYBER BAY","CORAL LAGOON","ECLIPSE REALM","RAINBOW HILLS","COSMIC CITADEL"};
        return n[worldIndex(level)];
    }
    private String realmRuleName(int level){
        String[] rules={"SKY DRIFT","SUGAR COMBOS","SUNSET STREAKS","TIDAL WIND","MOON GRAVITY","AURORA SWAY","CRYSTAL PULSE","NEON BUMPERS","FOREST CHAINS","STAR PORTALS","LAVA PRESSURE","FROST ARMOR","DUNE CROSSWIND","GALAXY ORBITS","SPRING SURGE","CYBER DEFLECTORS","CORAL CURRENT","ECLIPSE GRAVITY","RAINBOW FUSION","CITADEL CHAOS"};
        return rules[worldIndex(level)];
    }
    private int themeAccent(int level){
        int[] c={Color.rgb(57,158,255),Color.rgb(238,83,184),Color.rgb(255,137,55),Color.rgb(26,191,191),Color.rgb(104,88,220),Color.rgb(70,215,145),Color.rgb(80,190,236),Color.rgb(179,75,244),Color.rgb(71,188,104),Color.rgb(255,184,47),Color.rgb(255,83,47),Color.rgb(100,206,255),Color.rgb(239,180,61),Color.rgb(124,92,255),Color.rgb(71,203,116),Color.rgb(27,216,232),Color.rgb(34,189,191),Color.rgb(128,91,218),Color.rgb(255,99,171),Color.rgb(255,202,55)};
        return c[worldIndex(level)];
    }
    private int themeTop(int level){
        int[] c={Color.rgb(66,112,201),Color.rgb(142,77,190),Color.rgb(190,83,102),Color.rgb(37,131,174),Color.rgb(34,39,101),Color.rgb(77,61,167),Color.rgb(42,113,169),Color.rgb(91,38,154),Color.rgb(47,125,99),Color.rgb(104,63,155),Color.rgb(126,44,46),Color.rgb(57,112,178),Color.rgb(188,122,49),Color.rgb(34,28,92),Color.rgb(75,145,106),Color.rgb(23,65,122),Color.rgb(25,109,128),Color.rgb(46,37,91),Color.rgb(129,70,153),Color.rgb(52,37,108)};
        return c[worldIndex(level)];
    }
    private int themeBottom(int level){
        int[] c={Color.rgb(157,204,255),Color.rgb(243,169,226),Color.rgb(255,190,119),Color.rgb(123,221,224),Color.rgb(93,111,191),Color.rgb(128,209,210),Color.rgb(156,223,243),Color.rgb(226,132,241),Color.rgb(167,223,156),Color.rgb(242,191,111),Color.rgb(245,117,63),Color.rgb(194,237,255),Color.rgb(255,220,144),Color.rgb(106,92,206),Color.rgb(192,235,151),Color.rgb(69,194,218),Color.rgb(100,222,206),Color.rgb(126,111,194),Color.rgb(255,181,221),Color.rgb(215,162,247)};
        return c[worldIndex(level)];
    }
    private void drawLevelBackground(Canvas c) {
        drawWorldWallpaper(c, selectedLevel, true);
    }

    private void drawStartupWallpaper(Canvas c,int level) {
        drawWorldWallpaper(c,level,true);
        // Extra translucent glass layers make launch/home screens feel richer without copied assets.
        float w=getWidth(),h=getHeight(),u=uiScale();
        paint.setColor(Color.argb(28,255,255,255));
        c.drawOval(new RectF(-w*.18f,h*.09f,w*.52f,h*.29f),paint);
        c.drawOval(new RectF(w*.48f,h*.31f,w*1.14f,h*.53f),paint);
        stroke.setStrokeWidth(2f*u);stroke.setColor(Color.argb(24,255,255,255));
        for(int i=0;i<4;i++){float yy=h*(.20f+i*.17f);c.drawArc(new RectF(w*.10f,yy,w*.90f,yy+h*.18f),205f,130f,false,stroke);}
    }

    private int blendColor(int a,int b,float t){
        t=Math.max(0f,Math.min(1f,t));
        return Color.rgb((int)(Color.red(a)+(Color.red(b)-Color.red(a))*t),
                (int)(Color.green(a)+(Color.green(b)-Color.green(a))*t),
                (int)(Color.blue(a)+(Color.blue(b)-Color.blue(a))*t));
    }

    private float mapFocusLevelFloat(){
        float u=uiScale();
        float yTarget=getHeight()*.54f;
        float f=1f+(getHeight()-158f*u+mapScroll-yTarget)/(126f*u);
        return Math.max(1f,Math.min(MAP_LEVELS,f));
    }

    private int mapSceneTop(int scene){
        int[] p={
                Color.rgb(78,150,225),Color.rgb(100,114,219),Color.rgb(170,91,185),Color.rgb(228,115,120),
                Color.rgb(40,126,181),Color.rgb(39,49,117),Color.rgb(102,63,177),Color.rgb(45,145,121),
                Color.rgb(198,123,65),Color.rgb(37,83,154),Color.rgb(123,74,183),Color.rgb(50,127,170),
                Color.rgb(29,38,86),Color.rgb(116,51,73),Color.rgb(70,118,161),Color.rgb(27,99,74),
                Color.rgb(74,44,117),Color.rgb(31,75,115),Color.rgb(165,91,48),Color.rgb(49,66,128)
        };
        return p[Math.floorMod(scene,p.length)];
    }
    private int mapSceneBottom(int scene){
        int[] p={
                Color.rgb(191,231,255),Color.rgb(192,213,255),Color.rgb(248,188,235),Color.rgb(255,207,142),
                Color.rgb(133,229,225),Color.rgb(103,119,195),Color.rgb(216,145,236),Color.rgb(176,232,172),
                Color.rgb(255,224,147),Color.rgb(113,204,229),Color.rgb(211,164,242),Color.rgb(135,220,225),
                Color.rgb(75,94,164),Color.rgb(235,116,83),Color.rgb(193,226,255),Color.rgb(132,205,139),
                Color.rgb(169,131,225),Color.rgb(111,185,223),Color.rgb(255,180,100),Color.rgb(141,165,235)
        };
        return p[Math.floorMod(scene,p.length)];
    }

    private void drawMapSceneDecor(Canvas c,int scene,float alpha,float phase){
        if(alpha<=.01f)return;
        float w=getWidth(),h=getHeight(),u=uiScale();int type=Math.floorMod(scene,16);
        if(type==0){
            // Cloud valley.
            for(int i=0;i<7;i++){float x=w*(.01f+i*.18f)+(float)Math.sin(ambientTime*.08f+i+phase)*13f*u;float y=h*(.15f+(i%3)*.20f);paint.setColor(Color.argb((int)(72*alpha),245,252,255));c.drawOval(new RectF(x-w*.11f,y-w*.035f,x+w*.11f,y+w*.035f),paint);}
        }else if(type==1){
            // Desert sunset with drifting dunes.
            paint.setColor(Color.argb((int)(100*alpha),255,217,113));c.drawCircle(w*.78f,h*.20f,w*.095f,paint);
            for(int i=0;i<4;i++){Path d=new Path();float yy=h*(.68f+i*.06f)+(float)Math.sin(ambientTime*.05f+i)*3f*u;d.moveTo(0,yy);d.quadTo(w*.25f,yy-h*.09f,w*.52f,yy);d.quadTo(w*.76f,yy+h*.05f,w,yy-h*.02f);d.lineTo(w,h);d.lineTo(0,h);d.close();paint.setColor(Color.argb((int)((35+i*8)*alpha),121,67,105));c.drawPath(d,paint);}
        }else if(type==2){
            // Bubble garden.
            for(int i=0;i<18;i++){float x=w*(.04f+(i%9)*.12f)+(float)Math.sin(ambientTime*.18f+i)*7f*u;float y=h*(.13f+(i/9)*.52f)+(float)Math.cos(ambientTime*.16f+i)*8f*u;int col=PALETTE[(i+scene)%PALETTE.length];paint.setColor((col&0x00FFFFFF)|((int)(60*alpha)<<24));c.drawCircle(x,y,w*(.021f+(i%4)*.008f),paint);}
        }else if(type==3){
            // Ocean current.
            stroke.setStrokeWidth(5f*u);for(int i=0;i<6;i++){float yy=h*(.59f+i*.052f)+(float)Math.sin(ambientTime*.22f+i)*3f*u;Path wave=new Path();wave.moveTo(-w*.1f,yy);wave.cubicTo(w*.18f,yy-h*.032f,w*.40f,yy+h*.032f,w*.63f,yy);wave.cubicTo(w*.81f,yy-h*.032f,w*.97f,yy+h*.02f,w*1.1f,yy);stroke.setColor(Color.argb((int)((45+i*8)*alpha),215,250,255));c.drawPath(wave,stroke);}
            for(int i=0;i<9;i++){float bx=((i*.14f)+ambientTime*.006f)%1.08f*w;float by=h*(.25f+((i*19)%46)/100f);paint.setColor(Color.argb((int)(48*alpha),240,255,255));c.drawCircle(bx,by,(3f+i%3*2f)*u,paint);}
        }else if(type==4){
            // Moon and stars.
            paint.setColor(Color.argb((int)(96*alpha),247,245,255));c.drawCircle(w*.76f,h*.20f,w*.095f,paint);
            for(int i=0;i<28;i++){float tw=.45f+.55f*(float)Math.abs(Math.sin(ambientTime*2.2f+i));paint.setColor(Color.argb((int)((42+95*tw)*alpha),255,255,255));c.drawCircle(((i*.083f)%1f)*w,h*(.07f+((i*17)%64)/100f),(1.1f+(i%3)*.7f)*u,paint);}
        }else if(type==5){
            // Aurora curtains.
            stroke.setStrokeWidth(9f*u);for(int i=0;i<5;i++){Path aur=new Path();float yy=h*(.18f+i*.062f)+(float)Math.sin(ambientTime*.12f+i)*7f*u;aur.moveTo(-w*.1f,yy);aur.cubicTo(w*.25f,yy-h*.075f,w*.50f,yy+h*.07f,w*1.1f,yy-h*.025f);stroke.setColor(Color.argb((int)((32+i*8)*alpha),110+i*24,255,195+i*8));c.drawPath(aur,stroke);}
        }else if(type==6){
            // Forest hills with swaying trees.
            Path hill=new Path();hill.moveTo(0,h*.76f);hill.quadTo(w*.24f,h*.61f,w*.49f,h*.78f);hill.quadTo(w*.74f,h*.62f,w,h*.73f);hill.lineTo(w,h);hill.lineTo(0,h);hill.close();paint.setColor(Color.argb((int)(72*alpha),35,104,81));c.drawPath(hill,paint);
            for(int i=0;i<10;i++){float x=w*(.02f+i*.11f),base=h*.83f;float sway=(float)Math.sin(ambientTime*.28f+i)*4f*u;Path tree=new Path();tree.moveTo(x,base);tree.lineTo(x+w*.040f+sway,base-h*.13f);tree.lineTo(x+w*.080f,base);tree.close();paint.setColor(Color.argb((int)(68*alpha),27,83,58));c.drawPath(tree,paint);}
        }else if(type==7){
            // Crystal cave.
            for(int i=0;i<10;i++){float x=w*(.03f+i*.11f),base=h*.80f,hh=h*(.06f+.025f*(i%4));Path cr=new Path();cr.moveTo(x,base);cr.lineTo(x+w*.032f,base-hh);cr.lineTo(x+w*.064f,base);cr.close();paint.setColor(Color.argb((int)(72*alpha),125+i*8,220,255));c.drawPath(cr,paint);}
            for(int i=0;i<8;i++){float tw=.5f+.5f*(float)Math.sin(ambientTime*2.8f+i);paint.setColor(Color.argb((int)((40+80*tw)*alpha),215,248,255));c.drawCircle(w*(.09f+i*.12f),h*(.18f+(i%3)*.12f),(1.6f+tw*2f)*u,paint);}
        }else if(type==8){
            // Neon city skyline with animated windows.
            for(int i=0;i<10;i++){float bw=w*.075f,bx=i*w*.105f,top=h*(.49f-.035f*(i%5));paint.setColor(Color.argb((int)(82*alpha),24,26,68));c.drawRoundRect(new RectF(bx,top,bx+bw,h*.82f),5f*u,5f*u,paint);for(int j=0;j<5;j++){float pulse=.35f+.65f*(float)Math.abs(Math.sin(ambientTime*1.4f+i+j));paint.setColor(Color.argb((int)((55+90*pulse)*alpha),78+j*24,230,255));c.drawRect(bx+bw*.20f,top+12f*u+j*17f*u,bx+bw*.36f,top+18f*u+j*17f*u,paint);c.drawRect(bx+bw*.62f,top+7f*u+j*18f*u,bx+bw*.78f,top+13f*u+j*18f*u,paint);}}
        }else if(type==9){
            // Volcano world with rising embers.
            Path v=new Path();v.moveTo(w*.10f,h*.79f);v.lineTo(w*.50f,h*.43f);v.lineTo(w*.90f,h*.79f);v.close();paint.setColor(Color.argb((int)(88*alpha),62,38,59));c.drawPath(v,paint);paint.setColor(Color.argb((int)(110*alpha),255,111,48));c.drawOval(new RectF(w*.43f,h*.42f,w*.57f,h*.49f),paint);
            for(int i=0;i<18;i++){float ex=w*(.36f+((i*17)%29)/100f)+(float)Math.sin(ambientTime*.7f+i)*9f*u;float ey=h*.47f-((ambientTime*(.035f+i*.001f)+i*.071f)%1f)*h*.36f;paint.setColor(Color.argb((int)(95*alpha),255,130+i%3*35,55));c.drawCircle(ex,ey,(1.5f+i%3)*u,paint);}
        }else if(type==10){
            // Deep space with orbiting planets and a moving comet.
            for(int i=0;i<4;i++){float cx=w*(.17f+i*.22f),cy=h*(.20f+(i%2)*.17f),rr=w*(.035f+i*.008f);int col=PALETTE[(scene+i+2)%PALETTE.length];paint.setColor((col&0x00FFFFFF)|((int)(92*alpha)<<24));c.drawCircle(cx,cy,rr,paint);stroke.setStrokeWidth(1.5f*u);stroke.setColor(Color.argb((int)(54*alpha),255,255,255));c.drawOval(new RectF(cx-rr*1.7f,cy-rr*.55f,cx+rr*1.7f,cy+rr*.55f),stroke);}
            float q=(ambientTime*.035f)%1f;float cx=w*(1.12f-q*1.35f),cy=h*(.10f+q*.28f);stroke.setStrokeWidth(2f*u);stroke.setColor(Color.argb((int)(100*alpha),255,247,205));c.drawLine(cx,cy,cx+55f*u,cy-28f*u,stroke);paint.setColor(Color.argb((int)(180*alpha),255,255,235));c.drawCircle(cx,cy,3.2f*u,paint);
        }else if(type==11){
            // Waterfall canyon.
            paint.setColor(Color.argb((int)(70*alpha),35,78,103));c.drawRect(0,h*.43f,w*.24f,h,paint);c.drawRect(w*.76f,h*.39f,w,h,paint);
            for(int i=0;i<5;i++){float x=w*(.34f+i*.075f)+(float)Math.sin(ambientTime*.14f+i)*3f*u;stroke.setStrokeWidth((9f+i)*u);stroke.setColor(Color.argb((int)((42+i*8)*alpha),205,244,255));c.drawLine(x,h*.22f,x,h*.73f,stroke);}
            for(int i=0;i<16;i++){float mx=w*(.26f+((i*17)%49)/100f),my=h*(.67f+((i*13)%12)/100f)+(float)Math.sin(ambientTime*.8f+i)*6f*u;paint.setColor(Color.argb((int)(42*alpha),235,252,255));c.drawCircle(mx,my,(3f+i%4*2f)*u,paint);}
        }else if(type==12){
            // Temple night with floating lanterns.
            paint.setColor(Color.argb((int)(82*alpha),58,49,94));for(int i=0;i<5;i++){float x=w*(.07f+i*.20f);c.drawRoundRect(new RectF(x,h*.57f,x+w*.09f,h*.82f),7f*u,7f*u,paint);c.drawRect(x-w*.018f,h*.55f,x+w*.108f,h*.59f,paint);}
            for(int i=0;i<10;i++){float lx=w*(.08f+(i%5)*.20f),ly=h*(.20f+(i/5)*.23f)+(float)Math.sin(ambientTime*.35f+i)*9f*u;paint.setShader(new RadialGradient(lx,ly,15f*u,Color.argb((int)(120*alpha),255,210,95),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(lx,ly,15f*u,paint);paint.setShader(null);paint.setColor(Color.argb((int)(180*alpha),255,182,65));c.drawRoundRect(new RectF(lx-4f*u,ly-6f*u,lx+4f*u,ly+6f*u),3f*u,3f*u,paint);}
        }else if(type==13){
            // Frost mountains and continuous snowfall.
            Path m=new Path();m.moveTo(0,h*.78f);for(int i=0;i<8;i++){float x=w*i/7f;float y=h*(.61f-((i%2)*.11f));m.lineTo(x,y);}m.lineTo(w,h);m.lineTo(0,h);m.close();paint.setColor(Color.argb((int)(66*alpha),77,103,147));c.drawPath(m,paint);
            for(int i=0;i<34;i++){float sx=((i*.071f)+ambientTime*(.006f+(i%3)*.002f))%1.04f*w;float sy=((i*.113f)+ambientTime*(.018f+(i%4)*.003f))%1f*h;paint.setColor(Color.argb((int)(95*alpha),248,253,255));c.drawCircle(sx,sy,(1.2f+i%3*.8f)*u,paint);}
        }else if(type==14){
            // Jungle vines, leaves and fireflies.
            paint.setColor(Color.argb((int)(50*alpha),26,94,62));for(int i=0;i<9;i++){float x=w*(.02f+i*.13f);Path leaf=new Path();float y=h*(.18f+(i%4)*.15f)+(float)Math.sin(ambientTime*.22f+i)*8f*u;leaf.moveTo(x,y);leaf.quadTo(x+w*.05f,y-w*.035f,x+w*.09f,y);leaf.quadTo(x+w*.05f,y+w*.035f,x,y);leaf.close();c.drawPath(leaf,paint);}
            for(int i=0;i<14;i++){float fx=w*(.05f+((i*17)%89)/100f)+(float)Math.sin(ambientTime*.45f+i)*10f*u;float fy=h*(.16f+((i*23)%64)/100f)+(float)Math.cos(ambientTime*.36f+i)*9f*u;float tw=.4f+.6f*(float)Math.abs(Math.sin(ambientTime*2f+i));paint.setColor(Color.argb((int)((45+95*tw)*alpha),255,242,122));c.drawCircle(fx,fy,(1.2f+1.8f*tw)*u,paint);}
        }else{
            // Floating sky islands and balloons.
            for(int i=0;i<5;i++){float ix=w*(.04f+i*.22f),iy=h*(.48f+(i%2)*.17f)+(float)Math.sin(ambientTime*.12f+i)*8f*u;paint.setColor(Color.argb((int)(64*alpha),69,97,111));c.drawOval(new RectF(ix,iy,ix+w*.17f,iy+w*.06f),paint);Path tip=new Path();tip.moveTo(ix+w*.04f,iy+w*.04f);tip.lineTo(ix+w*.085f,iy+w*.13f);tip.lineTo(ix+w*.13f,iy+w*.04f);tip.close();paint.setColor(Color.argb((int)(55*alpha),54,68,84));c.drawPath(tip,paint);}
            for(int i=0;i<7;i++){float bx=w*(.07f+i*.145f),by=h*(.17f+((i%3)*.10f))+(float)Math.sin(ambientTime*.28f+i)*12f*u;int col=PALETTE[(i+scene)%PALETTE.length];paint.setColor((col&0x00FFFFFF)|((int)(82*alpha)<<24));c.drawCircle(bx,by,10f*u,paint);stroke.setStrokeWidth(1f*u);stroke.setColor(Color.argb((int)(70*alpha),255,255,255));c.drawLine(bx,by+10f*u,bx,by+25f*u,stroke);}
        }
    }

    private void drawMapScrollWallpaper(Canvas c){
        float w=getWidth(),h=getHeight(),u=uiScale();
        float levelF=mapFocusLevelFloat();
        float segF=(levelF-1f)/10f;
        int seg=(int)Math.floor(segF);float mix=segF-seg;
        int next=seg+1;
        int top=blendColor(mapSceneTop(seg),mapSceneTop(next),mix);
        int bottom=blendColor(mapSceneBottom(seg),mapSceneBottom(next),mix);
        paint.setShader(new LinearGradient(0,0,0,h,top,bottom,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
        // Cross-fade scene decorations as the player scrolls into the next 10-level region.
        drawMapSceneDecor(c,seg,1f-mix,seg*.31f);drawMapSceneDecor(c,next,mix,next*.31f);
        // Multi-speed parallax bubbles/cloud lights.
        for(int layer=0;layer<3;layer++){
            for(int i=0;i<7;i++){
                float ph=ambientTime*(.095f+layer*.038f)+i*.85f+seg*.21f;
                float x=((i*.151f)+ambientTime*(.0032f+layer*.0024f)*(1+i%2))%1.16f*w-w*.08f;
                float y=h*(.12f+((i*19+layer*11)%72)/100f)+(float)Math.sin(ph)*h*(.018f+layer*.008f);
                float r=w*(.010f+layer*.006f+(i%3)*.004f);int col=PALETTE[(i+seg+layer)%PALETTE.length];
                paint.setShader(new RadialGradient(x-r*.30f,y-r*.35f,r*1.45f,Color.argb(70-layer*10,255,255,255),Color.argb(18+layer*5,Color.red(col),Color.green(col),Color.blue(col)),Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);
            }
        }
        // Extra live atmosphere shared by every map scene: drifting light motes, cloud wisps
        // and an occasional sky streak. These move at different speeds for a stronger parallax feel.
        for(int i=0;i<18;i++){
            float ph=ambientTime*(.34f+(i%4)*.05f)+i*.71f+seg*.17f;
            float x=((i*.067f)+ambientTime*(.005f+(i%3)*.0026f))%1.08f*w-w*.03f+(float)Math.sin(ph)*8f*u;
            float y=h*(.10f+((i*29)%78)/100f)+(float)Math.cos(ph*.72f)*9f*u;
            float tw=.35f+.65f*(float)Math.abs(Math.sin(ambientTime*1.9f+i));
            paint.setColor(Color.argb((int)(22+58*tw),255,250,205));c.drawCircle(x,y,(.9f+1.7f*tw)*u,paint);
        }
        for(int i=0;i<4;i++){
            float x=((i*.31f)+ambientTime*(.0014f+i*.0004f))%1.35f*w-w*.18f;
            float y=h*(.16f+i*.18f)+(float)Math.sin(ambientTime*.08f+i)*8f*u;
            float rw=w*(.07f+i*.012f);paint.setShader(new RadialGradient(x,y,rw,Color.argb(20,250,252,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawOval(new RectF(x-rw,y-rw*.26f,x+rw,y+rw*.26f),paint);paint.setShader(null);
        }
        for(int i=0;i<4;i++){
            float ph=ambientTime*(.30f+i*.045f)+i*1.7f;
            float sx=((ph*.05f+i*.27f)%1.3f)*w-w*.15f;
            float sy=h*(.18f+i*.17f)+(float)Math.sin(ph)*h*.035f;
            stroke.setStrokeWidth((1.2f+i%2)*u);
            stroke.setColor(Color.argb(48+i*8,255,248,205));
            c.drawLine(sx,sy,sx+w*(.07f+.015f*i),sy-h*.025f,stroke);
        }
        float streak=(ambientTime*.027f+seg*.11f)%1f;
        float sx=w*(1.18f-streak*1.48f),sy=h*(.09f+streak*.20f);
        stroke.setStrokeWidth(1.8f*u);stroke.setColor(Color.argb(75,255,250,220));c.drawLine(sx,sy,sx+48f*u,sy-25f*u,stroke);
        // Soft vignette for readable road/nodes.
        paint.setShader(new RadialGradient(w*.5f,h*.48f,Math.max(w,h)*.74f,new int[]{Color.TRANSPARENT,Color.argb(10,0,0,24),Color.argb(46,0,0,38)},new float[]{0f,.72f,1f},Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
    }

    private void drawRealmAtmosphere(Canvas c,int themeLevel,float intensity){
        float w=getWidth(),h=getHeight(),u=uiScale();
        float k=Math.max(.35f,Math.min(1.35f,intensity));
        int accent=themeAccent(Math.max(1,themeLevel));
        // Animated aurora ribbons.
        for(int i=0;i<3;i++){
            float yy=h*(.14f+i*.18f)+(float)Math.sin(ambientTime*(.22f+i*.05f)+i*1.7f)*h*.025f;
            Path p=new Path();p.moveTo(-w*.18f,yy);
            p.cubicTo(w*.18f,yy-h*.06f,w*.48f,yy+h*.07f,w*.72f,yy-h*.025f);
            p.cubicTo(w*.90f,yy-h*.06f,w*1.06f,yy+h*.03f,w*1.18f,yy);
            stroke.setStrokeWidth((5f+i*2.2f)*u*k);
            int rr=Math.min(255,Color.red(accent)+35+i*12),gg=Math.min(255,Color.green(accent)+45),bb=Math.min(255,Color.blue(accent)+55);
            stroke.setColor(Color.argb((int)((18+i*7)*k),rr,gg,bb));c.drawPath(p,stroke);
        }
        // Floating realm rings create a deeper 3D/parallax feeling.
        for(int i=0;i<5;i++){
            float ph=ambientTime*(.08f+i*.009f)+i*1.19f+themeLevel*.013f;
            float x=w*(.08f+i*.23f)+(float)Math.sin(ph)*w*.055f;
            float y=h*(.18f+((i*23)%56)/100f)+(float)Math.cos(ph*.8f)*h*.035f;
            float r=w*(.028f+(i%3)*.013f)*k;
            stroke.setStrokeWidth(1.2f*u);stroke.setColor(Color.argb((int)(42*k),235,245,255));c.drawCircle(x,y,r,stroke);
            paint.setShader(new RadialGradient(x-r*.2f,y-r*.25f,r*1.4f,Color.argb((int)(34*k),255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x,y,r*.82f,paint);paint.setShader(null);
        }
        // Distant floating islands/castle silhouettes drift slowly across the lower background.
        for(int i=0;i<3;i++){
            float x=((i*.43f)+ambientTime*.0022f*(i+1))%1.35f*w-w*.16f;
            float y=h*(.69f+i*.055f)+(float)Math.sin(ambientTime*.13f+i)*6f*u;
            float iw=w*(.12f+i*.025f);
            paint.setColor(Color.argb((int)(22*k),24,30,86));
            c.drawOval(new RectF(x-iw*.55f,y-iw*.13f,x+iw*.55f,y+iw*.13f),paint);
            c.drawRect(x-iw*.10f,y-iw*.28f,x+iw*.10f,y,paint);
            Path roof=new Path();roof.moveTo(x-iw*.15f,y-iw*.28f);roof.lineTo(x,y-iw*.47f);roof.lineTo(x+iw*.15f,y-iw*.28f);roof.close();c.drawPath(roof,paint);
        }
        // Comet glints and fireflies.
        for(int i=0;i<16;i++){
            float ph=ambientTime*(.42f+i*.012f)+i*.77f;
            float x=w*(.03f+((i*17)%91)/100f)+(float)Math.sin(ph)*8f*u;
            float y=h*(.10f+((i*29)%76)/100f)+(float)Math.cos(ph*.7f)*7f*u;
            float tw=.35f+.65f*(float)Math.abs(Math.sin(ph*1.7f));
            paint.setColor(Color.argb((int)((28+58*tw)*k),255,242,172));c.drawCircle(x,y,(.8f+1.4f*tw)*u,paint);
        }
    }

    private void drawWorldWallpaper(Canvas c,int level,boolean animate) {
        float w=getWidth(),h=getHeight(),u=uiScale();int wi=worldIndex(level);int variant=Math.floorMod(level-1,25);
        paint.setShader(new LinearGradient(0,0,0,h,themeTop(level),themeBottom(level),Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
        int mode=Math.floorMod(wi*3+variant,10);
        if(mode==0){paint.setColor(Color.argb(50,255,255,255));for(int i=0;i<7;i++){float y=h*(.11f+i*.13f);float off=((i+variant)%3)*w*.12f;c.drawOval(new RectF(-w*.26f+off,y,w*.58f+off,y+w*.17f),paint);}}
        else if(mode==1){for(int i=0;i<14;i++){int col=PALETTE[(i+wi+variant)%PALETTE.length];paint.setColor((col&0x00FFFFFF)|0x34000000);float x=(.04f+(i%7)*.16f)*w,y=(.14f+(i/7)*.55f)*h;float rr=w*(.035f+((i+variant)%4)*.011f);c.drawCircle(x,y,rr,paint);}}
        else if(mode==2){paint.setColor(Color.argb(65,255,232,168));c.drawCircle(w*(.18f+(variant%5)*.15f),h*.19f,w*.13f,paint);Path hill=new Path();hill.moveTo(0,h*.62f);hill.quadTo(w*.23f,h*(.48f+(variant%3)*.03f),w*.51f,h*.66f);hill.quadTo(w*.76f,h*.78f,w,h*.55f);hill.lineTo(w,h);hill.lineTo(0,h);hill.close();paint.setColor(Color.argb(48,58,45,118));c.drawPath(hill,paint);}
        else if(mode==3){paint.setColor(Color.argb(42,255,255,255));for(int i=0;i<8;i++){float y=h*(.13f+i*.105f);float shift=(float)Math.sin(i+variant*.7f)*w*.08f;c.drawOval(new RectF(-w*.20f+shift,y,w*.52f+shift,y+w*.095f),paint);c.drawOval(new RectF(w*.48f-shift,y+h*.04f,w*1.18f-shift,y+h*.04f+w*.095f),paint);}}
        else if(mode==4){for(int i=0;i<starX.length;i++){float a=.35f+.65f*(.5f+.5f*(float)Math.sin((animate?ambientTime*1.7f:0f)+starPhase[i]+variant*.13f));paint.setColor(Color.argb((int)(180*a),255,255,255));c.drawCircle(starX[i]*w,starY[i]*h,(1.4f+2.3f*a)*u,paint);}paint.setColor(Color.argb(66,255,244,190));c.drawCircle(w*(.22f+(variant%4)*.19f),h*.20f,w*.09f,paint);}
        else if(mode==5){for(int i=0;i<6;i++){Path band=new Path();float yy=h*(.15f+i*.12f);band.moveTo(-w*.1f,yy);band.cubicTo(w*.18f,yy-h*.08f,w*.55f,yy+h*.09f,w*1.1f,yy-h*.02f);stroke.setStrokeWidth((11f+i*2f)*u);stroke.setColor(Color.argb(38+i*6,110+i*18,255-i*10,205+i*5));c.drawPath(band,stroke);}}
        else if(mode==6){paint.setColor(Color.argb(39,255,255,255));for(int i=0;i<15;i++){float x=(.04f+(i%8)*.135f)*w,y=(.14f+(i/8)*.57f)*h;float rr=w*(.025f+((i+variant)%3)*.008f);Path d=new Path();d.moveTo(x,y-rr);d.lineTo(x+rr*.7f,y);d.lineTo(x,y+rr*1.3f);d.lineTo(x-rr*.7f,y);d.close();c.drawPath(d,paint);}}
        else if(mode==7){stroke.setStrokeWidth(1.4f*u);stroke.setColor(Color.argb(44,95,250,255));for(int i=0;i<13;i++){float yy=h*(.14f+i*.06f);c.drawLine(0,yy,w,yy,stroke);}for(int i=0;i<10;i++){float xx=w*i/9f;c.drawLine(xx,h*.14f,w*.5f+(xx-w*.5f)*2.0f,h,stroke);}paint.setColor(Color.argb(50,255,63,210));c.drawCircle(w*(.22f+(variant%5)*.14f),h*.27f,w*.15f,paint);}
        else if(mode==8){Path ground=new Path();ground.moveTo(0,h*.66f);ground.quadTo(w*.24f,h*.55f,w*.50f,h*.69f);ground.quadTo(w*.73f,h*.58f,w,h*.64f);ground.lineTo(w,h);ground.lineTo(0,h);ground.close();paint.setColor(Color.argb(52,27,105,66));c.drawPath(ground,paint);for(int i=0;i<13;i++){paint.setColor(Color.argb(48,235,255,195));c.drawCircle((.05f+(i%7)*.15f)*w,(.16f+(i/7)*.41f)*h,w*.022f,paint);}}
        else{paint.setColor(Color.argb(48,255,225,135));c.drawCircle(w*.50f,h*.23f,w*.15f,paint);for(int i=0;i<7;i++){float yy=h*(.28f+i*.09f);paint.setColor(Color.argb(30+i*4,255,255,255));c.drawRoundRect(new RectF(w*.12f,yy,w*.88f,yy+h*.026f),11f*u,11f*u,paint);}}
        if(animate){float gx=w*(.18f+.08f*(float)Math.sin(ambientTime*.25f+variant));paint.setShader(new RadialGradient(gx,h*.60f,w*.36f,Color.argb(48,120,224,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(gx,h*.60f,w*.36f,paint);paint.setShader(null);for(int i=0;i<15;i++){float xx=((i*.071f)+(ambientTime*.004f*(1+i%3))+(variant*.013f))%1f*w;float yy=(.12f+((i*.113f)%1f)*.73f)*h;paint.setColor(Color.argb(60+(i%3)*18,255,255,255));c.drawCircle(xx,yy,(1.1f+(i%3)*.7f)*u,paint);}}
    
        if(animate)drawLiveWallpaperMotion(c,level);
        if(animate){
            // Faster foreground glints give splash/home/gameplay a visibly alive wallpaper
            // without covering the playfield.
            for(int i=0;i<5;i++){
                float ph=ambientTime*(.42f+i*.035f)+i*1.37f+level*.11f;
                float gx=((ph*.035f+i*.19f)%1.28f)*w-w*.12f;
                float gy=h*(.12f+(i%4)*.21f)+(float)Math.sin(ph)*h*.045f;
                float len=w*(.045f+.018f*(i%3));
                stroke.setStrokeWidth((1.1f+i%2)*u);
                stroke.setColor(Color.argb(42+(i%3)*15,255,255,255));
                c.drawLine(gx,gy,gx+len,gy-len*.28f,stroke);
            }
        }
        drawPremiumWorldDecor(c,level,animate);
    }

    private void drawLiveWallpaperMotion(Canvas c,int level){
        float w=getWidth(),h=getHeight(),u=uiScale();int accent=themeAccent(level),wi=worldIndex(level);
        // slow nebula halos
        for(int i=0;i<4;i++){float ph=ambientTime*(.045f+i*.008f)+i*1.41f+level*.033f;float x=w*(.14f+i*.25f)+(float)Math.sin(ph)*w*.10f;float y=h*(.18f+i*.19f)+(float)Math.cos(ph*.72f)*h*.055f;float r=w*(.10f+(i%2)*.035f);paint.setShader(new RadialGradient(x,y,r*1.45f,Color.argb(26,255,255,255),Color.argb(5,Color.red(accent),Color.green(accent),Color.blue(accent)),Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);}
        // moving orbit arcs
        for(int i=0;i<3;i++){float cy=h*(.22f+i*.24f)+(float)Math.sin(ambientTime*.18f+i)*h*.025f;RectF oval=new RectF(-w*.18f,cy-h*.10f,w*1.18f,cy+h*.10f);stroke.setStrokeWidth((1.2f+i*.7f)*u);stroke.setColor(Color.argb(28+i*12,190+(i*15),220,255));c.drawArc(oval,180f+(ambientTime*(8f+i*4f))%80f,135f,false,stroke);}
        // glossy drifting bubbles - parallax varies per world
        for(int i=0;i<12;i++){float ph=ambientTime*(.105f+i*.011f)+i*.91f+wi*.31f;float x=((i*.091f)+(ambientTime*.0055f*(1+i%3)))%1.12f*w-w*.06f+(float)Math.sin(ph)*w*.025f;float y=h*(.12f+((i*17)%74)/100f)+(float)Math.cos(ph*.63f)*h*.035f;float r=w*(.012f+(i%4)*.008f);int bi=(i+wi)%PALETTE.length;int bc=PALETTE[bi];paint.setShader(new RadialGradient(x-r*.32f,y-r*.36f,r*1.35f,Color.argb(60,255,255,255),Color.argb(22,Color.red(bc),Color.green(bc),Color.blue(bc)),Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);paint.setColor(Color.argb(60,255,255,255));c.drawCircle(x-r*.25f,y-r*.30f,r*.16f,paint);}
        // flowing ribbons
        for(int i=0;i<3;i++){float yy=h*(.30f+i*.22f)+(float)Math.sin(ambientTime*.20f+i)*h*.028f;Path ribbon=new Path();ribbon.moveTo(-w*.18f,yy);ribbon.cubicTo(w*.18f,yy-h*(.045f+i*.004f),w*.58f,yy+h*.055f,w*1.18f,yy-h*.02f);stroke.setStrokeWidth((5f+i*2.2f)*u);stroke.setColor(Color.argb(13+i*7,218,242,255));c.drawPath(ribbon,stroke);}
        // sparkles
        for(int i=0;i<22;i++){float x=((i*.049f)+(ambientTime*.010f*(1+i%3)))%1.05f*w;float y=h*(.08f+((i*19)%86)/100f);float tw=.5f+.5f*(float)Math.sin(ambientTime*2.5f+i);paint.setColor(Color.argb((int)(42+72*tw),255,255,255));c.drawCircle(x,y,(1f+(i%3)*.75f)*u,paint);}
    
        // Extra premium parallax layer: cloud wisps, fireflies, comet glints and edge bubbles.
        for(int layer=0;layer<2;layer++){
            for(int i=0;i<5;i++){
                float ph=ambientTime*(.045f+layer*.018f)+i*.92f+level*.017f;
                float cx=((i*.23f)+ambientTime*(.0015f+layer*.0012f))%1.25f*w-w*.12f;
                float cy=h*(.18f+(i%4)*.19f)+(float)Math.sin(ph)*h*.025f;
                float rw=w*(.075f+layer*.028f);
                paint.setShader(new RadialGradient(cx,cy,rw,Color.argb(20+layer*8,245,251,255),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawOval(new RectF(cx-rw,cy-rw*.32f,cx+rw,cy+rw*.32f),paint);paint.setShader(null);
            }
        }
        for(int i=0;i<10;i++){
            float ph=ambientTime*(.33f+i*.012f)+i*1.17f;
            float fx=w*(.05f+((i*13)%89)/100f)+(float)Math.sin(ph)*10f*u;
            float fy=h*(.16f+((i*21)%68)/100f)+(float)Math.cos(ph*.8f)*10f*u;
            float tw=.45f+.55f*(float)Math.abs(Math.sin(ambientTime*2.1f+i));
            paint.setColor(Color.argb((int)(32+65*tw),255,245,175));c.drawCircle(fx,fy,(1.0f+1.7f*tw)*u,paint);
        }
        float comet=(ambientTime*.085f)%1f;
        float cx=w*(1.12f-comet*1.35f),cy=h*(.10f+comet*.22f);
        stroke.setStrokeWidth(1.7f*u);stroke.setColor(Color.argb(70,255,247,205));c.drawLine(cx,cy,cx+42f*u,cy-23f*u,stroke);
    }

    private void drawPremiumWorldDecor(Canvas c,int level,boolean animate) {
        float w=getWidth(),h=getHeight(),u=uiScale();int accent=themeAccent(level);int variant=Math.floorMod(level*7,19);
        float t=animate?ambientTime:0f;
        float x1=w*(.18f+.08f*(float)Math.sin(t*.18f+variant));float y1=h*(.30f+.035f*(float)Math.cos(t*.23f+variant));
        paint.setShader(new RadialGradient(x1,y1,w*.28f,Color.argb(55,Color.red(accent),Color.green(accent),Color.blue(accent)),Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x1,y1,w*.28f,paint);paint.setShader(null);
        float x2=w*(.78f+.06f*(float)Math.cos(t*.16f+variant*.7f));paint.setColor(Color.argb(25,255,255,255));c.drawCircle(x2,h*.58f,w*.22f,paint);

        drawWorldLandmarks(c,level,animate);

        stroke.setStrokeWidth(2.2f*u);stroke.setColor(Color.argb(42,255,255,255));
        for(int i=0;i<3;i++){float yy=h*(.38f+i*.14f);RectF arc=new RectF(-w*.20f,yy-w*.10f,w*1.20f,yy+w*.22f);c.drawArc(arc,198f,144f,false,stroke);}
        for(int i=0;i<14;i++){float xx=((i*.097f)+(animate?t*.005f*(1+i%2):0f)+(variant*.031f))%1f*w;float yy=h*(.18f+((i*.137f+variant*.019f)%1f)*.62f);float a=.45f+.55f*(float)Math.abs(Math.sin(t*1.4f+i));paint.setColor(Color.argb((int)(88*a),255,255,255));c.drawCircle(xx,yy,(1.3f+(i%3)*.8f)*u,paint);}

        // Stronger edge vignette keeps gameplay bubbles readable over every wallpaper.
        paint.setShader(new RadialGradient(w*.5f,h*.47f,Math.max(w,h)*.72f,
                new int[]{Color.TRANSPARENT,Color.argb(18,0,0,25),Color.argb(58,0,0,38)},
                new float[]{0f,.72f,1f},Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
    }

    private void drawWorldLandmarks(Canvas c,int level,boolean animate) {
        float w=getWidth(),h=getHeight(),u=uiScale();int wi=worldIndex(level);float t=animate?ambientTime:0f;int accent=themeAccent(level);
        paint.setShader(null);
        if(wi==0||wi==14){
            paint.setColor(Color.argb(48,255,255,255));for(int i=0;i<5;i++){float cx=w*(.08f+i*.23f)+(float)Math.sin(t*.12f+i)*8f*u;float cy=h*(.24f+(i%2)*.16f);c.drawCircle(cx,cy,w*.075f,paint);c.drawCircle(cx+w*.055f,cy+w*.012f,w*.055f,paint);c.drawCircle(cx-w*.050f,cy+w*.018f,w*.050f,paint);}            
            Path hill=new Path();hill.moveTo(0,h*.76f);hill.quadTo(w*.22f,h*.66f,w*.48f,h*.78f);hill.quadTo(w*.75f,h*.66f,w,h*.74f);hill.lineTo(w,h);hill.lineTo(0,h);hill.close();paint.setColor(Color.argb(60,24,91,90));c.drawPath(hill,paint);
        } else if(wi==1||wi==18){
            for(int i=0;i<5;i++){float cx=w*(.10f+i*.21f),cy=h*(.28f+(i%2)*.18f),rr=w*.045f;paint.setColor((PALETTE[(i+level)%PALETTE.length]&0x00FFFFFF)|0x55000000);c.drawCircle(cx,cy,rr,paint);stroke.setStrokeWidth(4f*u);stroke.setColor(Color.argb(85,255,255,255));c.drawLine(cx,cy+rr,cx,cy+rr*3.4f,stroke);}            
        } else if(wi==2||wi==12){
            paint.setColor(Color.argb(70,255,219,126));c.drawCircle(w*.76f,h*.22f,w*.10f,paint);for(int i=0;i<4;i++){Path dune=new Path();float yy=h*(.66f+i*.06f);dune.moveTo(0,yy);dune.quadTo(w*.23f,yy-h*.09f,w*.50f,yy);dune.quadTo(w*.78f,yy+h*.07f,w,yy-h*.02f);dune.lineTo(w,h);dune.lineTo(0,h);dune.close();paint.setColor(Color.argb(28+i*8,137,72,79));c.drawPath(dune,paint);}
        } else if(wi==3||wi==16){
            stroke.setStrokeWidth(5f*u);for(int i=0;i<5;i++){Path wave=new Path();float yy=h*(.68f+i*.05f);wave.moveTo(-w*.1f,yy);wave.cubicTo(w*.18f,yy-h*.035f,w*.38f,yy+h*.035f,w*.62f,yy);wave.cubicTo(w*.80f,yy-h*.035f,w*.96f,yy+h*.02f,w*1.1f,yy);stroke.setColor(Color.argb(42+i*7,210,250,255));c.drawPath(wave,stroke);}for(int i=0;i<9;i++){paint.setColor(Color.argb(55,255,255,255));c.drawCircle(w*(.08f+(i%5)*.21f),h*(.26f+(i/5)*.32f),w*(.012f+(i%3)*.007f),paint);}
        } else if(wi==4||wi==17){
            float mx=w*.77f,my=h*.23f,mr=w*.105f;paint.setColor(Color.argb(72,246,244,255));c.drawCircle(mx,my,mr,paint);paint.setColor(Color.argb(30,80,80,120));c.drawCircle(mx-mr*.25f,my-mr*.15f,mr*.18f,paint);c.drawCircle(mx+mr*.30f,my+mr*.20f,mr*.12f,paint);if(wi==17){paint.setColor(Color.argb(115,32,26,66));c.drawCircle(mx+mr*.30f,my,mr*.92f,paint);}
        } else if(wi==5||wi==11){
            Path m=new Path();m.moveTo(0,h*.78f);for(int i=0;i<7;i++){float x=w*i/6f;float y=h*(.62f-((i%2)*.13f));m.lineTo(x,y);}m.lineTo(w,h);m.lineTo(0,h);m.close();paint.setColor(Color.argb(58,35,45,105));c.drawPath(m,paint);stroke.setStrokeWidth(8f*u);for(int i=0;i<4;i++){Path aur=new Path();float yy=h*(.20f+i*.055f);aur.moveTo(-w*.1f,yy);aur.cubicTo(w*.23f,yy-h*.08f,w*.48f,yy+h*.07f,w*1.1f,yy-h*.03f);stroke.setColor(Color.argb(38+i*7,120+i*20,255,205+i*6));c.drawPath(aur,stroke);}
        } else if(wi==6){
            for(int i=0;i<8;i++){float x=w*(.06f+i*.13f),base=h*.77f,hh=h*(.08f+.035f*(i%4));Path cr=new Path();cr.moveTo(x,base);cr.lineTo(x+w*.035f,base-hh);cr.lineTo(x+w*.07f,base);cr.close();paint.setColor(Color.argb(58,130+i*8,226,255));c.drawPath(cr,paint);}
        } else if(wi==7||wi==15){
            for(int i=0;i<11;i++){float bw=w*.075f,bx=i*w*.095f,top=h*(.58f-.04f*(i%5));paint.setColor(Color.argb(72,28,28,82));c.drawRect(bx,top,bx+bw,h*.82f,paint);for(int j=0;j<4;j++){paint.setColor(Color.argb(90,80+(j*35),240,255));c.drawRect(bx+bw*.2f,top+12f*u+j*18f*u,bx+bw*.35f,top+18f*u+j*18f*u,paint);c.drawRect(bx+bw*.60f,top+8f*u+j*20f*u,bx+bw*.75f,top+14f*u+j*20f*u,paint);}}
        } else if(wi==8){
            paint.setColor(Color.argb(65,19,83,67));for(int i=0;i<9;i++){float x=w*(.04f+i*.12f),base=h*.82f;Path tree=new Path();tree.moveTo(x,base);tree.lineTo(x+w*.045f,base-h*.16f);tree.lineTo(x+w*.09f,base);tree.close();c.drawPath(tree,paint);}
        } else if(wi==9||wi==19){
            paint.setColor(Color.argb(58,72,53,120));for(int i=0;i<5;i++){float x=w*(.08f+i*.21f);c.drawRoundRect(new RectF(x,h*.57f,x+w*.075f,h*.82f),8f*u,8f*u,paint);c.drawRect(x-w*.018f,h*.55f,x+w*.093f,h*.59f,paint);}paint.setColor(Color.argb(45,255,222,95));c.drawCircle(w*.5f,h*.24f,w*.11f,paint);
        } else if(wi==10){
            Path v=new Path();v.moveTo(w*.18f,h*.78f);v.lineTo(w*.50f,h*.48f);v.lineTo(w*.82f,h*.78f);v.close();paint.setColor(Color.argb(70,63,38,60));c.drawPath(v,paint);paint.setColor(Color.argb(85,255,112,50));c.drawOval(new RectF(w*.44f,h*.46f,w*.56f,h*.52f),paint);
        } else if(wi==13){
            for(int i=0;i<4;i++){float x=w*(.18f+i*.22f),y=h*(.23f+(i%2)*.15f),r=w*(.035f+i*.009f);paint.setColor((PALETTE[(i+2)%PALETTE.length]&0x00FFFFFF)|0x55000000);c.drawCircle(x,y,r,paint);stroke.setStrokeWidth(2f*u);stroke.setColor(Color.argb(50,255,255,255));c.drawOval(new RectF(x-r*1.8f,y-r*.55f,x+r*1.8f,y+r*.55f),stroke);}
        }
        paint.setShader(new RadialGradient(w*.5f,h*.55f,w*.58f,Color.TRANSPARENT,Color.argb(28,0,0,30),Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);paint.setShader(null);
    }

    private void buyBoosterWithCoins(Power which) {
        int cost = which==Power.BOMB ? BOMB_COST : WILD_COST;
        if(coins < cost){
            floatingTexts.add(new FloatingText("NEED "+cost+" COINS",getWidth()*.5f,getHeight()*.76f,Color.rgb(255,196,116),24f));
            overlay=Overlay.SHOP;
            audio.play(AudioEngine.FX_UI_OPEN,.85f,1f);
            return;
        }
        coins-=cost;
        if(which==Power.BOMB){bombCount++;power=Power.BOMB;prefs.edit().putInt("bomb_inventory",bombCount).putInt("coins",coins).apply();audio.play(AudioEngine.FX_POWER,1f,1.05f);}
        else {rainbowCount++;power=Power.RAINBOW;prefs.edit().putInt("wild_inventory",rainbowCount).putInt("coins",coins).apply();audio.play(AudioEngine.FX_MAGIC,1f,1.08f);}
        floatingTexts.add(new FloatingText((which==Power.BOMB?"BOMB":"WILD")+" BOUGHT • -"+cost+" COINS",getWidth()*.5f,getHeight()*.76f,Color.rgb(187,246,255),22f));
        haptic(28);
        saveGameState();
    }

    // ---------------------------------------------------------------
    // Utility and persistence
    // ---------------------------------------------------------------

    private float uiScale() {
        return Math.max(1f, Math.min(2.35f, getWidth() / 540f));
    }

    private boolean hasSavedGame() {
        // v4.1.1 and earlier could accidentally store a Daily Challenge as the
        // Adventure resume. Ignore that legacy slot instead of showing e.g. LEVEL 334.
        return prefs.getBoolean("saved_game", false) && prefs.contains("saved_grid")
                && !prefs.getBoolean("saved_daily_challenge", false);
    }

    private boolean hasContinueOption(){
        // Even if an older Daily Challenge corrupted the resume slot, progression
        // itself is safe in maxUnlocked. Offer CONTINUE at the real Adventure level.
        return hasSavedGame() || maxUnlocked>1;
    }

    private int continueLevel(){
        return hasSavedGame()?Math.max(1,Math.min(MAP_LEVELS,prefs.getInt("saved_level",maxUnlocked))):Math.max(1,maxUnlocked);
    }

    private void saveGameState() {
        // Survival, Treasure Room and Daily Challenge are session modes. Never overwrite
        // the player's Adventure resume slot with any of them.
        if (dailyChallengeMode || launchingDailyChallenge || gameMode != GameMode.ADVENTURE || screen != Screen.GAME || grid.isEmpty() || overlay == Overlay.WIN || overlay == Overlay.LOSE) return;
        StringBuilder data = new StringBuilder();
        for (Map.Entry<Integer, Integer> e : grid.entrySet()) data.append(e.getKey()).append(':').append(e.getValue()).append(',');
        prefs.edit().putBoolean("saved_game", true).putString("saved_grid", data.toString())
                .putInt("saved_level", selectedLevel).putInt("saved_score", levelScore).putInt("saved_goal", targetScore)
                .putInt("saved_shots", shotsLeft).putInt("saved_misses", misses).putInt("saved_combo", combo)
                .putInt("saved_initial", initialBubbleCount).putInt("saved_clear_target", clearTarget).putInt("saved_cleared", clearedBubbles)
                .putInt("saved_bomb", bombCount).putInt("saved_rainbow", rainbowCount).putInt("saved_current", currentColor)
                .putInt("saved_pressure_shots", shotsSinceDrop).putInt("saved_pressure_limit", pressureLimit)
                .putInt("saved_grid_phase",gridParityPhase)
                .putBoolean("saved_continue_used",continueUsedThisLevel)
                .putInt("saved_objective_target",objectiveTarget).putInt("saved_objective_progress",objectiveProgress)
                .putString("saved_objective",objective.name()).putBoolean("saved_daily_challenge",dailyChallengeMode)
                .putInt("saved_super_charge",superCharge).putInt("saved_branch_route",activeBranchRoute)
                .putInt("saved_boss_shield",bossShield).putInt("saved_boss_max_shield",bossMaxShield)
                .putInt("saved_boss_attack",bossShotsUntilAttack).putInt("saved_boss_phase",bossPhase)
                .putInt("saved_next", nextColor).putString("saved_power", power.name()).apply();
    }

    private void loadGameState() {
        if (!hasSavedGame()) { screen = Screen.MAP; return; }
        try {
            grid.clear(); particles.clear(); glassShards.clear(); debrisFloorY=-1f; falling.clear(); floatingTexts.clear();
            String raw = prefs.getString("saved_grid", "");
            if (raw != null && !raw.isEmpty()) for (String entry : raw.split(",")) {
                if (entry.isEmpty()) continue; String[] kv = entry.split(":");
                if (kv.length == 2) grid.put(Integer.parseInt(kv[0]), Integer.parseInt(kv[1]));
            }
            selectedLevel = Math.max(1, Math.min(MAP_LEVELS, prefs.getInt("saved_level", 1)));
            levelScore = prefs.getInt("saved_score", 0); targetScore = prefs.getInt("saved_goal", 3000 + selectedLevel * 450);
            shotsLeft = Math.min(28, Math.max(0, prefs.getInt("saved_shots", 28))); misses = prefs.getInt("saved_misses", 0); combo = prefs.getInt("saved_combo", 0);
            initialBubbleCount = Math.max(1,prefs.getInt("saved_initial", Math.max(1,grid.size())));
            clearTarget = Math.max(1,prefs.getInt("saved_clear_target", (int)Math.ceil(initialBubbleCount*.90f)));
            clearedBubbles = Math.max(0,prefs.getInt("saved_cleared", Math.max(0,initialBubbleCount-grid.size())));
            feverTimer=0f;feverBurst=0f;rings.clear();
            bombCount = prefs.getInt("saved_bomb", prefs.getInt("bomb_inventory",STARTING_BOMBS)); rainbowCount = prefs.getInt("saved_rainbow", prefs.getInt("wild_inventory",STARTING_WILDS));
            shotsSinceDrop = prefs.getInt("saved_pressure_shots",0); pressureLimit = Math.max(2,prefs.getInt("saved_pressure_limit", selectedLevel<=10?7:selectedLevel<=55?6:selectedLevel<=150?5:4));
            gridParityPhase = prefs.getInt("saved_grid_phase",0)&1;
            continueUsedThisLevel = prefs.getBoolean("saved_continue_used",false);
            try { objective=Objective.valueOf(prefs.getString("saved_objective",objectiveForLevel(selectedLevel).name())); } catch(Throwable ignored){ objective=objectiveForLevel(selectedLevel); }
            objectiveTarget=Math.max(0,prefs.getInt("saved_objective_target",0));objectiveProgress=Math.max(0,prefs.getInt("saved_objective_progress",0));dailyChallengeMode=prefs.getBoolean("saved_daily_challenge",false);
            gameMode=GameMode.ADVENTURE;
            activeBranchRoute=prefs.getInt("saved_branch_route",branchRouteForLevel(selectedLevel));
            configureDynamicLevelSystems(selectedLevel);
            superCharge=Math.max(0,Math.min(100,prefs.getInt("saved_super_charge",0)));superReadyAnnounced=superCharge>=100;
            int defaultBossMax=objective==Objective.BOSS?(3+Math.min(4,selectedLevel/100)):0;
            bossMaxShield=Math.max(0,prefs.getInt("saved_boss_max_shield",defaultBossMax));
            bossShield=Math.max(0,Math.min(bossMaxShield,prefs.getInt("saved_boss_shield",bossMaxShield)));
            bossShotsUntilAttack=Math.max(0,prefs.getInt("saved_boss_attack",objective==Objective.BOSS?4:0));
            bossPhase=Math.max(1,Math.min(2,prefs.getInt("saved_boss_phase",1)));
            currentColor = prefs.getInt("saved_current", 0); nextColor = prefs.getInt("saved_next", 1);
            try { power = Power.valueOf(prefs.getString("saved_power", Power.NORMAL.name())); } catch (Throwable ignored) { power = Power.NORMAL; }
            shotFlying=false; shotFlightTime=0f; aiming=false; overlay=Overlay.NONE; screen=Screen.GAME; displayedBest=prefs.getInt("best_"+selectedLevel,0); audio.setMusicTheme(12);
            if(grid.isEmpty()){clearSavedGame();screen=Screen.MAP;}
        } catch (Throwable t) { clearSavedGame(); screen = Screen.MAP; }
    }

    private void clearSavedGame() {
        // Daily Challenge uses the Adventure renderer/game mode, but it must never
        // delete the player's real Adventure resume.
        if(dailyChallengeMode || launchingDailyChallenge)return;
        prefs.edit().remove("saved_game").remove("saved_grid").remove("saved_level").remove("saved_score")
                .remove("saved_goal").remove("saved_shots").remove("saved_misses").remove("saved_combo")
                .remove("saved_initial").remove("saved_clear_target").remove("saved_cleared")
                .remove("saved_bomb").remove("saved_rainbow").remove("saved_current").remove("saved_next")
                .remove("saved_pressure_shots").remove("saved_pressure_limit").remove("saved_grid_phase").remove("saved_continue_used")
                .remove("saved_objective_target").remove("saved_objective_progress").remove("saved_objective").remove("saved_daily_challenge")
                .remove("saved_super_charge").remove("saved_branch_route").remove("saved_boss_shield").remove("saved_boss_max_shield")
                .remove("saved_boss_attack").remove("saved_boss_phase")
                .remove("saved_power").apply();
    }

    private boolean in(float x,float y,float l,float t,float r,float b){return x>=l&&x<=r&&y>=t&&y<=b;}
    private float dist(float x1,float y1,float x2,float y2){float dx=x1-x2,dy=y1-y2;return(float)Math.sqrt(dx*dx+dy*dy);}

    private void drawStar(Canvas c, float cx, float cy, float r, int color) {
        Path p = new Path();
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = (i % 2 == 0) ? r : r * .45f;
            float x = cx + (float) Math.cos(a) * rr, y = cy + (float) Math.sin(a) * rr;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        paint.setColor(Color.argb(90, 0, 0, 0));
        c.save();
        c.translate(0, 3f);
        c.drawPath(p, paint);
        c.restore();
        paint.setShader(new RadialGradient(cx - r * .25f, cy - r * .28f, r * 1.35f,
                new int[]{lighten(color, .55f), color, darken(color, .35f)}, null, Shader.TileMode.CLAMP));
        c.drawPath(p, paint);
        paint.setShader(null);
        stroke.setStrokeWidth(Math.max(1.2f, r * .10f));
        stroke.setColor(Color.argb(160, 255, 255, 255));
        c.drawPath(p, stroke);
    }

    private void clickFx(){audio.play(AudioEngine.FX_CLICK,.65f,1f);haptic(10);}
    private void bounceFx(){long n=System.currentTimeMillis();if(n-lastBounceMs>70){audio.play(AudioEngine.FX_BOUNCE,.42f,1f);lastBounceMs=n;}}

    private void haptic(int ms){
        if(!hapticsOn||vibrator==null||!vibrator.hasVibrator())return;
        try{if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createOneShot(ms,Math.min(120,40+ms)));else vibrator.vibrate(ms);}catch(Exception ignored){}
    }

    private void saveSettings(){prefs.edit().putBoolean("sound",soundOn).putBoolean("music",musicOn).putBoolean("aimGuide",aimGuideOn).putBoolean("haptics",hapticsOn).apply();}

private boolean isDailyGiftClaimed(){return todayKey().equals(prefs.getString("dailyGift",""));}
    private void claimDailyGift(){
        if(isDailyGiftClaimed()){clickFx();floatingTexts.add(new FloatingText("COME BACK TOMORROW",getWidth()*.5f,getHeight()*.61f,Color.WHITE,20f));return;}
        coins+=DAILY_COIN_REWARD;prefs.edit().putInt("coins",coins).putString("dailyGift",todayKey()).apply();audio.play(AudioEngine.FX_COIN,1f,1f);haptic(35);
        for(int i=0;i<22;i++)particles.add(new Particle(getWidth()*.5f,getHeight()*.65f,(random.nextFloat()-.5f)*420f,-random.nextFloat()*430f,Color.rgb(255,200,35),4f+random.nextFloat()*5f,.8f+random.nextFloat()*.5f));
        floatingTexts.add(new FloatingText("+"+DAILY_COIN_REWARD+" COINS",getWidth()*.5f,getHeight()*.61f,Color.rgb(255,226,76),27f));
    }

    private static class RingFx{
        float x,y,radius,speed,life,maxLife;int color;
        RingFx(float x,float y,int color,float radius,float speed,float life){this.x=x;this.y=y;this.color=color;this.radius=radius;this.speed=speed;this.life=life;this.maxLife=life;}
    }
    private static class Particle{
        float x,y,vx,vy,size,life,maxLife;int color;
        Particle(float x,float y,float vx,float vy,int color,float size,float life){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.color=color;this.size=size;this.life=life;this.maxLife=life;}
    }
    private static class GlassShard{
        float x,y,vx,vy,w,h,vr,rot,life,maxLife;int color;boolean concrete;boolean settled;
        GlassShard(float x,float y,float vx,float vy,float w,float h,float vr,int color,float life){
            this(x,y,vx,vy,w,h,vr,color,life,false);
        }
        GlassShard(float x,float y,float vx,float vy,float w,float h,float vr,int color,float life,boolean concrete){
            this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.w=w;this.h=h;this.vr=vr;this.rot=(float)(Math.random()*6.2831855f);this.color=color;this.life=life;this.maxLife=life;this.concrete=concrete;this.settled=false;
        }
    }
    private static class FallingBubble{
        float x,y,vx,vy,rot,vr;int color;
        FallingBubble(float x,float y,float vx,float vy,int color,float vr){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.color=color;this.vr=vr;}
    }
    private static class FloatingText{
        String text;float x,y,life=1.05f,size;int color;
        FloatingText(String text,float x,float y,int color,float size){this.text=text;this.x=x;this.y=y;this.color=color;this.size=size;}
    }
}
