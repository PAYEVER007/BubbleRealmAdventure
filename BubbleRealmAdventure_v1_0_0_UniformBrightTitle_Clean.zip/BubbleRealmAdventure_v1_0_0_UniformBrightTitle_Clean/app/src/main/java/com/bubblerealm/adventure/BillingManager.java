package com.bubblerealm.adventure;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Consumable Google Play Billing coin packs. Prices always come from Google Play. */
public final class BillingManager implements PurchasesUpdatedListener {
    public interface Listener {
        void onCoinsPurchased(int coins, String productId, String purchaseToken, Runnable onPersisted);
        void onBillingStateChanged(boolean ready);
    }

    public static final String COINS_500 = "coins_500";
    public static final String COINS_1200 = "coins_1200";
    public static final String COINS_2500 = "coins_2500";
    public static final String COINS_1800 = "coins_1800";

    private final Activity activity;
    private final Listener listener;
    private final SharedPreferences prefs;
    private final BillingClient client;
    private final Map<String, ProductDetails> details = new HashMap<>();
    private boolean ready;

    public BillingManager(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
        this.prefs = activity.getSharedPreferences("bubble_realm_billing", Context.MODE_PRIVATE);
        client = BillingClient.newBuilder(activity)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
        connect();
    }

    private void connect() {
        try {
            client.startConnection(new BillingClientStateListener() {
                @Override public void onBillingSetupFinished(BillingResult result) {
                    ready = result.getResponseCode() == BillingClient.BillingResponseCode.OK;
                    if (listener != null) listener.onBillingStateChanged(ready);
                    if (ready) { queryProducts(); refreshPurchases(); }
                }
                @Override public void onBillingServiceDisconnected() {
                    ready = false;
                    details.clear();
                    if (listener != null) listener.onBillingStateChanged(false);
                }
            });
        } catch (Throwable ignored) {
            ready = false;
            if (listener != null) listener.onBillingStateChanged(false);
        }
    }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        for (String id : new String[]{COINS_500, COINS_1200, COINS_2500, COINS_1800}) {
            list.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build());
        }
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
        try {
            client.queryProductDetailsAsync(params, (result, queryResult) -> {
                details.clear();
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && queryResult != null) {
                    for (ProductDetails pd : queryResult.getProductDetailsList()) details.put(pd.getProductId(), pd);
                }
                if (listener != null) activity.runOnUiThread(() -> listener.onBillingStateChanged(ready));
            });
        } catch (Throwable ignored) {}
    }

    public void refreshPurchases() {
        if (!ready) return;
        try {
            QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.INAPP).build();
            client.queryPurchasesAsync(params, (result, purchases) -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                    for (Purchase p : purchases) processPurchase(p);
                }
            });
        } catch (Throwable ignored) {}
    }

    public boolean isReady() { return ready; }
    public boolean isProductAvailable(String productId) { return ready && details.containsKey(productId); }

    private ProductDetails.OneTimePurchaseOfferDetails firstOffer(ProductDetails pd) {
        if (pd == null) return null;
        try {
            List<ProductDetails.OneTimePurchaseOfferDetails> offers = pd.getOneTimePurchaseOfferDetailsList();
            if (offers != null && !offers.isEmpty()) return offers.get(0);
        } catch (Throwable ignored) {}
        try { return pd.getOneTimePurchaseOfferDetails(); } catch (Throwable ignored) { return null; }
    }

    public String getPrice(String productId) {
        if (!ready) return "CHECKING...";
        ProductDetails pd = details.get(productId);
        if (pd == null) return "UNAVAILABLE";
        try {
            ProductDetails.OneTimePurchaseOfferDetails offer = firstOffer(pd);
            if (offer != null && offer.getFormattedPrice() != null && !offer.getFormattedPrice().isEmpty()) {
                return offer.getFormattedPrice();
            }
        } catch (Throwable ignored) {}
        return "UNAVAILABLE";
    }

    public void buy(String productId) {
        if (!ready) {
            Toast.makeText(activity, "Google Play purchases are unavailable right now.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProductDetails pd = details.get(productId);
        if (pd == null) {
            Toast.makeText(activity, "This coin pack is not available right now.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ProductDetails.OneTimePurchaseOfferDetails offer = firstOffer(pd);
            if (offer == null) {
                Toast.makeText(activity, "This purchase is not available right now.", Toast.LENGTH_SHORT).show();
                return;
            }
            BillingFlowParams.ProductDetailsParams pdp = BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(pd)
                    .setOfferToken(offer.getOfferToken())
                    .build();
            List<BillingFlowParams.ProductDetailsParams> products = new ArrayList<>();
            products.add(pdp);
            BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(products).build();
            client.launchBillingFlow(activity, flow);
        } catch (Throwable t) {
            Toast.makeText(activity, "Purchase could not start. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) return;
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || purchases == null) return;
        for (Purchase purchase : purchases) processPurchase(purchase);
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        String token = purchase.getPurchaseToken();
        if (prefs.getBoolean("granted_" + token, false)) {
            consume(token);
            return;
        }
        String productId = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
        int amount = coinAmount(productId);
        if (amount <= 0 || listener == null) return;

        listener.onCoinsPurchased(amount, productId, token, () -> {
            boolean recorded = prefs.edit().putBoolean("granted_" + token, true).commit();
            if (recorded) consume(token);
        });
    }

    private void consume(String token) {
        try {
            ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(token).build();
            client.consumeAsync(params, (result, purchaseToken) -> {});
        } catch (Throwable ignored) {}
    }

    private int coinAmount(String productId) {
        if (COINS_500.equals(productId)) return 500;
        if (COINS_1200.equals(productId)) return 1200;
        if (COINS_2500.equals(productId)) return 2500;
        if (COINS_1800.equals(productId)) return 1800;
        return 0;
    }

    public void destroy() {
        try { client.endConnection(); } catch (Throwable ignored) {}
    }
}
