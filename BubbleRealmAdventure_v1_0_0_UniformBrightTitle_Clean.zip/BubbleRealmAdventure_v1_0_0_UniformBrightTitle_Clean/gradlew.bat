@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
set "BOOT_DIR=%USERPROFILE%\.gradle\bubblerealm-bootstrap"
set "GRADLE_HOME=%BOOT_DIR%\gradle-8.13"
set "GRADLE_BAT=%GRADLE_HOME%\bin\gradle.bat"
set "GRADLE_ZIP=%BOOT_DIR%\gradle-8.13-bin.zip"

if not exist "%GRADLE_BAT%" (
  echo First build: downloading official Gradle 8.13 distribution...
  if not exist "%BOOT_DIR%" mkdir "%BOOT_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile '%GRADLE_ZIP%'; if (Test-Path '%GRADLE_HOME%') { Remove-Item -Recurse -Force '%GRADLE_HOME%' }; Expand-Archive -Force '%GRADLE_ZIP%' '%BOOT_DIR%'"
  if errorlevel 1 (
    echo.
    echo ERROR: Gradle 8.13 could not be downloaded. Check internet/proxy and retry.
    exit /b 1
  )
)

call "%GRADLE_BAT%" %*
set "EXIT_CODE=%ERRORLEVEL%"
endlocal & exit /b %EXIT_CODE%
